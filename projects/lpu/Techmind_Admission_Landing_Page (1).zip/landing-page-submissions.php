<?php
include('inc/db-connection.php');

$name = isset($_POST['name']) ? $_POST['name'] : '';
$father_name = isset($_POST['father_name']) ? $_POST['father_name'] : '';
$dob = isset($_POST['dob']) ? $_POST['dob'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$company_name = isset($_POST['company_name']) ? $_POST['company_name'] : '';
$country_code = isset($_POST['country_code']) ? $_POST['country_code'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$landline_number = isset($_POST['landline_number']) ? $_POST['landline_number'] : '';
$father_number = isset($_POST['father_number']) ? $_POST['father_number'] : '';
$emergency_number = isset($_POST['emergency_number']) ? $_POST['emergency_number'] : '';
$website_url = isset($_POST['pageType']) ? $_POST['pageType'] : '';
$title = isset($_POST['title']) ? $_POST['title'] : '';
$short_description = isset($_POST['short_description']) ? $_POST['short_description'] : '';
$long_description = isset($_POST['long_description']) ? $_POST['long_description'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$city = isset($_POST['city']) ? $_POST['city'] : '';
$state = isset($_POST['state']) ? $_POST['state'] : '';
$zip = isset($_POST['zip']) ? $_POST['zip'] : '';
$country = isset($_POST['country']) ? $_POST['country'] : '';
$detail_1 = isset($_POST['detail_1']) ? $_POST['detail_1'] : '';
$detail_2 = isset($_POST['detail_2']) ? $_POST['detail_2'] : '';
$detail_3 = isset($_POST['detail_3']) ? $_POST['detail_3'] : '';
$detail_4 = isset($_POST['detail_4']) ? $_POST['detail_4'] : '';
$detail_5 = isset($_POST['detail_5']) ? $_POST['detail_5'] : '';
$lead_transaction_id = isset($_POST['lead_transaction_id']) ? $_POST['lead_transaction_id'] : '';
$lead_transaction_date = isset($_POST['lead_transaction_date']) ? $_POST['lead_transaction_date'] : '';
$programme = isset($_POST['programme']) ? $_POST['programme'] : '';
$specialization = isset($_POST['specialization']) ? $_POST['specialization'] : '';
$checkbox = isset($_POST['checkbox']) ? $_POST['checkbox'] : '';
$utm_source = isset($_POST['utm_source']) ? $_POST['utm_source'] : '';
$utm_medium = isset($_POST['utm_medium']) ? $_POST['utm_medium'] : '';
$utm_campaignid = isset($_POST['utm_campaignid']) ? $_POST['utm_campaignid'] : '';
$utm_adgroupid = isset($_POST['utm_adgroupid']) ? $_POST['utm_adgroupid'] : '';
$utm_creativeid = isset($_POST['utm_creativeid']) ? $_POST['utm_creativeid'] : '';
$utm_matchtype = isset($_POST['utm_matchtype']) ? $_POST['utm_matchtype'] : '';
$utm_device = isset($_POST['utm_device']) ? $_POST['utm_device'] : '';
$utm_network = isset($_POST['utm_network']) ? $_POST['utm_network'] : '';
$utm_keyword = isset($_POST['utm_keyword']) ? $_POST['utm_keyword'] : '';
$utm_keywordid = isset($_POST['utm_keywordid']) ? $_POST['utm_keywordid'] : '';
$utm_campaign = isset($_POST['utm_campaign']) ? $_POST['utm_campaign'] : '';
$gad_source = isset($_POST['gad_source']) ? $_POST['gad_source'] : '';
$gbraid = isset($_POST['gbraid']) ? $_POST['gbraid'] : '';
$gclid = isset($_POST['gclid']) ? $_POST['gclid'] : '';


$query = "
    INSERT INTO landing_page_submissions (
        name, email, country_code, phone, state, city, programme, specialization, checkbox,
        utm_source, utm_medium, utm_campaignid, utm_adgroupid, utm_creativeid, utm_matchtype,
        utm_device, utm_network, utm_keyword, utm_keywordid, utm_campaign,
        gad_source, gbraid, gclid, page_type
    ) VALUES (
        '$name', '$email', '$country_code', '$phone', '$state', '$city', '$programme', '$specialization', '$checkbox',
        '$utm_source', '$utm_medium', '$utm_campaignid', '$utm_adgroupid', '$utm_creativeid', '$utm_matchtype',
        '$utm_device', '$utm_network', '$utm_keyword', '$utm_keywordid', '$utm_campaign',
        '$gad_source', '$gbraid', '$gclid', '$website_url'
    )";

if ($conn->query($query) === TRUE) {
    include('inc/leads-api-call.php');
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>