<?php
// Set defaults.
if(!isset($attributes)){
    $attributesData = "";
}else{
    $attributesData = $attributes;
}
$post_tabs_param = wp_parse_args(
    $args,
    $attributesData
);

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$current_url = explode("/", $actual_link);
$parentCatSlug = $current_url[3]; //get from url index

$childCatSlug = $current_url[4]; //get lang from url index
$citySlug = isset($current_url[5])? $current_url[5] : '';
$cusomFieldTest = $parentCatSlug;
if ($childCatSlug == 'en') { //if lang en avail then check and concat
$citySlug = $current_url[6];
    $cusomFieldTest .= '-en';
    $centre =  'centre';
}else{
  $centre = $childCatSlug;
}
if($citySlug!=""){
	$citySlug = strtoupper($citySlug);
	if($citySlug == 'SYDNEY'){
	  $cusomFieldTest .="-sd";
	  $centre = '';
	}
	if($citySlug == 'MELBOURNE'){
	  $cusomFieldTest .="-ml";
	  $centre = '';
	}
	if($citySlug == 'HSINCHU'){
	  $cusomFieldTest .="-hs";
	  $centre = '';
	}
	if($citySlug == 'TAIPEI'){
	  $cusomFieldTest .="-tp";
	  $centre = '';
	}
}
$taxonomy = 'centre-district';

$enablemap = $post_tabs_param['enablelatestmap'];

if($centre == 'centre'){
if($parentCatSlug == 'tw' || $parentCatSlug == 'au'){
$singleposttaxo = get_the_terms( get_the_ID(), $taxonomy );
// $cusomFieldTest =  $singleposttaxo[1]->slug;
$filtered_terms = array();
foreach ($singleposttaxo as $term) {
    if ($term->parent == 0) {
        $filtered_terms[] = $term->slug;
    }
}
$cusomFieldTest =  $filtered_terms[0];
}
if($childCatSlug != 'en' && $parentCatSlug == 'tw'){
 $singleposttaxo = get_the_terms( get_the_ID(), $taxonomy );
 // $cusomFieldTest =  $singleposttaxo[0]->slug;
 $filtered_terms = array();
foreach ($singleposttaxo as $term) {
    if ($term->parent == 0) {
        $filtered_terms[] = $term->slug;
    }
}
$cusomFieldTest =  $filtered_terms[0];
}
}

global $post;
$postid = $post->ID;
if ($postid == 108974 OR $postid==108988) {
    if($postid == 108974) {
        $cusomFieldTest = "au-ml";
     } elseif ($postid == 108988) {
        $cusomFieldTest = "au-sd";
    } else {
        $cusomFieldTest = "au-sd";
    }
} elseif (in_array($postid, [109130, 109142, 109150, 109161, 109176])) {
    $cusomFieldTest = "sg";
} else {
    $cusomFieldTest =  $cusomFieldTest;
}

?>






<section class="latest_post_tabs_mv" data-location-setting="<?php echo $cusomFieldTest; ?>">
    <?php
    if ($enablemap == "yes") {
    ?>
        <div class="map-wrapper">
            <div class="wrap-map">
                <div class="map">
                    <div class="mapouter">
                        <div class="gmap_canvas">
                            <div id="map"></div>
                        </div>
                    </div>
                </div>
                <div class="placeholderLoader">
                    <div class="card_placeholders_mv">
                        <div class="row">
                            <div class="col-12">
                                <div class="placeholder_card map_loader"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }
    ?>
    <div class="container container_mv">
        <div class="tabs_head">
            <?php
            // $cats = get_categories($args);
            $parentTermId = get_term_by('slug', $cusomFieldTest, $taxonomy);
			if($parentTermId && !is_wp_error($parentTermId)){
				$categories = get_terms($taxonomy, array('hide_empty' => false, 'child_of' => $parentTermId->term_id));
				foreach ($categories as $category) {
					$langValue = get_field("district_country_code", $category);
					$cat_name = $category->name;
					$cat_slug = $category->slug;

					// if ($cat_name !== "Uncategorized") {
						// if ($cusomFieldTest == $langValue) {
				?>
							<button data-filter=".<?php echo $cat_slug; ?>" class="tab_button"><?php echo $cat_name; ?></button>
				<?php
						// }
					// }
				}
			}
            ?>

        </div>
        <div class="tabs_body">
            <?php
            $args = array(
                'post_type' => 'centre',
                'post_status' => 'publish',
                'posts_per_page' => '-1', //initially 8 post showing 
                'hide_empty' => false,
                'tax_query' => array(
                    array(
                        'taxonomy' => $taxonomy,
                        'field' => 'slug',
                        'terms' => isset($categories[0]->slug) ? $categories[0]->slug : array(),
                    )
                )
            );
            ?>
            <div class="body row">
                <?php $result = new WP_Query($args);
                
                if ($result->have_posts()) : ?>
                    <?php while ($result->have_posts()) : $result->the_post(); ?>

                        <?php
                        // $categories = get_the_category();
                        $taxonomy = 'centre-district';
                        $tax_terms = get_terms($taxonomy, array('hide_empty' => false));
                        $all_cats = "";
                        foreach ($tax_terms as $key => $category) {
                            $all_cats .= " " . $category->slug;
                        }

                        $location = get_field('location', get_the_ID());
                        $centre_badge = get_field('centre_badge', get_the_ID());
                        ?>

                        <div class="col-md-6 col-lg-4 col-xl-3 <?php echo $categories[0]->slug ?>">
                            <div class="tab_card">
                                <div class="img_box">
                                    <?php if(($centre_badge) && ($centre_badge != "d-none")){?> 
                                        <span class="post_badge <?php echo str_replace(' ', '-', $centre_badge); ?>">
                                            <?php echo $centre_badge;?>
                                        </span>
                                        <?php if(str_replace(' ', '-', $centre_badge) == 'Opening-Soon' || str_replace(' ', '-', $centre_badge) == 'New'){ ?>
                                        <b class="bottom_line"></b>
                                        <?php } ?>
                                    <?php } ?>
                                    <a href="<?php echo get_permalink(); ?>">
                                        <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="bike" />
                                    </a>
                                </div>
                                <div class="detail">
                                    <h4>
                                        <a href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a>
                                    </h4>
                                    <p>
                                        <?php
                                        if ($location) {
                                            echo $location;
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif;
                wp_reset_postdata(); ?>

            </div>

            <div class="placeholderLoader">
                <div class="card_placeholders_mv">
                    <div class="row">
                        <div class="col-md-6 col-lg-4 col-xl-3">
                            <div class="placeholder_card"></div>
                        </div>
                        <div class="col-md-6 col-lg-4 col-xl-3">
                            <div class="placeholder_card"></div>
                        </div>
                        <div class="col-md-6 col-lg-4 col-xl-3">
                            <div class="placeholder_card"></div>
                        </div>
                        <div class="col-md-6 col-lg-4 col-xl-3">
                            <div class="placeholder_card"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="not_found">
                <h4>Sorry! No posts found</h4>
            </div>
        </div>
    </div>

</section>
<?php
if ($result->have_posts()) :
    while ($result->have_posts()) : $result->the_post();

        $location = get_field('location', get_the_ID());

        $locationpost_ID = get_the_ID();

        $location_image = wp_get_attachment_image_src(get_post_thumbnail_id($locationpost_ID), 'single-post-thumbnail');
        $latitude_pins = get_field("latitude", $locationpost_ID);
        $longitude_pins = get_field("longitude", $locationpost_ID);

        $latitude_var = floatval($latitude_pins);
        $longitude_var = floatval($longitude_pins);
        $address = get_post_field('post_excerpt', $locationpost_ID); 
          // $address = trim($location);
          
        
       
        // $url = "https://maps.google.com/maps/api/geocode/json?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&address=" . str_replace(" ", "+", $address) . "&sensor=false";

        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // $responseJson = curl_exec($ch);
        // curl_close($ch);

        // $response = json_decode($responseJson);
        // if ($response->status == 'OK') {

            if ($latitude_pins != "" && $longitude_pins != "") {
                $latitude = $latitude_var;
                $longitude = $longitude_var;
            } else {
                // $latitude = $response->results[0]->geometry->location->lat;
                // $longitude = $response->results[0]->geometry->location->lng;
                $latitude = '';
                $longitude =  '';
            }

            $the_title = get_the_title();
            $positions[] = array(
                'name' => $the_title,
                'address' => $address,
                'image' => $location_image[0],
                'lat' => $latitude,
                'lng' => $longitude,
            );
        // }

    /* */

    endwhile;
endif;
wp_reset_postdata();

?>
<?php
if ($enablemap == "yes") {
?>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&callback=initMap&v=weekly" defer></script>
    <script>
        var positions = <?php echo json_encode(isset($positions) ? $positions : array()); ?>;
        var hs_show_map = true;
        tabs_map(positions);
    </script>
<?php } else {
?>
    <script>
        var hs_show_map = false;
    </script>
<?php } ?>