<?php if( have_rows('slider_images') ): ?>
  <section class="slider_sec img_slider">
  <!-- Swiper -->
  <div class="swiper mySwiper">
    <div class="swiper-wrapper">
      <?php while( have_rows('slider_images') ): the_row(); 
        $image = get_sub_field('slider_image');
        ?>
        <div class="swiper-slide">
          <div class="img_slide">
          <?php
            if( $image ){ ?>
                 <img
                  src="<?php echo $image['url']?>"
                  alt="<?php echo $image['alt']?>"
                  class="cover"
                />
          <?php } ?>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
    <div class="swiper_button_wrap">
      <button class="swiper_button swiper_button_next">
        <img
          src="<?php echo get_template_directory_uri(). '/assets/images/left_arrow.svg' ?>"
          alt=""
        />
      </button>
      <button class="swiper_button swiper_button_prev">
        <img
          src="<?php echo get_template_directory_uri(). '/assets/images/right_arrow.svg' ?>"
          alt=""
        />
      </button>
    </div>
  </div>
</section>
<?php endif; ?>