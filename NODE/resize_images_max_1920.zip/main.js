const sharp = require("sharp");
const fs = require("fs");
const path = require("path");
const recursive = require("recursive-readdir");

// List of supported image extensions
const supportedExtensions = [".png", ".jpg", ".jpeg", ".gif"];

// Function to resize image
async function resizeImage(inputFilePath, outputFilePath) {
  try {
    await sharp(inputFilePath)
      .resize({ width: 1920, withoutEnlargement: true }) // Max width of 1920px
      .toFile(outputFilePath);

    console.log(
      `Image resized successfully: ${inputFilePath} -> ${outputFilePath}`
    );
  } catch (err) {
    console.error(`Error resizing image: ${inputFilePath}`, err);
  }
}

// Function to process all images in the folder
async function processAllImagesInFolder(folderPath) {
  try {
    // Recursively read all files in the folder
    const files = await recursive(folderPath);

    // Filter files to only include supported image extensions
    const imageFiles = files.filter((file) =>
      supportedExtensions.includes(path.extname(file).toLowerCase())
    );

    // Process each image file
    for (let file of imageFiles) {
      const outputFilePath = path.join(
        path.dirname(file),
        "../output",
        path.basename(file)
      );

      // Ensure the "resized" directory exists
      const outputDir = path.dirname(outputFilePath);
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }

      // Resize the image and save to the "resized" folder
      await resizeImage(file, outputFilePath);
    }

    console.log("All images processed successfully!");
  } catch (err) {
    console.error("Error processing images:", err);
  }
}

// Call the function with the folder path you want to process
const inputFolderPath = "./input"; // Change this to your input folder path
processAllImagesInFolder(inputFolderPath);
