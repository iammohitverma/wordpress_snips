document.addEventListener("DOMContentLoaded", () => {
  // Get saved template from localStorage
  const saved = localStorage.getItem("gjs-saved-template");

  if (saved) {
    const { html, css } = JSON.parse(saved);

    // Inject CSS into a <style> tag in <head>
    const style = document.createElement("style");
    style.innerHTML = css;
    document.head.appendChild(style);

    // Inject saved HTML into the #frontend container
    const frontendContainer = document.getElementById("frontend");
    frontendContainer.innerHTML = html;
  }
});
