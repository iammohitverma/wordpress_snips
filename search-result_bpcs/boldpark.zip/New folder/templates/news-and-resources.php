<?php 
/*
Template Name: Community/News Resources
*/
get_header(); // Load the header template
?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('news_and_resources_page_section') ): 
    while( have_rows('news_and_resources_page_section') ): the_row(); 

if( get_row_layout() == 'banner_section' ): ?>
<section class="our_difference_newbanner bg_grey cmn_new_banner">
        <?php get_template_part( 'template-parts/sections/banner_inner_pages_new' ); ?>
</section>
<!-- Common banner secion inner pages  -->

<!-- 02 Section about difference Start-->
<?php
             elseif (get_row_layout() == 'upcoming_events') :
                $heading = get_sub_field('section_heading');
                $filter_heading = get_sub_field("filter_heading");
            ?>
            <section class="events_resources pt_extra inner_event_resources news_resource">
                <div class="container">
                    <div class="row">
                         <div class="col-12">
                            <div class="inner">
                                <h2 class="hdng"><?php echo $heading; ?></h2>
                                <h3 class="filter_hdng"><?php echo $filter_heading; ?></h3>
                                <div class="category">
                                <ul class="category_shape">
                                    <?php // display all categories for tabbing functionality
                                    $args = array(
                                        'child_of'                 => 0,
                                        'parent'                   => '',
                                        'order'                    => 'ASC',
                                        'orderby'   => 'order_clause',   
                                        'meta_query' => array(
                                            'order_clause' => array(
                                                'type'=> 'NUMERIC',
                                                'key' => 'category_order'
                                            )
                                        ),
                                      
                                        'hide_empty'               => 1,
                                        'hierarchical'             => 1,
                                        'taxonomy'                 => 'category',
                                        'pad_counts'               => false
                                    );
                                    $categories = get_categories($args);
                                    $cat_no = 1;
                                    foreach ($categories as $category) {
                                        $url = get_term_link($category);
                                        $bg_image = get_field('shape_image', 'category_'.$category->term_id);   
                                        $txt_color = get_field('text_color', 'category_'.$category->term_id);   
                                    ?>
                                <li>
                                    <a style="background-image: url('<?php echo $bg_image['url']; ?>'); color:<?php echo $txt_color; ?>"" href="javascript:void(0);"
                                        class="tab_item  tab_news_tm"
                                        data-newscatId="<?php echo $category->term_id; ?>"
                                        data-newscatName="<?php echo $category->name; ?>">
                                        <?php echo $category->name; ?>
                                    </a>
                                </li>
                                
                                <?php 
                                $cat_no++;
                                } ?>
                                </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row newsposts">
                        <?php 
                            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
                            $args = array(
                                'post_type'=> 'post',
                                'posts_per_page' => 6,
                                'paged' => $paged,
                                'post_status' => 'publish',
                            );              

                            $the_query = new WP_Query( $args );
                            if($the_query->have_posts() ) : 
                                while ( $the_query->have_posts() ) : 
                                $the_query->the_post(); 
                                $post_id = get_the_ID();
                                $thumbnail_url = '';
                                
                                if (has_post_thumbnail()) {
                                    $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                }

                                $eventTitle = get_the_title(); 
                                $eventExcerpt = get_the_excerpt();
                                $event_button = get_the_permalink();
                            ?>

                                    <div class="col-12 col-sm-6 col-lg-4 mt-4">
                                        <div class="card_main">
                                            <div class="img_main">
											   <?php if ( has_post_thumbnail() ) : ?>
												<figure><?php the_post_thumbnail(); ?></figure>
												<?php else : ?>
												<img src="/wp-content/uploads/2023/09/post_dummy.png" alt="post" />
											<?php endif; ?>
											</div>
                                            <div class="content_main">
                                                 <div class="top_cont">
													<p><?php echo get_the_date( 'F j, Y' ); ?></p>  

														<?php echo '<h3 class="card_hdng"> <a href="' . get_permalink() . '">' . get_the_title() . '</a> </h3> '; ?>
												</div>
												<div class="content_mid">
													<?php  echo '<p> ' . get_the_excerpt() . ' </p> '; ?>
												</div>
												<div class="read_more_btn">
													<a href="<?php echo $event_button; ?>" class="cmn_btn">Read more</a>
												</div> 
                                            </div>
                                        </div>
                                    </div>

                                <?php
                                // content goes here
                                endwhile; 
                                wp_reset_postdata(); 
                            else: 
                            endif;
                            echo '<div class="pagination">';
                            echo paginate_links( array(
                                'base'    => str_replace('%#%', esc_url(get_pagenum_link('%#%')), esc_url(get_pagenum_link(1))) . '%_%',
                                'format' => '?paged=%#%',
                                'current' => max( 1, get_query_var('paged') ),
                                'total' =>  $the_query->max_num_pages // Use $the_query->max_num_pages here
                            ));
                            echo '</div>';
                        ?>
                        </div>
                    </div>
                </div>
            </section>
<!-- 02 Section about difference end-->
<?php
        elseif( get_row_layout() == 'question_section' ): 
        ?>
<!-- Questions start-->
<section class="questions_sec without_animation fees_page">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->


<?php 
endif; 
     endwhile; 
    endif;
get_footer(); // Load the footer template ?>

<div class="loading_wrapper" style="display:none;">
    <div class="inner">
        <div class="lds-default">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>
