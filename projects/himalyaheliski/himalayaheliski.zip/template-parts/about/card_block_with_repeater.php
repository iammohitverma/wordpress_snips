<?php
$blocks = get_sub_field('blocks');
?>
<section class="common_list_grid pb_100">
    <div class="container">
        <?php if ($blocks):
            foreach ($blocks as $key => $block):
                $image = $block['image'];
                $content = $block['content'];
                ?>
                <div class="inner_wrap">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="img_wrapper">
                                <?php if ($image): ?>
                                    <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['url']; ?>">
                                <?php else: ?>
                                    <img src="https://placehold.co/400x300" alt="default">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <?php if ($content):
                                $title = $content['title'];
                                $content_box = $content['content_box'];
                                $link = $content['link'];
                                ?>
                                <div class="text_wrapper pl_50 pr_50">
                                    <?php if ($title): ?>
                                        <div class="heading_wrap">
                                            <h2 class="sec_heading"><?php echo $title; ?></h2>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($content_box): ?>
                                        <div class="content_editor_default">
                                            <?php echo $content_box; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php
                                    if ($link):
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                        ?>
                                        <a href="<?php echo $link_url; ?>" class="hl_btn text-uppercase"
                                            target="<?php echo $link_target; ?>"><?php echo $link_title; ?></a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
    </div>
</section>