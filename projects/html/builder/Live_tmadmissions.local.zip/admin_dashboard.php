<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: login");  // ya aapka login page ka URL
    exit;
}

// Agar yahan tak pahucha toh matlab login hai
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>
    2025 Admissions Open Now | Apply Online | Distance Learning
  </title>
  <link rel="icon" type="image/x-icon" href="./assets/images/favicon.ico" />

  <!-- bootstrap 5 -->
  <link rel="stylesheet" href="./assets/bootstrap-5.2.3-dist/css/bootstrap.min.css" />

  <!-- heebo font -->
  <link rel="stylesheet" href="./assets/fonts/heebo/stylesheet.css" />
  <!-- roboto font -->
  <link rel="stylesheet" href="./assets/fonts/roboto/stylesheet.css" />

  <!-- splitting -->
  <link rel="stylesheet" href="https://unpkg.com/splitting/dist/splitting.css" />
  <link rel="stylesheet" href="https://unpkg.com/splitting/dist/splitting-cells.css" />

  <!-- aos animation -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- Grapes css -->
  <link rel="stylesheet" href="https://unpkg.com/grapesjs/dist/css/grapes.min.css" />

  <!-- Font awesome css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <!-- custom style -->
  <link rel="stylesheet" href="./assets/css/custom_style.css" />
</head>

<body>

<div class="preloader show">
  <img src="./assets/images/loader.gif" alt="">
</div>

<div class="state_loader">
  <img src="./assets/images/loader.gif" alt="">
</div>

  <div id="gjs"></div>


  <!-- jQuery 3.7.1 -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

  <!-- tilt js -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js"></script>

  <!-- split text script -->
  <script src="https://unpkg.com/splitting/dist/splitting.min.js"></script>

  <!-- aos script -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

  <!-- grapes js -->
  <script src="https://unpkg.com/grapesjs"></script>
  <!-- grapes js blocks -->
  <script src="https://unpkg.com/grapesjs-blocks-basic"></script>

  <!-- custom script -->
  <script src="./assets/js/custom_script.js"></script>

  <!-- grapes js builder init js -->
  <script src="./assets/js/grapes_init.js"></script>

</body>

</html>