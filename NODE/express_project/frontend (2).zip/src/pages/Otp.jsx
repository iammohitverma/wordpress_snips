import React from 'react'
import Comm1 from '../components/Otp/Comm1'

const Otp = () => {
  return (
    <div>
      <Comm1 />
    </div>
  )
}

export default Otp
