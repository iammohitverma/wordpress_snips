<?php
/**
 * Template when no post found in selected category/tags/author/date/month/day
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package projectx-theme
 */

?>

<div>
    <h5 style="text-align:center">Not Found</h5>
</div>


