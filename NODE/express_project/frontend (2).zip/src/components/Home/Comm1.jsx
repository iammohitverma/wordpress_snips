import React, { useEffect, useState } from "react";
import { AiOutlineFire } from "react-icons/ai";
import axiosinstance from "../../api/axiosinstance";
import { Link, useNavigate } from "react-router-dom";

const IconPlay = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <polygon points="5 3 19 12 5 21 5 3" />
    </svg>
);

const IconFire = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <path d="M12 2s-4 5 0 11c0 0-5-1-5-7s5-7 5-7z" />
        <path d="M12 2s4 5 0 11c0 0 5-1 5-7s-5-7-5-7z" />
    </svg>
);

const IconCheckCircle = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <circle cx="12" cy="12" r="10" />
        <polyline points="9 12 12 15 22 9" />
    </svg>
);

const IconChartLine = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <polyline points="3 17 9 11 13 15 21 7" />
        <line x1="21" y1="7" x2="21" y2="17" />
    </svg>
);

const IconUser = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <circle cx="12" cy="7" r="4" />
        <path d="M5.5 21a8.38 8.38 0 0 1 13 0" />
    </svg>
);

const IconLogout = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <polyline points="16 17 21 12 16 7" />
        <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
);

const IconUpgrade = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <path d="M12 19v-6m0 0V5m0 8H9m3 0h3" />
    </svg>
);

const IconFlameOutline = ({ className }) => (
    <svg
        className={className}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        viewBox="0 0 24 24"
    >
        <path d="M12 2C7 7 8 13.5 12 17s5-3 5-5A7 7 0 0 0 12 2z" />
    </svg>
);

function Comm1() {
    const [tests, setTests] = useState({
        inProgress: 0,
        readyToBurn: 0,
        completed: 0,
        totalQuota: 1,
        usedQuota: 0,
    });
    const [recentTests, setRecentTests] = useState([]);

    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const email = localStorage.getItem('email');
    const userEmail = localStorage.getItem('email');
    const [count, setcount] = useState(null)

    useEffect(() => {
        if (!email) {
            navigate('/');
            return
        }

        const fetchUser = async () => {
            try {
                const res = await axiosinstance.get('/api/auth/me', {
                    params: { email }
                });
                setUser(res.data);
                console.log(res.data)
            } catch (err) {
                console.error(err.response?.data?.message);
                navigate('/');
            }
        };

        fetchUser();
    }, [email, navigate]);

    
        useEffect(() => {
            if (userEmail) {
                axiosinstance.get(`/api/test/get-tests/${userEmail}`)
                    .then(res => {
                        setcount(res.data.length)
                    })
                    .catch(err => {
                        console.error('Error fetching test data:', err);
                    });
            }
        }, [userEmail]);

    if (!user) return <p>Loading...</p>;

    const LogOutHandler = async (e) => {
        e.preventDefault();
        localStorage.removeItem('email');
        navigate('/');
    }

    return (
        <div className="min-h-screen bg-gradient-to-b from-orange-100 to-orange-50 text-amber-900 font-sans flex flex-col">
            <header className="bg-white border-b border-amber-300 shadow-sm sticky top-0 z-50">
                <nav className="container mx-auto px-4 flex items-center justify-between h-16">
                    <div className="flex flex-col items-center space-x-2">
                        <div className="flex items-center text-amber-800">
                            {/* Flame icon with gradient */}
                            <AiOutlineFire />
                            <span className="font-extrabold text-lg select-none ml-1">
                                Candle Burn-Test Log
                            </span>
                        </div>
                        <span className="text-xs text-amber-600 select-none font-light">
                            Professional candle testing made simple
                        </span>
                    </div>

                    <div className="flex items-center space-x-4 text-xs">
                        <div className="hidden md:flex items-center space-x-2 bg-amber-100 border border-amber-300 rounded-full py-1 px-3 cursor-default select-none">
                            <span className="uppercase text-amber-600 font-semibold tracking-wider">
                                Free
                            </span>
                        </div>
                        <button
                            type="button"
                            aria-label="Upgrade Account"
                            className="flex items-center space-x-1 bg-amber-700 hover:bg-amber-800 transition-colors rounded-full py-1 px-3 text-white font-medium"
                        >
                            <IconUpgrade className="w-4 h-4" />
                            <span>Upgrade</span>
                        </button>
                        <div className="hidden md:flex items-center text-amber-800 font-semibold">
                            <span>
                                {count}/{tests.totalQuota} tests
                            </span>
                        </div>
                        <button
                            type="button"
                            aria-label="User Profile"
                            className="flex items-center space-x-1 text-amber-700 hover:text-amber-900 transition-colors"
                        >
                            <IconUser className="w-5 h-5" />
                            <span className="hidden md:inline-block">{user.name}</span>
                        </button>
                        <button
                            type="button"
                            onClick={LogOutHandler}
                            aria-label="Logout"
                            className="text-amber-600 hover:text-amber-800 transition-colors"
                            title="Logout"
                        >
                            <IconLogout className="w-5 h-5" />
                        </button>
                    </div>
                </nav>

                <div className="bg-white border-t border-amber-300 shadow-sm">
                    <nav className="container mx-auto px-4 flex text-sm font-semibold text-amber-800 leading-none select-none overflow-x-auto">
                        <Link to={'/home'} className="px-4 py-3 border-b-4 border-amber-600 text-amber-900 whitespace-nowrap">
                            Dashboard
                        </Link>
                        <Link to={"/logs"} className="px-4 py-3 border-b-4 border-transparent hover:border-amber-400 whitespace-nowrap">
                            My Logs
                        </Link>
                        <Link to={'/upgrade'} className="px-4 py-3 border-b-4 border-transparent hover:border-amber-400 whitespace-nowrap">
                            Upgrade
                        </Link>
                    </nav>
                </div>
            </header>

            <main className="container mx-auto px-4 py-4 flex-grow">
                <section className="bg-white text-amber-900 px-6 py-4 rounded-md shadow flex flex-col md:flex-row md:items-center md:justify-between gap-3 select-none">
                    <div>
                        <h2 className="font-semibold text-lg md:text-xl">Welcome back, {user.name}!</h2>
                        <p className="text-sm md:text-base mt-1">
                            Track your candle burn tests with precision and ease
                        </p>
                    </div>
                    <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1 text-amber-700 font-semibold cursor-default select-none">
                            <IconFire className="w-5 h-5" />
                            <span>Keep testing!</span>
                        </div>
                        <Link to={"/home/test-1"}
                            type="button"
                            className="bg-amber-700 hover:bg-amber-800 transition-colors text-white font-semibold py-2 px-5 rounded shadow-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2"
                        >
                            New Test
                        </Link>
                    </div>
                </section>

                <section className="my-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5 select-none">
                    <div className="flex justify-between bg-white shadow-md rounded-md p-5 border border-transparent hover:border-amber-300 cursor-pointer transition-colors">
                        <div>
                            <p className="text-2xl font-extrabold text-amber-900">{tests.inProgress}</p>
                            <p className="text-xs text-amber-600 mt-1">Tests in Progress</p>
                        </div>
                        <div className="flex items-center justify-center w-10 h-10 bg-amber-100 text-amber-700 rounded-xl">
                            <IconPlay className="w-6 h-6" />
                        </div>
                    </div>

                    <div className="flex justify-between bg-amber-50 shadow-md rounded-md p-5 border-amber-300 border cursor-pointer transition-colors">
                        <div>
                            <p className="text-2xl font-extrabold text-amber-900">{tests.readyToBurn}</p>
                            <p className="text-xs text-amber-600 mt-1">Ready to Burn</p>
                        </div>
                        <div className="flex items-center justify-center w-10 h-10 bg-amber-200 text-amber-700 rounded-xl">
                            <IconFire className="w-6 h-6" />
                        </div>
                    </div>

                    <div className="flex justify-between bg-white shadow-md rounded-md p-5 border border-transparent hover:border-amber-300 cursor-pointer transition-colors">
                        <div>
                            <p className="text-2xl font-extrabold text-amber-900">{count}</p>
                            <p className="text-xs text-amber-600 mt-1">Completed Tests</p>
                        </div>
                        <div className="flex items-center justify-center w-10 h-10 bg-green-100 text-green-700 rounded-xl">
                            <IconCheckCircle className="w-6 h-6" />
                        </div>
                    </div>

                    <div className="flex justify-between bg-white shadow-md rounded-md p-5 border border-transparent hover:border-amber-300 cursor-default transition-colors">
                        <div>
                            <p className="text-2xl font-extrabold text-amber-900">
                                {count}/{tests.totalQuota}
                            </p>
                            <p className="text-xs text-amber-600 mt-1">Tests Used</p>
                        </div>
                        <div className="flex items-center justify-center w-10 h-10 bg-yellow-100 text-yellow-700 rounded-xl">
                            <IconChartLine className="w-6 h-6" />
                        </div>
                    </div>
                </section>

                <section className="bg-white rounded-md shadow-md p-6 mt-6 min-h-[18rem] flex flex-col">
                    <h3 className="text-amber-900 font-semibold text-lg mb-4 select-none">Recent Tests</h3>
                    {count === 0 ? (
                        <div className="flex flex-col items-center justify-center flex-grow text-amber-400 select-none">
                            <IconFlameOutline className="w-12 h-12 mb-4" />
                            <p className="font-semibold text-lg mb-1">No burn tests yet</p>
                            <p className="max-w-xs text-center text-sm leading-relaxed">
                                Get started by creating your first burn test.
                            </p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto -mx-6 px-6">
                           <button>Show Logs</button>
                        </div>
                    )}
                </section>
            </main>

            <footer className="text-center text-amber-700 py-4 select-none text-xs bg-amber-50 border-t border-amber-300">
                © 2024 Candle Burn-Test Log. All rights reserved.
            </footer>
        </div>
    );
}

export default Comm1;


