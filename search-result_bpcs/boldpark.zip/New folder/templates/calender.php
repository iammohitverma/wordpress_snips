<?php 
/*
Template Name: Community/Calender
*/
get_header(); // Load the header template
?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('calendar_page_section') ): 
    while( have_rows('calendar_page_section') ): the_row(); 

if( get_row_layout() == 'banner' ): 
 $parent_pageId = wp_get_post_parent_id(get_the_ID());
$parent_page = get_the_title($parent_pageId);
$parent_page_url = get_the_permalink($parent_pageId);
 $page_title = $wp_query->post->post_title; 
 $banner_heading = get_sub_field('banner_heading');
 $banner_description = get_sub_field('banner_description');
 $banner_img = get_sub_field('banner_image');

?>
<section class="app_process_banner bg_grey">
    <div class="banner_main">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="banner_left">
                        <div class="breadcrumbs">
                            <ul>
                                <?php if($parent_pageId != 0){ ?>
                                        <li>
                                            <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                                        </li>
                                        <?php } ?>
                                        <li>
                                            <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                                        </li>
                            </ul>
                        </div>
                        <div class="banner_headings">
                            <h2 class="banner_mainheading sec_title_90"><?php echo$banner_heading; ?></h2>
                            <p><?php echo$banner_description; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="banner_right">
                        <img src="<?php echo$banner_img['url']; ?>">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="banner_links">
                        <?php get_template_part( 'template-parts/sections/banner_links' ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php
    elseif( get_row_layout() == 'question' ):
	
	$sub_section_heading = get_sub_field('sub_section_heading');
    $iframe_link = get_sub_field("iframe_link");
    // var_dump($iframe_link['url']);
?>
<section class="calenderBox">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="hdng">
                    <?php echo $sub_section_heading; ?>
                </h2>
                <?php if($iframe_link){
                    $link_url = $iframe_link["url"];
                    ?>
                        <div class="bpcs_calander">
                            <!-- <img src="/wp-content/uploads/2023/08/calender.png" alt=""> -->
                            <iframe src="<?php echo esc_url( $link_url ); ?>" style="border: 0" width="700" height="600" frameborder="0" scrolling="no"></iframe>
                        </div>
                    <?php
                } ?>
            </div>
        </div>
    </div>
</section>

<!-- Questions start-->
<section class="questions_sec without_animation fees_page">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->


<?php
endif; 
     endwhile; 
    endif;
    get_footer(); // Load the footer template ?>
