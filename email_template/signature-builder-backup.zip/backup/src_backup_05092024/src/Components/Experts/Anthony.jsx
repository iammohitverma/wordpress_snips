export const Anthony = () => {
  return (
    <>
      <table width="600" align="start" cellSpacing="0" cellPadding="0">
        <tbody>
          <tr>
            <td
            // style={{
            //   background:
            //     "url('https://apps.okmg.com/client_signatures/cpa-signature/static/images/email_shape_600_400_2.png') no-repeat left 90% / cover",
            // }}
            >
              <table
                width="100%"
                align="start"
                cellSpacing="0"
                cellPadding="0"
                style={{ backgroundColor: "#30526d" }}
              >
                <tbody>
                  <tr>
                    <td>
                      <table
                        align="start"
                        width="600"
                        style={{
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "200px",
                                textAlign: "right",
                                padding: "20px 30px",
                              }}
                            >
                              <img
                                src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/anthony_rizzacasa_140.png"
                                alt=""
                                style={{
                                  width: "140px",
                                  height: "140px",
                                }}
                              />
                            </td>
                            <td
                              style={{
                                width: "400px",
                                verticalAlign: "middle",
                                padding: "20px 30px",
                                paddingLeft: "30px",
                              }}
                            >
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "22px",
                                  fontWeight: "600",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "1px",
                                }}
                              >
                                Anthony Rizzacasa
                              </p>
                              <div
                                style={{
                                  marginBottom: "7px",
                                }}
                              ></div>
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#ec6563",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                  marginBottom: "3px",
                                }}
                              >
                                Senior Development Manager
                              </p>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "300px",
                                verticalAlign: "top",
                                padding: "20px 0 0 30px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td>
                                      <p>
                                        <a
                                          href="tel: 0403 359 733
"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/mobile.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          0403 359 733
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="tel:08 9323 0000"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/telephone.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          1300 CAPITAL
                                        </a>
                                      </p>

                                      <p>
                                        <a
                                          href="mailto: anthony@cpadvisory.com.au"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                            wordBreak: "break-all",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/email.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          anthony@cpadvisory.com.au
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="https://cpadvisory.com.au/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/globe.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          cpadvisory.com.au
                                        </a>
                                      </p>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td
                              style={{
                                width: "300px",
                                textAlign: "right",
                                paddingRight: "30px",
                                paddingTop: "20px",
                              }}
                            >
                              <a
                                href="https://www.cpadvisory.com.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  paddingTop: "0px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.jpg"
                                  alt=""
                                  style={{
                                    width: "200px",
                                  }}
                                />
                              </a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tbody>
                            <tr>
                              <td
                                style={{
                                  padding: "0px 30px",
                                  width: "600px",
                                  paddingTop: "20px",
                                }}
                              >
                                <table>
                                  <tbody>
                                    <tr>
                                      <td>
                                        <p>
                                          <a
                                            href="https://www.instagram.com/capitalpropertyadvisory/"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{
                                              display: "inline-block",
                                              marginLeft: "0",
                                              marginRight: "0",
                                            }}
                                          >
                                            <img
                                              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/instagram.png"
                                              alt=""
                                              style={{
                                                width: "30px",
                                                height: "20px",
                                                objectFit: "contain",
                                              }}
                                            />
                                          </a>
                                          <a
                                            href="https://www.facebook.com/capitalpropertyadvisory/"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{
                                              display: "inline-block",
                                              marginRight: "0",
                                            }}
                                          >
                                            <img
                                              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/facebook.png"
                                              alt=""
                                              style={{
                                                width: "30px",
                                                height: "20px",
                                                objectFit: "contain",
                                              }}
                                            />
                                          </a>
                                          <a
                                            href="https://au.linkedin.com/company/capital-property-advisory/"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{
                                              display: "inline-block",
                                              marginRight: "0",
                                            }}
                                          >
                                            <img
                                              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/linkedin.png"
                                              alt=""
                                              style={{
                                                width: "30px",
                                                height: "20px",
                                                objectFit: "contain",
                                              }}
                                            />
                                          </a>
                                          <a
                                            href="https://open.spotify.com/show/02cyiNPOIIRRXCzCaDcP2g?si=37d97901349f493b&nd=1&dlsi=158951d90f264278"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{
                                              display: "inline-block",
                                              marginRight: "0",
                                            }}
                                          >
                                            <img
                                              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/spotify.png"
                                              alt=""
                                              style={{
                                                width: "30px",
                                                height: "20px",
                                                objectFit: "contain",
                                              }}
                                            />
                                          </a>
                                        </p>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td
                                style={{
                                  padding: "10px 30px",
                                  width: "600px",
                                  paddingTop: "20px",
                                }}
                              >
                                <a
                                  href="http://rebaa.com.au/"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  style={{
                                    display: "inline-block",
                                    marginLeft: "5px",
                                  }}
                                >
                                  <img
                                    src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/rebaa.jpg"
                                    alt=""
                                    style={{
                                      width: "auto",
                                      height: "40px",
                                      objectFit: "contain",
                                    }}
                                  />
                                </a>
                                <a
                                  href="https://www.pipa.asn.au/"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  style={{
                                    display: "inline-block",
                                    marginLeft: "5px",
                                  }}
                                >
                                  <img
                                    src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/pipa.jpg"
                                    alt=""
                                    style={{
                                      width: "auto",
                                      height: "40px",
                                      objectFit: "contain",
                                    }}
                                  />
                                </a>
                                <a
                                  href="https://www.pipa.asn.au/qualified-property-investment-adviser-property-investment-adviser/"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  style={{
                                    display: "inline-block",
                                    marginLeft: "5px",
                                  }}
                                >
                                  <img
                                    src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/qpia.jpg"
                                    alt=""
                                    style={{
                                      width: "auto",
                                      height: "40px",
                                      objectFit: "contain",
                                    }}
                                  />
                                </a>
                                <a
                                  href="https://members.reiwa.com.au/s/"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  style={{
                                    display: "inline-block",
                                    marginLeft: "5px",
                                  }}
                                >
                                  <img
                                    src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/reiwa.jpg"
                                    alt=""
                                    style={{
                                      width: "auto",
                                      height: "40px",
                                      objectFit: "contain",
                                    }}
                                  />
                                </a>
                              </td>
                            </tr>
                          </tbody>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};
