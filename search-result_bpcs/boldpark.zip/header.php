<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package boldpark-theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-Q92LWDY95B"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-Q92LWDY95B');
	</script>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> data-pageId="<?php echo get_the_id() ?>">
    <?php wp_body_open(); ?>
    <div class="loader">

    </div>
    <div id="page-<?php echo sanitize_title_with_dashes(get_the_title()); ?>" class="site">
      
    <!-- header -->
    <header>
         <!-- Search form mobile-->
         <div class="search_form_wrap mobile">
            <div class="container">
                <div class="row">
                    <div class="col-12 mx-auto">
                        <?php echo get_search_form();?>
                    </div>
                </div>
            </div>
        </div>
        <div class="topbar">
            <div class="container-fluid">
                <div class="inner">
                    <p>
                        <?php echo get_theme_mod( 'topbar_text' ); ?>
                    </p>
                    <?php 
                        $checkStatus = get_theme_mod( 'topbar_close_btn_hide_show' ); 
                        if($checkStatus == "yes") {
                            ?>
                                <button class="close-topbar"></button>
                            <?php
                        }
                    ?>
                </div>
            </div>
        </div>
        <div class="main-header">
            <div class="container">
                <div class="inner">
                    <div class="logoBx">                                        
                        <?php 
                            $custom_logo_id = get_theme_mod( 'custom_logo' );
                            $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                            
                            //   if logo image does'nt exist call site title and tagline
                            if ( has_custom_logo() ) {
                                the_custom_logo();
                            } else {?>
                                <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
                                <!-- <p><?php bloginfo('description'); ?></p> -->
                            <?php
                            }
                        ?>
                    </div>
                    <div class="right">
                        <div class="primary-top-menu-wrap">
                            <?php
                                wp_nav_menu(  array(
                                    'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                    'theme_location'    => "primary_top_menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                    'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                    'after'                => '</div>', // (string) Text after the link text.
                                ) );
                            ?>

                            <div class="searcIcon_hdr desktop">
                                <svg class="icon" width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.4525 13.8593L15.4107 13.8179C16.4759 12.4588 17.1114 10.7536 17.1114 8.90386C17.1114 4.47221 13.4634 0.869824 8.99785 0.869824C4.53229 0.869824 0.884285 4.47221 0.884285 8.90386C0.884285 13.3355 4.53229 16.9379 8.99785 16.9379C10.7414 16.9379 12.3603 16.3887 13.6861 15.4554L13.7703 15.5387L13.9556 15.7221C12.5592 16.719 10.8464 17.3077 8.99785 17.3077C4.31329 17.3077 0.5 13.5267 0.5 8.90386C0.5 4.28097 4.31329 0.5 8.99785 0.5C13.6824 0.5 17.4957 4.28097 17.4957 8.90386C17.4957 10.8543 16.8169 12.6548 15.6803 14.0848L15.4525 13.8593ZM15.4505 15.7946C15.5431 15.7095 15.634 15.6226 15.7232 15.534L22.2892 22.0314L22.0212 22.2966L15.4505 15.7946Z" fill="#1E1E1E" stroke="#1E1E1E"/>
                                </svg>
                                
                                <svg class="close"  width="23" height="23" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.8614 6.02249L10.8839 9.99997L14.8614 13.9774L13.9775 14.8613L10 10.8839L6.02252 14.8613L5.13864 13.9774L9.11612 9.99997L5.13864 6.02249L6.02252 5.13861L10 9.11608L13.9775 5.13861L14.8614 6.02249Z" fill="#1F1F1F"/>
                                </svg>
                            </div>
                            <!-- Search form -->
                            <div class="search_form_wrap desktop">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 p-0 mx-auto">
                                            <?php /* echo get_search_form(); */?>
                                            <?php include get_template_directory() . "/searchform.php";?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="primary-menu-bottom">
                            <div class="primary-menu-wrap">
                                <?php
                                    wp_nav_menu(  array(
                                        'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                        'theme_location'    => "primary_menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in order to be selectable by the user.
                                        'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                        'after'                => '</div>', // (string) Text after the link text.
                                    ) );
                                ?>
                            </div>

                            <!-- Book a tour button -->
                            <a href=" <?php echo get_theme_mod( 'header_tour_button_url' ); ?>" class="header-btn blue">
                                <?php echo get_theme_mod( 'header_tour_button_text' ); ?>
                            </a>
                            
                            <!-- Mega menu toggle button -->
                            <button class="mega-menu-toggle">
                                <i class="icon hamburger">
                                    <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-open.svg' alt="hamburger"/>
                                </i>
                                <i class="icon hamburger close">
                                    <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-closed.svg' alt="hamburger"/>
                                </i>
                            </button>

                            <div class="searcIcon_hdr mobile">
                                <svg class="icon" width="20" height="20" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.4525 13.8593L15.4107 13.8179C16.4759 12.4588 17.1114 10.7536 17.1114 8.90386C17.1114 4.47221 13.4634 0.869824 8.99785 0.869824C4.53229 0.869824 0.884285 4.47221 0.884285 8.90386C0.884285 13.3355 4.53229 16.9379 8.99785 16.9379C10.7414 16.9379 12.3603 16.3887 13.6861 15.4554L13.7703 15.5387L13.9556 15.7221C12.5592 16.719 10.8464 17.3077 8.99785 17.3077C4.31329 17.3077 0.5 13.5267 0.5 8.90386C0.5 4.28097 4.31329 0.5 8.99785 0.5C13.6824 0.5 17.4957 4.28097 17.4957 8.90386C17.4957 10.8543 16.8169 12.6548 15.6803 14.0848L15.4525 13.8593ZM15.4505 15.7946C15.5431 15.7095 15.634 15.6226 15.7232 15.534L22.2892 22.0314L22.0212 22.2966L15.4505 15.7946Z" fill="#1E1E1E" stroke="#1E1E1E"/>
                                </svg>
                                
                                <svg class="close"  width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.8614 6.02249L10.8839 9.99997L14.8614 13.9774L13.9775 14.8613L10 10.8839L6.02252 14.8613L5.13864 13.9774L9.11612 9.99997L5.13864 6.02249L6.02252 5.13861L10 9.11608L13.9775 5.13861L14.8614 6.02249Z" fill="#1F1F1F"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mega-menu-wrap">
            <div class="top">
                <div class="container">
                    <div class="inner">
                        <div class="primary-top-menu-wrap">
                            <?php
                                wp_nav_menu(  array(
                                    'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                    'theme_location'    => "primary_top_menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                    'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                    'after'                => '</div>', // (string) Text after the link text.
                                ) );
                            ?>
                        </div>
                        <div class="primary-mega-menu-wrap">
                            <button class="mega-menu-toggle">
                                <i class="icon hamburger">
                                    <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-open.svg' alt="hamburger"/>
                                </i>
                                <i class="icon hamburger close">
                                    <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-closed.svg' alt="hamburger"/>
                                </i>
                            </button>
                            <div class="mega-menu-mobile-header">
                                <div class="inner">
                                    <div class="logoBx">                                        
                                        <?php 
                                            $custom_logo_id = get_theme_mod( 'custom_logo' );
                                            $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                            
                                            //   if logo image does'nt exist call site title and tagline
                                            if ( has_custom_logo() ) {
                                                the_custom_logo();
                                            } else {?>
                                                <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
                                                <!-- <p><?php bloginfo('description'); ?></p> -->
                                            <?php
                                            }
                                        ?>
                                    </div>
                                    <button class="mega-menu-toggle">
                                        <i class="icon hamburger">
                                            <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-open.svg' alt="hamburger"/>
                                        </i>
                                        <i class="icon hamburger close">
                                            <img src='/wp-content/themes/boldpark/assets/images/hamburger-menu-closed.svg' alt="hamburger"/>
                                        </i>
                                    </button>
                                </div>
                            </div>
                            <div class="inner">
                                <!-- <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_one", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_one", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_two", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_three", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_four", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_five", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "mega_menu_six", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div> -->
                                <div class="col-menu">
                                    <?php
                                        wp_nav_menu(  array(
                                            'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                            'theme_location'    => "primary_menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                            'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                            'after'                => '</div>', // (string) Text after the link text.
                                        ) );
                                    ?>
                                </div>
                            </div>
                            <div class="mobile-btn">
                                <a
                                href="<?php echo get_theme_mod( 'header_megamenu_content_button_url' ); ?>"
                                class="header-btn black outline">
                                    <?php echo get_theme_mod( 'header_megamenu_content_button_text' ); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mega-menu-visit-us">
                <div class="container">
                    <div class="content">
                        <h2><?php echo get_theme_mod('header_megamenu_content_heading' ); ?></h2>
                        <p><?php echo get_theme_mod( 'header_megamenu_content_para' ); ?></p>
                        <!-- Book a tour button -->
                        <a
                         href="<?php echo get_theme_mod( 'header_megamenu_content_button_url' ); ?>"
                         class="header-btn black outline">
                            <?php echo get_theme_mod( 'header_megamenu_content_button_text' ); ?>
                        </a>
                    </div>
                </div>
            </div>
            <div class="mobile-links-wrap">
                <div class="container">
                    <div class="primary-top-menu-wrap">
                        <?php
                            wp_nav_menu(  array(
                                'container'         => "nav", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
                                'theme_location'    => "primary_top_menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in 
                                'before'               => '<div class="a-Wrap">', // (string) Text before the link text.
                                'after'                => '</div>', // (string) Text after the link text.
                            ) );
                    ?>
                    </div>
            </div>
           </div>
        </div>
    </header>

