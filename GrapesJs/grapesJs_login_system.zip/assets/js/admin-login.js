var username, password;
function onPageLoad() {
  const editor = window.editor;
  const myModal = new bootstrap.Modal("#loginModal", {
    keyboard: false,
    backdrop: "static", // Prevent clicking outside
  });
  myModal.hide();

  //   fetch from db
  function verifyAdmin(username, password) {
    const userRef = firebase.database().ref("admin/");
    userRef.once("value").then((snapshot) => {
      const data = snapshot.val();
      console.log(data);

      if (
        data &&
        username === data.credentials.username &&
        password === data.credentials.password
      ) {
        // // ✅ Hide the modal
        document.activeElement.blur(); // ✅ Prevents aria-hidden + focus conflict
        myModal.hide();

        // save credentials in localStorage for automatic future login
        const credentialsString = JSON.stringify({ username, password });
        localStorage.setItem("credentials", credentialsString);

        // get data from db and set to editor
        const { html, css } = data.builderData;

        if (html || css) {
          editor.setComponents(html);
          editor.setStyle(css);
        }
      } else {
        alert("Invalid username or password!");
      }
    });
  }
  /**************************************************/
  // Login form submit
  /**************************************************/
  let loginForm = document.getElementById("loginForm");
  function onSubmit(e) {
    e.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    verifyAdmin(username, password);
  }
  loginForm.addEventListener("submit", onSubmit);

  /*********************************/

  // Optional: Load saved credentials from local storage✅
  const credentials = localStorage.getItem("credentials");
  if (credentials) {
    const credentialsObj = JSON.parse(credentials);
    if (credentialsObj) {
      const { username, password } = credentialsObj;
      verifyAdmin(username, password);
    }
  } else {
    myModal.show();
  }
  /*********************************/

  /**************************************************/
  // Get data from firebase realtime database for edit📥
  /**************************************************/
  //   const userRef = firebase.database().ref("admin/builderData");
  //   userRef.once("value").then((snapshot) => {
  //     const data = snapshot.val();

  //     if (data) {
  //       const { html, css } = data;
  //       if (html || css) {
  //         const style = document.createElement("style");
  //         style.innerHTML = css;
  //         document.head.appendChild(style);

  //         const frontendContainer = document.getElementById("frontend");
  //         frontendContainer.innerHTML = html;
  //       }
  //     }
  //   });
}

window.addEventListener("load", onPageLoad);
