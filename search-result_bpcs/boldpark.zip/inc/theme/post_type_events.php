<?php
// Register Custom Post Type Events
function create_events_cpt() {

	$labels = array(
		'name' => _x( 'Events', 'Post Type General Name', 'boldpark' ),
		'singular_name' => _x( 'Events', 'Post Type Singular Name', 'boldpark' ),
		'menu_name' => _x( 'Events', 'Admin Menu text', 'boldpark' ),
		'name_admin_bar' => _x( 'Events', 'Add New on Toolbar', 'boldpark' ),
		'archives' => __( 'Events Archives', 'boldpark' ),
		'attributes' => __( 'Events Attributes', 'boldpark' ),
		'parent_item_colon' => __( 'Parent Events:', 'boldpark' ),
		'all_items' => __( 'All Events', 'boldpark' ),
		'add_new_item' => __( 'Add New Events', 'boldpark' ),
		'add_new' => __( 'Add New', 'boldpark' ),
		'new_item' => __( 'New Events', 'boldpark' ),
		'edit_item' => __( 'Edit Events', 'boldpark' ),
		'update_item' => __( 'Update Events', 'boldpark' ),
		'view_item' => __( 'View Events', 'boldpark' ),
		'view_items' => __( 'View Events', 'boldpark' ),
		'search_items' => __( 'Search Events', 'boldpark' ),
		'not_found' => __( 'Not found', 'boldpark' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'boldpark' ),
		'featured_image' => __( 'Featured Image', 'boldpark' ),
		'set_featured_image' => __( 'Set featured image', 'boldpark' ),
		'remove_featured_image' => __( 'Remove featured image', 'boldpark' ),
		'use_featured_image' => __( 'Use as featured image', 'boldpark' ),
		'insert_into_item' => __( 'Insert into Events', 'boldpark' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Events', 'boldpark' ),
		'items_list' => __( 'Events list', 'boldpark' ),
		'items_list_navigation' => __( 'Events list navigation', 'boldpark' ),
		'filter_items_list' => __( 'Filter Events list', 'boldpark' ),
	);
	$args = array(
		'label' => __( 'Events', 'boldpark' ),
		'description' => __( '', 'boldpark' ),
		'labels' => $labels,
		'menu_icon' => 'dashicons-admin-post',
		'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'author'),
		'taxonomies' => array( 'category' ),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => true,
		'has_archive' => true,
		'hierarchical' => false,
		'exclude_from_search' => false,
		'show_in_rest' => true,
		'publicly_queryable' => true,
		'capability_type' => 'post',
	);
	register_post_type( 'events', $args );

}
add_action( 'init', 'create_events_cpt', 0 );