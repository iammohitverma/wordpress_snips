<?php 
/*
Template Name: Enrolment Page
*/
get_header(); // Load the header template
?>
<?php if( have_rows('enrolment_page_sections') ): ?>
    <?php while( have_rows('enrolment_page_sections') ): the_row(); 

if( get_row_layout() == 'banner_section' ):
$page_title = $wp_query->post->post_title; ?>
<section class="our_difference_newbanner bg_grey cmn_new_banner">
        <?php  get_template_part( 'template-parts/sections/banner_inner_pages_new' ); ?>
</section>
<!-- Common banner secion inner pages  -->
<?php 
elseif( get_row_layout() == 'enquiry_now_section' ):

$enq_heading = get_sub_field('heading');
$enq_desc = get_sub_field('description');
$enq_btn = get_sub_field('button');
// $enq_image = get_sub_field('image');
$image_grid = get_sub_field('image_grid');
?>
<!-- 02 Section about enrolment Start-->
<!-- mohit -->
<section class="about_enrol pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="inner">
                    <h2 class="hdng" style="width:100%">
                        <?php echo $enq_heading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex">
                <div class="inner">
                    <div class="editor">
                        <p>
                            <?php echo $enq_desc; ?>
                        </p>
                        <a href="<?php echo $enq_btn['url'];?>" class="cmn_btn"><?php echo $enq_btn['title'];?></a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex mt-4 mt-md-0">
                <div class="inner">
                <?php
                    if( have_rows('image_grid') ):
                        while( have_rows('image_grid') ) : the_row();

                            // Load sub field value.
                            $section_image = get_sub_field('section_image');
                            ?>
                            <img class="mb-md-4 mb-2" src="<?php echo $section_image['url'];?>" alt="">
                        <?php
                        // End loop.
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>  
        </div>
    </div>
</section>
<!-- 02 Section about enrolment End-->

<?php elseif( get_row_layout() == 'children_thrive_section' ): ?>
<!-- 03 Section Shapes Start-->
<section class="shapes_section shape_enroll">
    <!--/** Need to remove above container when dynamic functionality is done ***/-->
    <?php get_template_part( 'template-parts/sections/common_shape' ); ?>
</section>
<!-- 03 Section Shapes End-->
<?php elseif( get_row_layout() == 'apply_now_section' ):   
?>
<!-- 09 Section apply start-->
<section class="apply_now bg_white">
    <?php get_template_part( 'template-parts/sections/apply_now' ); ?>
</section>
<!-- 09 Section apply end-->

<?php
elseif( get_row_layout() == 'question_section' ): 
?>
<!-- Questions start-->
<section class="questions_sec bg_grey without_animation">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->


<?php 
endif;
endwhile;
endif;

get_footer(); // Load the footer template ?>
