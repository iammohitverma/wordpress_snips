import axios from "axios";
import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

// API da base URL environment variable ton leya ja reha
const baseUrl = import.meta.env.VITE_API_URL;

// LoginForm component shuru ho reha
function LoginForm({ setIsLogin, setLoggedInUserName, data }) {
  const isform = data?.show_form; // Check kar reha ke form dikhana hai ke nahi
  const [name, setName] = useState(""); // Username di value store karan layi state
  const [password, setPassword] = useState(""); // Password di value store karan layi state
  const [loading, setLoading] = useState(false); // Loading di state
  const [message, setMessage] = useState(""); // Message wali state (error ya success layi)
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Check kar reha ke banda login ho chuka ke nahi
  const [loggedinUser, setLoggedinUser] = useState(""); // Logged-in user da naam

  // Component mount hote check kar reha ke token already localStorage ch hai ke nahi
  useEffect(() => {
    if (localStorage.getItem("token")) {
      setIsLoggedIn(true); // Je token mil gaya taan login status true krdo
    }
  }, []);

  // Form submit hone te handleSubmit function chalega
  const handleSubmit = async (e) => {
    e.preventDefault(); // Form da default behaviour rok lo
    setLoading(true); // Loading true krdo
    setMessage(); // Purana message clear krdo
    try {
      // API nu POST request bhej reha username te password naal
      const res = await axios.post(`${baseUrl}/wp-json/jwt-auth/v1/token`, {
        username: name,
        password: password,
      });

      // Je login successful ho janda
      setMessage("Login successful!"); // Success message set krdo
      localStorage.setItem("token", res.data.token); // Token localStorage ch save krdo
      localStorage.setItem("user_nicename", res.data.user_nicename); // Username localStorage ch save krdo
      setIsLogin(res.data.token); // Parent component nu login token pass krdo
      setLoggedInUserName(res.data.user_nicename); // Parent component nu username pass krdo
      setLoggedinUser(res.data.user_nicename); // Local state ch user da naam set krdo
      setIsLoggedIn(true); // Login status true krdo
    } catch (err) {
      console.log(err); // Error console ch print krdo
      setMessage("Invalid username or password."); // Error message show krdo
    } finally {
      setLoading(false); // Loading false krdo
    }
  };

  return (
    isform === "yes" && ( // Je 'show_form' yes hai taan form show krdo
      <section className="py-5">
        <div className="container">
          <div className="row">
            <div className="col-8 mx-auto">
              <div className="p-5 bg-body-tertiary rounded-3">
                {!isLoggedIn ? ( // Je user login nahi hoya taan login form show krdo
                  <>
                    <h2 className="text-center mb-3">Login</h2>
                    <form onSubmit={handleSubmit}>
                      <div className="mb-3">
                        <label>Name</label>
                        <input
                          type="text"
                          className="form-control"
                          value={name}
                          onChange={(e) => setName(e.target.value)} // Input change hone te name state update krdo
                        />
                      </div>
                      <div className="mb-3">
                        <label>Password</label>
                        <input
                          type="password"
                          className="form-control"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)} // Input change hone te password state update krdo
                        />
                      </div>
                      {loading && ( // Je loading true hai taan loader image show krdo
                        <img
                          src="/loader.gif"
                          alt="loading"
                          width={50}
                          style={{ mixBlendMode: "darken" }}
                        />
                      )}
                      {message && <p>{message}</p>}
                      {/* // Je message hai taan show krdo */}
                      <button type="submit" className="btn btn-primary">
                        Submit
                      </button>
                      <div className="mt-3">
                        <p>
                          Don't have an account?{" "}
                          <NavLink to="/signup">Signup</NavLink>
                        </p>
                      </div>
                    </form>
                  </>
                ) : (
                  // Je user already logged in hai taan message show krdo
                  <h3 className="text-center">
                    Already Logged in {loggedinUser}
                  </h3>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    )
  );
}

export default LoginForm;
