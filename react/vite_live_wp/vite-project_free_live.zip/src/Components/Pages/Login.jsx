import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import LoginForm from "../Sections/LoginForm";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Login({ setIsLogin, setLoggedInUserName }) {
  const { acfData, loading, error } = useFetchAcfData(180, "login");

  if (loading) {
    return <Loader />; // Loading state dikhao jab data aaraha ho
  }

  if (error) {
    return <p>Error: {error}</p>; // Error message dikhao agar API fail ho
  }

  return (
    <>
      <HelmetConfig
        title={"Login Page - My Website"}
        description={"This is the Login page of my website."}
      />

      {acfData.map((block, index) => {
        switch (block.acf_fc_layout) {
          case "banner":
            return <Banner key={index} data={block} />;
          case "login_form":
            return (
              <LoginForm
                key={index}
                data={block}
                setIsLogin={setIsLogin}
                setLoggedInUserName={setLoggedInUserName}
              />
            );
          default:
            return null;
        }
      })}
    </>
  );
}
export default Login;
