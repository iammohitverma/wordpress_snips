import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from "framer-motion";
import { useTest } from '../../context/TestContext';
import axiosinstance from '../../api/axiosinstance';


const Comm1 = () => {
    const [message, setmessage] = useState("")
    const [showAlert, setShowAlert] = useState(false);
    const navigate = useNavigate();

    const handleFinishTest = () => {
        setShowAlert(true);

        setTimeout(() => {
            // navigate to your desired route
            navigate('/your-target-page');
            // OR use window.location.href = '/your-target-page';
        }, 2000);
    };

    const { testData, setTestData } = useTest();

    const handleChange = (e) => {
        const { name, value } = e.target;

        setTestData((prev) => {
            const updatedData = { ...prev, [name]: value };
            console.log('Updated Test Data:', updatedData);

            return updatedData;
        });
    };


    const [isEnabled, setIsEnabled] = useState(false);
    const [cureTime, setCureTime] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');

    const handleToggle = () => setIsEnabled(!isEnabled);

    const handleSubmit = async () => {
        setShowAlert(true);
        try {
            const email = localStorage.getItem('email');
            const payload = {
                ...testData,
                userEmail: email
            };

            const response = await axiosinstance.post('/api/test/save-test', payload);
            console.log('Saved successfully:', response.data);
            setmessage(response.data.message)
            setTimeout(() => {
                navigate('/home');
            }, 2000);
        } catch (err) {
            console.error('Error saving test data:', err);
            setTimeout(() => {
                navigate('/home');
            }, 2000);
        }
    };
    return (
        <div className="min-h-screen bg-gradient-to-b from-[#FFF9F0] to-[#F7E9D7] flex justify-center items-start py-16 px-4">
            <div className="w-full max-w-3xl bg-white rounded-lg shadow-md border border-gray-200 p-8">
                {/* Header panel with logo and step info */}
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center space-x-2">
                        {/* Logo flame icon */}
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-6 w-6 text-orange-500"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2}
                            aria-hidden="true"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M12 3c0 2.993-3 5-3 8a3 3 0 006 0c0-3-3-5-3-8z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M12 12c0-1.105-1-2-1-2s1 2 1 4a1 1 0 102 0c0-1.333-2-2-2-2z"
                            />
                        </svg>
                        <span className="font-semibold text-gray-900 text-lg">
                            Candle Burn-Test Log
                        </span>
                    </div>

                    <div className="text-sm text-gray-500 select-none">
                        Step 4 of 4
                        <span className="inline-flex ml-3 space-x-1">
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                        </span>
                    </div>
                </div>

                <div className="flex flex-col items-center p-6 rounded-lg shadow-md">
                    <h1 className="text-2xl font-bold mb-4">Candle Burn - Test Log</h1>
                    <div className="w-full">
                        <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                        <textarea
                            className="block w-full border border-gray-300 rounded-lg p-2 mb-4"
                            rows="5"
                            placeholder="Additional Notes:"
                            name="MainNote"
                            value={testData.MainNote || ''} onChange={handleChange}
                        />
                        <p className="text-xs text-gray-500 mb-4">
                            A PDF Sheet of Test Results will be available in the "My Logs" tab after finishing test
                        </p>
                    </div>
                    <div className="flex justify-between w-full mt-4">
                        <button className="bg-red-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-red-600">
                            Back
                        </button>
                        <div className="flex space-x-4">
                            <button
                                onClick={handleSubmit}
                                className="bg-green-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-green-600"
                            >
                                Finish Test 🔥
                            </button>

                            <AnimatePresence>
                                {showAlert && (
                                    <motion.div
                                        initial={{ scale: 0 }}
                                        animate={{ scale: 1 }}
                                        exit={{ opacity: 0, scale: 0.5 }}
                                        transition={{ duration: 0.5 }}
                                        className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative shadow-lg"
                                    >
                                        {message}
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Comm1;
