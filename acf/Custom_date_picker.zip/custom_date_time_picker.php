<?php
/* Template Name: Custom Date Time Picker  */
get_header(); ?>

<?php
$event_heading = get_field('event_heading');
$enabled_dates = []; // Array to store enabled date-time values
?>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<style>
    .daterangepicker td.disabled:hover {
        background-color: #fff !important;
        color: #999 !important;
    }

    .slots_wrapper {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        padding: 20px;
        margin-top: 20px;
        background-color: #fff;
        box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
        gap: 15px;
    }

    .slots_wrapper .slot button {
        background-color: rgba(255, 208, 154, 1);
        padding: 10px;
        font-size: 14px;
        color: #000;
        border: none;
        border-radius: 10px;
        transition: 0.5s;
    }

    .slots_wrapper .slot button:hover {
        background-color: rgba(255, 183, 100, 1);
    }
</style>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                    <?php
                    if (have_rows('event_booking')):
                        while (have_rows('event_booking')):
                            the_row();
                            echo "<div class='alert alert-warning mb-3'>";

                            $date_value = get_sub_field('date_time_picker');
                            $full_day_booking = get_sub_field('full_day_booking');
                            $event_slots = get_sub_field('event_slots');
                            if ($date_value) {
                                $enabled_dates[] = $date_value;
                                echo $date_value;
                                echo "</br>";
                                echo "<p class='alert alert-info p-1 mb-4'>Full day booking = " . $full_day_booking . "</p>";
                                $rows = $event_slots;
                                if ($rows && $full_day_booking == "no") {
                                    foreach ($rows as $row) {
                                        echo "<div class='alert alert-primary p-2 mt-1'>";
                                        $start_time = $row['start_time'];
                                        $end_time = $row['end_time'];
                                        echo $start_time . ' ' . $end_time;
                                        echo "</div>";
                                    }
                                }
                            }
                            echo "</div>";
                        endwhile;
                    else:
                    endif;
                    ?>
                </div>
            </div>
            <div class="col-md-6 mx-auto">
                <div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                    <h5 class="mb-3"><?php echo $event_heading; ?></h5>
                    <input type="text" name="daterange" value="" />
                    <br>
                    <div class="slots_wrapper"></div>
                    <button class="btn btn-primary mt-3">Click</button>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>



<script>
    /*************************/
    // Only for dates and time
    /*************************/
    var enabledDates = <?php echo json_encode($enabled_dates); ?>;
    var firstEnabledDate = enabledDates.length > 0 ? moment(enabledDates[0], 'DD/MM/YYYY').format('DD/MM/YYYY') : moment().format('DD/MM/YYYY');

    jQuery('input[name="daterange"]').daterangepicker({
        singleDatePicker: true,
        // timePicker: true,
        locale: {
            format: 'DD/MM/YYYY'
        },
        // minDate: moment().format('DD/MM/YYYY'),
        minDate: firstEnabledDate,
        isInvalidDate: function (date) {
            var dateFormatted = date.format('DD/MM/YYYY');
            return !enabledDates.includes(dateFormatted);
        }
    });

    function triggerDate(dateField) {
        $(".slots_wrapper").html("");
        var selectedDate = $(dateField).val();
        console.log(selectedDate);


        $.ajax({
            url: '<?php echo admin_url("admin-ajax.php"); ?>',
            method: 'POST',
            data: {
                action: 'get_event_slots_for_date',
                date: selectedDate
            },
            success: function (response) {
                const responseOBJ = JSON.parse(response);
                if ((responseOBJ != "") && (responseOBJ != null) && (responseOBJ.length != 0)) {
                    $(responseOBJ).each(function (index, item) {
                        const slotData = item.start_time + " - " + item.end_time;
                        $(".slots_wrapper").append(`<div class="slot"><button data-slot="${slotData}">${slotData}</button></div>`);
                    });
                } else {
                    $(".slots_wrapper").append(`<div class="w-100 text-center alert alert-success p-2">Full Day Booking</div>`);
                }
            }
        });
    }
    triggerDate('input[name="daterange"]');
    $('input[name="daterange"]').on('change', function () {
        triggerDate($(this));
    });
</script>

<?php get_footer(); ?>