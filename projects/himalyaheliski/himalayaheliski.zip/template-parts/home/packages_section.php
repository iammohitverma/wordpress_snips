<section class="two_col_sec">
  <div class="container-fluid p-0">
    <?php if( have_rows('packages') ): ?>
        <?php while( have_rows('packages') ): the_row(); 
            $image = get_sub_field('image');
            $content_box = get_sub_field('content_box');
            $heading = $content_box['heading'];
            $content = $content_box['content'];
            $button = $content_box['button'];
            ?>
            <div class="row gx-0">
                <div class="col-lg-6">
                    <?php
                        if( $image ){ ?>
                        <div class="img_box">
                            <img
                                src="<?php echo $image['url']?>"
                                alt="<?php echo $image['alt']?>"
                                class="w-100 cover"
                            />
                        </div>
                    <?php } ?>
                </div>
                <div class="col-lg-6 flex-grow-1">
                    <div class="text_box">
                    <div class="heading_wrap">
                        <h4 class="main_heading hr_70 fs_35">
                            <?php echo $heading;?>
                        </h4>
                    </div>
                    <div class="content_editor_default">
                        <?php echo $content;?>
                    </div>
                    <?php 
                    if( $button ): 
                        $link_url = $button['url'];
                        $link_title = $button['title'];
                        $link_target = $button['target'] ? $button['target'] : '_self';
                        ?>
                        <a class="hl_btn" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
                    <?php endif; ?>
                    </div>
                </div>
                </div>
        <?php endwhile; ?>
    <?php endif; ?>
  </div>
</section>
