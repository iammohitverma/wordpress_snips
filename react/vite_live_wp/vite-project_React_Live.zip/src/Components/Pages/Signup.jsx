import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import SignupForm from "../Sections/SignupForm";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Signup({ isLogin }) {
  const navigate = useNavigate();
  useEffect(() => {
    if (isLogin) {
      navigate("/login"); //  safely navigate after clearing
    }
  }, []);

  const {
    data: acfData,
    isLoading,
    isError,
    error,
  } = useFetchAcfData(199, "signup");

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <HelmetConfig
        title={"Signup Page - My Website"}
        description={"This is the Login page of my website."}
      />

      {acfData &&
        acfData.map((block, index) => {
          switch (block.acf_fc_layout) {
            case "banner":
              return <Banner key={index} data={block} />;
            case "signup_form":
              return <SignupForm key={index} data={block} />;
            default:
              return null;
          }
        })}
    </>
  );
}
export default Signup;
