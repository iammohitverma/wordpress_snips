<?php
/**
 * Template part for displaying Quetion Section Without Animation
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
    $heading = get_sub_field('heading');
            $description = get_sub_field('description');
            $image = get_sub_field('image');
			$sub_heading = get_sub_field('sub_heading');
?>
<div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-7 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                    <?php echo$heading; ?>
                    </h2>
					<?php if($sub_heading){ ?>
						<b><?php echo $sub_heading; ?></b>
						<?php } ?>
                    <h3 class="sub_hdng">
                    <?php echo$description; ?>
                    </h3>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <img src="<?php echo $image['url'];?>" alt="">
                </div>
            </div>  
        </div>
    </div>