import axios from 'axios';

const axiosinstance = axios.create({
    // baseURL: 'http://localhost:5000',
    baseURL: 'https://first-express-api-ef3v.onrender.com',
    headers: {
        'Content-Type': 'application/json',
    }
});

export default axiosinstance;
