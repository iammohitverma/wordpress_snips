import React, { useEffect, useState } from 'react';
import { AiOutlineFire } from "react-icons/ai";
import axiosinstance from '../../api/axiosinstance';
import { Link, useNavigate } from 'react-router-dom';


const Comm1 = () => {
  const [email, setEmail] = useState('');
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState("");
  const [otp, setOtp] = useState("");
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const useremail = localStorage.getItem('email');


  useEffect(() => {

    if (useremail) {
      navigate("/home")
    }
  }, [useremail])

  const handleSendCode = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await axiosinstance.post('/api/auth/send-otp', { email });
      console.log(res.data);
      
      setMessage(res.data.message);
      setStep(2);
      navigate('/verify-otp', { state: { email: email } });
      setLoading(false);

    } catch (err) {
      console.error(err);
      setMessage(err?.response?.data?.message || "Error sending OTP");
      setLoading(false);

    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-orange-100 to-orange-100">
      <div className="flex flex-col items-center text-center">
        <div className="mb-6">
          <span className="text-6xl text-orange-600"><AiOutlineFire /></span>
        </div>
        <h1 className="text-3xl font-bold text-gray-800">Candle Burn-Test Log</h1>
        <p className="mt-2 text-md text-gray-600">Professional candle testing made simple</p>

        <div className="w-full max-w-md p-6 mt-6 bg-white rounded-lg shadow-md">
          <h2 className="mb-4 text-xl font-semibold">Welcome back</h2>
          <p className="mb-2 text-sm     text-gray-500">Enter your email to receive a sign-in code</p>
          <form onSubmit={handleSendCode}>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-12 px-4 border rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-400 mb-4"
              placeholder="Email Address"
              required
            />
            <p>{message}</p>
            <button
              type="submit"
              className="w-full h-12 text-white bg-orange-400 rounded-md hover:bg-orange-600 transition duration-200"
            >
              {loading ? (
                <svg
                  className="animate-spin h-5 w-5 text-white mx-auto"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v8H4z"
                  ></path>
                </svg>
              ) : (
                "Send Code"
              )}
            </button>
          </form>
          <p className="text-sm mt-4 text-gray-600">
            Don't have an account? <Link to={'/signup'} className=" text-orange-500 underline">Sign up</Link>
          </p>
        </div>

        <p className="mt-6 text-gray-500 text-xs">Secure passwordless authentication</p>
      </div>
    </div>
  );
};

export default Comm1;
