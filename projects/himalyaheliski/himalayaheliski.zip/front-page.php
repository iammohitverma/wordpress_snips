<?php
/**
 * The template for displaying front page
 *
 * (Home Page of Website)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package himalayaheliski-theme
 */
get_header();
?>

<?php if (have_rows('sections')) : ?>
	<?php while (have_rows('sections')) : the_row(); 
		$layout_name = get_row_layout();
		$template_part_path = get_stylesheet_directory() . '/template-parts/home/' . $layout_name . '.php';
			if (file_exists($template_part_path)) {
				include($template_part_path);
		}
	?>
	<?php endwhile; ?>
<?php endif; ?>

<?php get_footer();?>

