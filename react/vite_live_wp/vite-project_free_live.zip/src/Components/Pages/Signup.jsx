import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import SignupForm from "../Sections/SignupForm";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Signup({ isLogin }) {
  const navigate = useNavigate();
  useEffect(() => {
    if (isLogin) {
      navigate("/login"); //  safely navigate after clearing
    }
  }, []);

  const { acfData, loading, error } = useFetchAcfData(199, "signup");

  if (loading) {
    return <Loader />; // Loading state dikhao jab data aaraha ho
  }

  if (error) {
    return <p>Error: {error}</p>; // Error message dikhao agar API fail ho
  }

  return (
    <>
      <HelmetConfig
        title={"Signup Page - My Website"}
        description={"This is the Login page of my website."}
      />

      {acfData.map((block, index) => {
        switch (block.acf_fc_layout) {
          case "banner":
            return <Banner key={index} data={block} />;
          case "signup_form":
            return <SignupForm key={index} data={block} />;
          default:
            return null;
        }
      })}
    </>
  );
}
export default Signup;
