// SinglePost.jsx
import axios from "axios";
import React from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Loader from "../Sections/Loader";

function SinglePost() {
  const { slug } = useParams();
  const baseUrl = import.meta.env.VITE_API_URL;

  const fetchPostData = async () => {
    const res = await axios.get(`${baseUrl}/wp-json/wp/v2/posts`, {
      params: { slug },
    });
    const postData = res.data[0];

    if (!postData) return null;

    if (postData.featured_media) {
      try {
        const imageRes = await axios.get(
          `${baseUrl}/wp-json/wp/v2/media/${postData.featured_media}`
        );
        postData.featured_image_url = imageRes.data.source_url;
      } catch (imgErr) {
        console.warn(`Post image not fetched:`, imgErr);
        postData.featured_image_url = null;
      }
    } else {
      postData.featured_image_url = null;
    }

    return postData;
  };

  const {
    data: post,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ["singlePost", slug],
    queryFn: fetchPostData,
    enabled: !!slug,
  });

  if (isLoading) return <Loader />;
  if (isError) return <div>Error: {error.message}</div>;
  if (!post) return <div>Post not found.</div>;

  return (
    <section className="single_post container">
      <h1 dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
      {post.featured_image_url && (
        <img
          src={post.featured_image_url}
          alt={post.title.rendered}
          style={{ width: "100%", marginBottom: "20px" }}
        />
      )}
      <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} />
    </section>
  );
}

export default SinglePost;
