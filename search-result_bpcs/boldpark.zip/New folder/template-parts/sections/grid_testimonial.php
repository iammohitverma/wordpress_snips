<?php
/**
 * Template part for displaying Testimonial (Grid)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>
<div class="container">
    <div class="row">
        <div class="col-12 col-md-6 d-flex align-items-center">
        <?php $image = get_sub_field('testimonial_image'); 
                    if( !empty( $image ) ): 
            ?>
            <div class="inner">
                <img src="<?php echo esc_url($image['url']); ?>" alt="">
            </div>
            <?php endif;      ?>
        </div>
        <div class="col-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
            <div class="inner ps-md-3">
            <?php $testimonial_content = get_sub_field('testimonial_content'); ?>
                
                <p class="desc">
                    <?php echo $testimonial_content ;?>
                </p>
                <p class="userName">
                -  <?php $author = get_sub_field('author_name'); 
                        echo $author ;
                ?>
                    <!-- img src="/wp-content/uploads/2023/05/heart.png" alt=""-->
                </p>
            </div>
        </div>
    </div>
</div>

