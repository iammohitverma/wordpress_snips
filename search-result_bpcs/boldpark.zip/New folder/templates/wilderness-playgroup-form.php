<?php 
/*
Template Name: Program/WP Form
*/
get_header(); // Load the header template
?>

<!-- Common banner secion inner pages  -->
<section class="app_process_banner bg_grey wpg_form_banner">
    <div class="banner_main">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="banner_left">
                        <div class="banner_headings">
                            <h2 class="banner_mainheading sec_title_90">
                                Wilderness Playgroup
                            </h2>
                            <p>
                                Online enquiry
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 d-flex justify-content-center">
                    <div class="banner_right">
                        <img src="/wp-content/uploads/2023/05/wpg_banner_hero.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Common banner secion inner pages  -->

<?php get_footer(); // Load the footer template ?>
