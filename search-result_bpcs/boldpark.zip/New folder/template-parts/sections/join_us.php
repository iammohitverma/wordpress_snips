<?php
/**
 * Template part for displaying Join Us
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

$join_heading = get_sub_field('heading');
$join_desc = get_sub_field('description');
$join_button = get_sub_field('button');
$join_image = get_sub_field('image');
?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-lg-7">
            <div class="inner">
                <img src="<?php echo $join_image['url'];?>" alt="">
            </div>
        </div>

        <div class="col-md-6 col-lg-5 mt-4 mt-md-0 d-flex align-items-center">
            <div class="inner">
                <h4 class="hdng">
                    <?php echo $join_heading; ?>
                </h4>
                <p>
                    <?php echo $join_desc; ?>
                </p>
                <a href="<?php echo $join_button['url'];?>" class="cmn_btn">
                    <?php echo $join_button['title']; ?>
                </a>
            </div>
        </div>
    </div>
</div>