import React from 'react'
import Comm1 from '../components/Admin/Comm1'

const Admin = () => {
    return (
        <div>
            <Comm1 />
        </div>
    )
}

export default Admin
