<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file = __DIR__ . '/saved-template.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jsonData = file_get_contents('php://input');
    $data = json_decode($jsonData, true);

    if (!$data || !isset($data['html']) || !isset($data['css'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid data']);
        exit;
    }

    // $saved = file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    $saved = file_put_contents($file, json_encode($data)); // no JSON_PRETTY_PRINT

    if ($saved === false) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save']);
        exit;
    }

    echo json_encode(['message' => 'Template saved successfully']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    header("Cache-Control: public, max-age=60");
    if (file_exists($file)) {
        $contents = file_get_contents($file);
        $decoded = json_decode($contents, true);

        // If empty or invalid JSON, send blank structure
        if (!$decoded || !isset($decoded['html']) || !isset($decoded['css'])) {
            echo json_encode(['html' => '', 'css' => '']);
            exit;
        }

        echo json_encode($decoded);
        exit;
    } else {
        // If file doesn't exist, send blank structure
        echo json_encode(['html' => '', 'css' => '']);
        exit;
    }
}

http_response_code(405);
echo json_encode(['error' => 'Only GET and POST methods allowed']);