<?php
/*
Template Name: Reggio Inspired
*/
get_header(); // Load the header template

global $wp_query;
?>
	<?php 
    if (have_rows('our_difference_sections')) : 
        while (have_rows('our_difference_sections')) : the_row(); ?>
        
        <?php
            //Banner Section.
        if (get_row_layout() == 'banner_section') : ?>
        
<section class="our_difference_newbanner bg_grey cmn_new_banner">
    <div class="container-fluid px-0">
        <?php 
            $parent_pageId = wp_get_post_parent_id(get_the_ID());
            $parent_page = get_the_title($parent_pageId);
            $parent_page_url = get_the_permalink($parent_pageId);
            $page_title = $wp_query->post->post_title; 
        ?>
        <div class="banner_main">
            <div class="container">
                <div class="breadcrumbs">
                    <ul>
                        <?php if($parent_pageId != 0){ ?>
                            <li>
                                <a href="<?php echo $parent_page_url; ?>">
                                    <?php echo $parent_page; ?>
                                </a>
                            </li>
                            <?php } ?>
                                <li>
                                    <a href="javascript:void(0)" class="active">
                                        <?php echo $page_title; ?>
                                    </a>
                                </li>
                    </ul>
                </div>
            </div>
            <div class="banner_content_wrap">
                <div class="row">
                    <?php 
                        $banner_heading = get_sub_field('banner_heading');
                        $banner_desc = get_sub_field('banner_description');
                        $banner_img = get_sub_field('banner_image');
                    ?>
                        <div class="col-lg-5 col-md-6 col-sm-12 col-12">
                            <div class="left_main">
                                <div class="left_img"> 
                                <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-6 col-sm-12 col-12">
                            <div class="banner_content_inner">
                                <div class="right_cont">
                                    <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading;?></h2>
                                    <p>
                                        <?php echo $banner_desc; ?>
                                    </p>
                                </div>
								<div class="banner_links">
									<?php get_template_part( 'template-parts/sections/banner_links' ); ?>
								</div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 02 Section about difference Start-->
<?php elseif (get_row_layout() == 'video_section') :

    $section_heading = get_sub_field('section_heading');
    $heading = get_sub_field('heading');
    $description = get_sub_field('description');
?>
<section>
    <div class="container">
        <div class="our_mission_main">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mv_left">
                        <div class="m_heading">
                            <h3 class="bg_hdng sec_title_90">
                                <?php echo $section_heading; ?>
                            </h3>
                        </div>
                        <?php $image = get_sub_field('image');
                                    if (!empty($image)) : ?>
                        <div class="m_img">
                            <img src="<?php echo esc_url($image['url']); ?>" alt="welcome_hero" />
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 d-flex align-items-center">
                    <div class="mv_right">
                        <h6 class="hdng">
                            <?php echo $heading; ?>
                        </h6>
                        <p>
                            <?php echo $description; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 02 Section about difference end-->

<!-- Section 03 Video Section -->
<section class="single-video-sec hide_temp">
    <?php get_template_part('template-parts/sections/videos_section');  ?>
</section>
<!-- Section 03 Video Section End -->

<!-- Section 04 Accordian -->
	<?php elseif (get_row_layout() == 'accordion_section_new') :
        $acc_section_heading = get_sub_field('section_heading');
    ?>
<section class="accordian_wrapper new_design bg_grey">
	<div class="container">
		<div class="row">
            <div class="col-12">
                <h3 class="hdng">
                    <?php echo $acc_section_heading; ?>
                </h3>
                <div class="cmn_hr"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <?php
                    // check if the nested repeater field has rows of data
                    if( have_rows('accordions') ):
                    while ( have_rows('accordions') ) : the_row(); 
                    $accordion_heading = get_sub_field('accordion_heading'); 
                    $left_description = get_sub_field('accordion_left_description');
                    $right_image = get_sub_field('accordion_right_image');
                ?>
                <div class="accordion-item">
                    <div class="accordion-item-header">
                        <?php echo $accordion_heading ;?>
                    </div>
                    <!-- /.accordion-item-header -->
                    <div class="accordion-item-body" style="max-height: 0px;">
                        <div class="accordion-item-body-content">
                            <?php if (!empty($right_image)) : ?>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="left_content_accord">
                                            <p>
                                                <?php echo $left_description; ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="right_content_accord">
                                            <img src="<?php echo esc_url($right_image['url']); ?>">
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="left_content_accord">
                                            <p>
                                                <?php echo $left_description; ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- /.accordion-item-body -->
                </div>
                    <!-- /.accordion-item -->
                <?php endwhile; 
                    endif;
                ?>
            </div>
        </div>
    </div>
</section>

<!-- Section 07 hover expand items -->
<?php elseif (get_row_layout() == 'join_us_section') :?>
<section class="join_us">
    <?php get_template_part('template-parts/sections/join_us'); ?>
</section>
<!-- Section 07 hover expand items End -->

<!-- Section 08 Apply Now Start -->
<?php elseif (get_row_layout() == 'apply_now_section') : ?>
<!-- Questions start-->
<section class="questions_sec">
    <?php get_template_part('template-parts/sections/apply_now'); ?>
</section>
<!-- Section 08 Apply Now End -->										
<?php get_footer(); // Load the footer template
        endif;
    endwhile;
endif;
?>
