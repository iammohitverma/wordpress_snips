<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file = 'data.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $newData = json_decode($input, true);

    if (!$newData) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON"]);
        exit;
    }

    $existingData = file_exists($file)
        ? json_decode(file_get_contents($file), true)
        : [];

    $existingData[] = $newData;

    if (file_put_contents($file, json_encode($existingData, JSON_PRETTY_PRINT)) === false) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to write data"]);
        exit;
    }

    echo json_encode(["message" => "Data saved"]);
} else {
    header('Content-Type: application/json');
    echo file_exists($file)
        ? file_get_contents($file)
        : json_encode([]);
}
