<?php
$servername = 'localhost';
$username = 'tech_admi5s10ndbu5r';
$password = '5_}9?1MWj6A9';
$dbname = 'tech_admis5i0ndb';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>