<?php 
/*
Template Name: Enrolment/App Process
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('application_process_page_sections') ): 
     while( have_rows('application_process_page_sections') ): the_row(); 
        //Banner Section.
        if( get_row_layout() == 'banner_section' ):?>
<section class="app_process_banner bg_grey">
    <div class="banner_main">
        <?php  get_template_part( 'template-parts/sections/banner_inner_pages' ); ?>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php
    // process_steps  layout.
        elseif( get_row_layout() == 'process_steps' ): 
    ?>
<!-- 02 Section about difference Start-->
<div class="steps_loop">
<?php if( have_rows('steps') ): 
        $count = 0;
     while ( have_rows('steps') ) : the_row(); 
     $steps_sub_heading = get_sub_field('sub_heading');
     $steps_heading = get_sub_field('heading');
     $steps_description = get_sub_field('description');
     $steps_button = get_sub_field('button');
     if( $steps_button ):
         $steps_button_url = $steps_button['url'];
         $steps_button_title = $steps_button['title'];
     endif;
    ?>
    <section class="aplication_step <?php if($count == 0){ ?>pt_extra <?php } ?>">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="inner shape_inner">
                        <div class="row">
                            <div class="col-md-4 col-lg-4 d-flex align-items-center">
                                <div class="inner">
                                    <p class="step_p">
                                        <?php echo$steps_sub_heading; ?>
                                    </p>
                                    <h4 class="hdng">
                                    <?php echo$steps_heading; ?>
                                    </h4>
                                </div>
                            </div>
                            <div class="col-md-8 col-lg-8">
                                <p class="desc">
                                <?php echo$steps_description; ?>
                                </p>
                                <?php if( $steps_button ): ?>
                                <a href="<?php echo esc_url($steps_button_url); ?>" class="cmn_btn">
                                <?php echo esc_html( $steps_button_title ); ?>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php 
        $count++;
        endwhile; 
        endif; 
        ?>
</div>
<!-- 02 Section about difference end-->
<?php
elseif( get_row_layout() == 'enquiry_section' ): 
?>
<!-- Questions start-->
<section class="questions_sec bg_grey without_animation">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->

<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>
