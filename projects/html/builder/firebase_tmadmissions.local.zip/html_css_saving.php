<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file = __DIR__ . '/saved-template.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jsonData = file_get_contents('php://input');
    $data = json_decode($jsonData, true);

    if (!$data || !isset($data['changedComponents']) || !is_array($data['changedComponents'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid data: changedComponents missing']);
        exit;
    }

    // Load existing saved file if exists, else create blank
    $savedData = ['html' => '<body></body>', 'css' => ''];
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $savedData = json_decode($content, true) ?: $savedData;
    }

    // Use DOMDocument to parse and update HTML
    $dom = new DOMDocument();
    // Suppress warnings due to malformed HTML
    libxml_use_internal_errors(true);
    $dom->loadHTML($savedData['html'], LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    foreach ($data['changedComponents'] as $component) {
        if (!isset($component['id']) || !isset($component['html'])) continue;

        $element = $dom->getElementById($component['id']);
        if ($element) {
            // Remove all children of the element
            while ($element->firstChild) {
                $element->removeChild($element->firstChild);
            }
            // Append new HTML fragment inside the element
            $frag = $dom->createDocumentFragment();
            @$frag->appendXML($component['html']);
            $element->appendChild($frag);
        }
    }

    // Save updated HTML + old CSS
    $savedData['html'] = $dom->saveHTML();
    // CSS remains same, or you can update similarly if needed

    $saved = file_put_contents($file, json_encode($savedData, JSON_PRETTY_PRINT));

    if ($saved === false) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save updated template']);
        exit;
    }

    echo json_encode(['message' => 'Template updated successfully']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($file)) {
        $contents = file_get_contents($file);
        $decoded = json_decode($contents, true);

        // If empty or invalid JSON, send blank structure
        if (!$decoded || !isset($decoded['html']) || !isset($decoded['css'])) {
            echo json_encode(['html' => '', 'css' => '']);
            exit;
        }

        echo json_encode($decoded);
        exit;
    } else {
        // If file doesn't exist, send blank structure
        echo json_encode(['html' => '', 'css' => '']);
        exit;
    }
}

http_response_code(405);
echo json_encode(['error' => 'Only GET and POST methods allowed']);