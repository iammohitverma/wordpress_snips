Resize images in a folder (and subfolders) to a max width of 1920px using Node.js and Sharp.
Install dependencies with `npm install` and run with `node main.js`

<!-- npm install -->
<!-- node main.js -->
