<div class="people_tabs">
    <?php $people_genres = get_terms('people-category'); // get all the people ?>
      <ul class="nav" role="tablist" id="vr_tabs">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#all">Our leadership</a>
        </li>
          <?php foreach($people_genres as $people_genre) { ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="tab" href="#<?php echo $people_genre->slug ?>"><?php echo $people_genre->name ?></a>
            </li>
          <?php } ?>
      </ul>
      <hr style="border-top: 2px solid #CCCFD2; margin: 10px 0; width:30%;">
</div>
<div class="tab-content">
  <div id="all" class="tab-pane active"><br>
    <?php 	
      $args = array('post_type' => 'our-people', 'posts_per_page'=> -1, 'orderby' => 'publish_date', 'order' => 'DESC');
      $all_peoples = new WP_Query( $args );		
      if ( $all_peoples->have_posts() ) : // make sure we have films to show before doing anything 
    ?>
      <div class="people_list">
        <ul>
        <?php while ( $all_peoples->have_posts() ) : $all_peoples->the_post(); ?>
              <li>
                <div class="teacher_img">
                  
                  <?php if (has_post_thumbnail()) : ?>
                      <?php the_post_thumbnail(); ?>
                  <?php else : ?>
                      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/dummy_user.png" alt="leadership-team" />
                  <?php endif; ?>

                    <a href="JavaScript:void(0)">
                        <span>
                            Read More
                        </span>
                    </a>
                </div>
                <div class="teacher_desc">
                  <h4><?php the_title() ?></h4>
                  <?php if( get_field('position') ): ?>
                    <p><?php the_field('position'); ?></p>
                  <?php endif; ?>
                </div>
                <!--- moday body start --->
                <div class="modalBody">
                  <?php if( get_field('position') ): ?>
                      <p><?php the_field('position'); ?></p>
                  <?php endif; ?>
                    <h3><?php the_title() ?></h3>
                      <div class="about_peple row">
                          <div class="col-md-3">
                              <div class="wrapper">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail(); ?>
                                <?php else : ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/dummy_user.png" alt="leadership-team" />
                                <?php endif; ?>
                                  <?php if( get_field('qualification') ): ?>
                                    <p>QUALIFICATIONS: 
                                    <br> 
                                      <?php the_field('qualification'); ?>
                                  <?php endif; ?>
                                  </p>
                                  <?php if( get_field('bpos') ): ?>
                                  <span>AT BPCS SINCE:
                                      <?php the_field('bpos'); ?>
                                  </span>    
                                  <?php endif; ?>

                              </div>
                          </div>
                          <div class="col-md-9">
                              <div class="people_blog">
                                  <p><?php echo the_content(); ?></p>
                              </div>
                          </div>
                      </div>
                </div>
                <!--- moday body end --->
              </li>
         <?php endwhile; ?>
        <?php wp_reset_query() ?>
        </ul>
      </div>
      <?php endif; ?>
    </div>
    <?php foreach($people_genres as $people_genre) { ?>
      <div id="<?php echo $people_genre->slug ?>" class="tab-pane fade"><br>
          <?php 	
              $args = array('post_type' => 'our-people', 'posts_per_page'=> -1, 'orderby' => 'publish_date', 'order' => 'DESC', 'tax_query' => array(
                      array( 'taxonomy' => 'people-category', 'field' => 'slug', 'terms' => $people_genre->slug ) ) );
                      $peoples = new WP_Query( $args );		
          ?>
          <?php if ( $peoples->have_posts() ) : // make sure we have films to show before doing anything?>
              <div class="people_list">
                <ul>
                <?php while ( $peoples->have_posts() ) : $peoples->the_post(); ?>
                <li>
                  <div class="teacher_img">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail(); ?>
                    <?php else : ?>
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/dummy_user.png" alt="leadership-team" />
                    <?php endif; ?>
                      <a href="JavaScript:void(0)">
                          <span>
                              Read More
                          </span>
                      </a>
                  </div>
                  <div class="teacher_desc">
                          
                          <h4><?php the_title() ?></h4>
                          <?php if( get_field('position') ): ?>
                            <p><?php the_field('position'); ?></p>
                        <?php endif; ?>
                  </div>
                <!--- moday body start --->
                <div class="modalBody">
                  <?php if( get_field('position') ): ?>
                      <p><?php the_field('position'); ?></p>
                  <?php endif; ?>
                    <h3><?php the_title() ?></h3>
                      <div class="about_peple row">
                          <div class="col-md-3">
                              <div class="wrapper">
                                  <?php if (has_post_thumbnail()) : ?>
                                      <?php the_post_thumbnail(); ?>
                                  <?php else : ?>
                                      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/dummy_user.png" alt="leadership-team" />
                                  <?php endif; ?>
                                  <p>QUALIFICATIONS: 
                                  <br> 
                                  <?php if( get_field('qualification') ): ?>
                                      <?php the_field('qualification'); ?>
                                  <?php endif; ?>
                                  </p>
                                  <?php if( get_field('bpos') ): ?>
                                  <span>AT BPCS SINCE:
                                      <?php the_field('bpos'); ?>
                                  </span>    
                                  <?php endif; ?>

                              </div>
                          </div>
                          <div class="col-md-9">
                              <div class="people_blog">
                                  <p><?php echo the_content(); ?></p>
                              </div>
                          </div>
                      </div>
                </div>
                <!--- moday body end --->
                </li>
                <?php endwhile; ?>
                <?php wp_reset_query() ?>
                </ul>
              </div>
            <?php endif; ?>
      </div>
      <?php }  ?>
</div>
        

<section class="popupWrapper">
    <div class="people_popup container-fluid">
        <div class="container">
            <div class="cross">
                <span class="one"></span>
                <span class="two"></span>
            </div>

            <!--- moday body start --->
            <div id="appendCntnt">
                <div class="modayBody">
                    <p>PEDAGOGISTA</p>
                    <h3>Nicole Hunter</h3>
                    <div class="about_peple row">
                        <div class="col-md-3">
                            <div class="wrapper">
                                <img src="./assets/images/image1.png" alt="">
                                <p>QUALIFICATIONS: <br> Bachelor of ScienceGraduate Diplomas in Education (Science and Early Childhood)Masters of Education
                                </p>
                                <span>AT BPCS SINCE:
                                2004</span>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="people_blog">
                                <p>
                                  Nicole fervently believes that quality early life relationships, experiences and education are critical in providing a solid foundation for healthy life patterns and continuous learning. Nicole has both contributed
                                    to and experienced the growth of Bold Park Community School as a parent, teacher and board member; first joining the community in 2001, when the school was a one-room primary school! She became part of the Early
                                    Childhood teaching team in 2004.
                                    <br> From 2008 until 2015 Nicole was Early Childhood Co-Team Leader with the responsibility of expanding the outdoor learning program and National Quality Standards. In 2016 Nicole was appointed to the role of Pedagogista.
                                    This role sees her working, in collaboration, with the teaching teams and leadership to align the principles, practices and philosophy of Bold Park with current educational research and translate these into the
                                    daily experience of students and families. <br> To this role, Nicole draws not only her many years of experience in the Bold Park context, but also her teaching experience in a breadth of contexts including high
                                    school science and early years learning. Nicole is grateful to have had the opportunity to travel internationally to visit educational contexts of Reggio Emilia and has recently completed her Master’s of Education
                                    in Teaching and Learning.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--- moday body start --->
        </div>
    </div>
</section>
