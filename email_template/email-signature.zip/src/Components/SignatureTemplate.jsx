import { useState } from "react";

import { MasterSignature } from "./MasterSignature";

// Signature css
import "../assets/css/signature.css";

export const SignatureTemplate = () => {
  // Function to copy the table content to clipboard
  const copyFunction = () => {
    // Get the HTML content of the table
    const tableContent = document.querySelector(".table_wrap table").outerHTML;

    // Create a temporary div element to hold the HTML content
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = tableContent;

    // Append the div to the body (it needs to be in the DOM to be copied)
    document.body.appendChild(tempDiv);

    // Select the content
    const range = document.createRange();
    range.selectNode(tempDiv);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    // Copy the selected content
    try {
      document.execCommand("copy");
      alert("Email signature copied to clipboard!");
    } catch (err) {
      console.error("Failed to copy: ", err);
    }

    // Clean up by removing the temporary div
    document.body.removeChild(tempDiv);
  };

  const ourExpertsList = {
    matthew: {
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/matthew_120.png",
      expertName: "Matthew Hughes",
      expertPositionSm: "CertIVPS(RE) DipFMBM QPIA",
      expertPositionLgFirstRow: "Managing Director &",
      expertPositionLgSecondRow: "Senior Buyer's Agent",
      expertContact: "0437 777 377",
      expertEmail: "matthew@cpadvisory.com.au",
    },
    stacey: {
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/stacey_billerwell_120.png",
      expertName: "Stacey Billerwell",
      expertPositionSm: "",
      expertPositionLgFirstRow: "National Acquisitions Adviser",
      expertPositionLgSecondRow: "",
      expertContact: "0419 713 330",
      expertEmail: "stacey@cpadvisory.com.au",
    },
    ben: {
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/ben_120.png",
      expertName: "Ben Chamberlain",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Buyers Agent",
      expertPositionLgSecondRow: "",
      expertContact: "0488 776 628",
      expertEmail: "ben@cpadvisory.com.au",
    },
    becky: {
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/becky_120.png",
      expertName: "Becky Hughes",
      expertPositionSm: "",
      expertPositionLgFirstRow: "PR & Marketing Manager",
      expertPositionLgSecondRow: "",
      expertContact: "0438 912 422",
      expertEmail: "becky@cpadvisory.com.au",
    },
    anthony: {
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/anthony_rizzacasa_120.png",
      expertName: "Anthony Rizzacasa",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Senior Development Manager",
      expertPositionLgSecondRow: "",
      expertContact: "0403 359 733",
      expertEmail: "anthony@cpadvisory.com.au",
    },
  };

  const [expert, setExpert] = useState("matthew");
  const [expertData, setExpertData] = useState(ourExpertsList.matthew);

  const onHandleSelectChange = (event) => {
    const selectedExpert = event.target.value;
    setExpert(selectedExpert);
    setExpertData(ourExpertsList[selectedExpert]); // Update expert data based on the new selection
  };

  return (
    <>
      <header>
        <div className="container_okmg">
          <a
            href="https://www.cpadvisory.com.au/"
            className="logo"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/cpa-logo.svg"
              alt=""
            />
          </a>
        </div>
      </header>
      <section className="email_signature_wrap">
        <div className="container_okmg">
          <div className="form_wrap">
            <div className="head">
              <h1 className="signature_header">Email Signature</h1>
              <h2 className="signature_sub_header">
                Preview and Select Signature
              </h2>
              <p className="signature_description">
                Choose from the generated email signature options to view and
                select the one that best fits your needs.
              </p>
            </div>

            <form>
              <div className="input_control">
                <label htmlFor="experts">
                  Our Experts: Signature Preview Options
                </label>
                <select
                  name="experts"
                  id="experts"
                  onChange={(e) => onHandleSelectChange(e)}
                  value={expert}
                >
                  <option value="matthew">Matthew Hughes</option>
                  <option value="stacey">Stacey Billerwell</option>
                  <option value="ben">Ben Chamberlain</option>
                  <option value="anthony">Anthony Rizzacasa</option>
                  <option value="becky">Becky Hughes</option>
                </select>
              </div>
            </form>
          </div>
          <div className="inner">
            <div className="table_wrap">
              <MasterSignature expertData={expertData} />
            </div>
          </div>

          <div className="copy_btn_wrap">
            <div className="container_okmg">
              <button className="copyBtn" onClick={copyFunction}>
                Copy email signature
              </button>
            </div>
          </div>
        </div>
      </section>
      <footer>
        <div className="container_okmg">
          <p>© 2024 Capital Property Advisory</p>
        </div>
      </footer>
    </>
  );
};
