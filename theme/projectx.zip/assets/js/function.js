jQuery(document).ready(function () {
  var header = jQuery(".projectx_header") // Select the header

  jQuery(window).scroll(function () {
    var scroll = jQuery(window).scrollTop(); // Get current scroll position

    if (scroll > 30) {
      header.addClass("sticky");
    } else {
      header.removeClass("sticky");
    }
  });

  jQuery(".menu_toggle_btn").click(function () {
    jQuery(this).toggleClass("active");
    header.toggleClass("active");
    jQuery(".navigationWrap").slideToggle();
  });

  jQuery(".subMenuAngle").click(function () {
    jQuery(this).toggleClass("active");
    jQuery(this).closest(".a-Wrap").next(".sub-menu").slideToggle();
  });

  new Swiper("#relationships_slider", {
    slidesPerView: 1,
    spaceBetween: 10,
    pagination: {
      el: ".swiper-pagination",
      type: "progressbar",
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      640: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 40,
      },
      1024: {
        slidesPerView: 4,
        spaceBetween: 50,
      },
    }
  });
});