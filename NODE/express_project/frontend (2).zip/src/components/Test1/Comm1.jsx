import React from 'react';
import { Link } from 'react-router-dom';

const CandleBurnTestLog = () => {
    return (
        <div className="flex items-center justify-center min-h-[85vh] w-full bg-gradient-to-b from-orange-100 to-orange-50 text-amber-900 ">
            <div className="flex flex-col    bg-white shadow-lg rounded-lg p-6 max-w-2xl text-center">
                <div className="flex justify-center mb-4">
                    <span className="text-4xl text-yellow-500">🕯️</span>
                </div>
                <h1 className="text-3xl font-bold mb-2">Candle Burn-Test Log</h1>
                <h2 className="text-lg font-semibold mb-4">Important Information</h2>
                <p className="text-gray-700 mb-6">
                    The next section is in regards to how you made your candle. Be as thorough as possible to ensure you have detailed
                    your candle-making process accurately. This will help you to assess the strong and weak points of your candle-making process.
                </p>
                <div className='flex justify-center'>
                    <Link to={"/home/test-2"} className="flex items-center justify-center bg-red-500 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:bg-red-600 hover:scale-105 focus:outline-none">
                        Next
                        <span className="ml-2">➡️</span>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default CandleBurnTestLog;
