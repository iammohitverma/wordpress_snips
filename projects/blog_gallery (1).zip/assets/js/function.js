function initLightGallery() {
  lightGallery(document.getElementById("gallary_container"));
}
function afterWindowLoad() {
  initLightGallery({
    speed: 500,
    mode: "lg-fade",
    zoom: true,
  });

  //   // team members
  //   const teamImagePopup = {
  //     selector: "a.gallery_image",
  //     speed: 500,
  //     mode: "lg-fade",
  //     download: false,
  //     zoom: false,
  //   };
  //   const teamItems = document.querySelectorAll(".team_section .img_box");
  //   teamItems.forEach((item) => {
  //     lightGallery(item, teamImagePopup);
  //   });
}
window.addEventListener("load", afterWindowLoad);
