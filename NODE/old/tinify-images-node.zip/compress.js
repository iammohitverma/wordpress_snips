const fs = require('fs');
const path = require('path');
const tinify = require('tinify');

// Set your API key here
// Get you API from: https://tinify.com/developers 
tinify.key = "bpLDQtZZmcd4TmTn4XGbTP6BSQC12bbw";

// Folder paths
const inputFolder = path.join(__dirname, 'input');
const outputFolder = path.join(__dirname, 'output');

// Create output folder if it doesn't exist
if (!fs.existsSync(outputFolder)) {
  fs.mkdirSync(outputFolder);
}

// Supported image extensions
const validExtensions = ['.png', '.jpg', '.jpeg'];

// Compress all images in the input folder
fs.readdir(inputFolder, async (err, files) => {
  if (err) {
    console.error("Failed to read input folder:", err);
    return;
  }

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    if (!validExtensions.includes(ext)) continue;

    const inputPath = path.join(inputFolder, file);
    const outputPath = path.join(outputFolder, file);

    try {
      await tinify.fromFile(inputPath).toFile(outputPath);
      console.log(`✅ Compressed: ${file}`);
    } catch (err) {
      console.error(`❌ Failed to compress ${file}:`, err.message);
    }
  }
});
