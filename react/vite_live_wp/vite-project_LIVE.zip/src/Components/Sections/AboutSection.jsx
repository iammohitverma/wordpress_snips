import React from "react";

function AboutSection({ data }) {
  const sectionData = data || {};
  const { heading = "Default Heading", sub_heading = "Default sub_heading" } =
    sectionData;

  return (
    <>
      <section className="about_sec bg-warning">
        <div className="container my-5">
          <div className="p-5 text-center bg-body-tertiary rounded-3">
            <h1 className="text-body-emphasis mb-4">{heading}</h1>
            <p className="col-lg-8 mx-auto fs-5 mb-5  text-muted">
              {sub_heading}
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
export default AboutSection;
