$(document).ready(function () {
    $('#staticBackdrop').modal({
        backdrop: 'static',
        keyboard: false
    })


    var timer;
    var iqScore;

    //    $("[data-toggle='popover']").on({
    $("#gameOneHoveringPoints .point").on({
        'mouseover': function (event) {
            var currentElem = $(this).html(event.target);
            timer = setTimeout(function () {
                $(currentElem).addClass('active');
                $('span.point').popover('hide');
                $(currentElem).popover('show').off('click').siblings();




                if ($(currentElem).hasClass("point1")) {
                    $('#featureOne').modal('show');
                }

                if ($(currentElem).hasClass("point2")) {
                    $('#featureOne').modal('show');
                }

                if ($(currentElem).hasClass("point3")) {
                    $('#featureOne').modal('show');
                }

                if ($(currentElem).hasClass("point4")) {
                    $('#featureOne').modal('show');
                }

                if ($(currentElem).hasClass("point5")) {
                    $('#featureOne').modal('show');
                }

                if ($('span.point.active').length >= 5) {
                    
                    /*** score game 01 ****/
                    iqScore = 50
                    $('.game-score').html("Your Score is " + "<b>" + iqScore + "</b>");
                }

                $(".gm-popup-close").click(function () {
                    if ($('span.point.active').length >= 5) {
                        $('#staticBackdropScore').modal({
                            backdrop: 'static',
                            keyboard: false
                        })
                    }
                })

            }, 500);
        },
        'mouseout': function () {
            clearTimeout(timer);
        }
    });

    $("#playnextGame").click(function () {
        window.location.href = 'https://cytiva.dexsandbox.com/game-list.html';
        // Check browser support
        if (typeof (Storage) !== "undefined") {
            // Store
            sessionStorage.setItem("gameId", "game-2");
            // Retrieve
            // document.getElementById("result").innerHTML = sessionStorage.getItem("lastname");
            // } else {
            // document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            // }
            console.log(sessionStorage.getItem("gameId"));
        }
    });
});
