<?php
/* Template Name: Equipment */
?>

<?php
get_header();
?>

<?php if (have_rows('sections')) : ?>
	<?php while (have_rows('sections')) : the_row(); 
		$layout_name = get_row_layout();
		$template_part_path = get_stylesheet_directory() . '/template-parts/equipment/' . $layout_name . '.php';
			if (file_exists($template_part_path)) {
				include($template_part_path);
		}
	?>
	<?php endwhile; ?>
<?php endif; ?>


<?php
get_footer();
?>