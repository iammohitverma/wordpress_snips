let map;
var markers = [];
var infoWindows = [];

const styles = {
  default: [],
  silver: [
    {
      featureType: "all",
      elementType: "labels.text.fill",
      stylers: [
        {
          color: "#696969",
        },
      ],
    },
    {
      featureType: "administrative",
      elementType: "geometry",
      stylers: [
        {
          color: "#a7a7a7",
        },
      ],
    },
    {
      featureType: "administrative",
      elementType: "labels.text.fill",
      stylers: [
        {
          visibility: "on",
        },
        {
          color: "#737373",
        },
      ],
    },
    {
      featureType: "landscape",
      elementType: "geometry.fill",
      stylers: [
        {
          visibility: "on",
        },
        {
          color: "#efefef",
        },
      ],
    },
    {
      featureType: "poi",
      elementType: "geometry.fill",
      stylers: [
        {
          visibility: "on",
        },
        {
          color: "#dadada",
        },
      ],
    },
    {
      featureType: "poi",
      elementType: "labels",
      stylers: [
        {
          visibility: "off",
        },
      ],
    },
    {
      featureType: "poi",
      elementType: "labels.icon",
      stylers: [
        {
          visibility: "off",
        },
      ],
    },
    {
      featureType: "road",
      elementType: "labels.text.fill",
      stylers: [
        {
          color: "#696969",
        },
      ],
    },
    {
      featureType: "road",
      elementType: "labels.icon",
      stylers: [
        {
          visibility: "off",
        },
      ],
    },
    {
      featureType: "road.highway",
      elementType: "geometry.fill",
      stylers: [
        {
          color: "#ffffff",
        },
      ],
    },
    {
      featureType: "road.highway",
      elementType: "geometry.stroke",
      stylers: [
        {
          visibility: "on",
        },
        {
          color: "#b3b3b3",
        },
      ],
    },
    {
      featureType: "road.arterial",
      elementType: "geometry.fill",
      stylers: [
        {
          color: "#ffffff",
        },
      ],
    },
    {
      featureType: "road.arterial",
      elementType: "geometry.stroke",
      stylers: [
        {
          color: "#d6d6d6",
        },
      ],
    },
    {
      featureType: "road.local",
      elementType: "geometry.fill",
      stylers: [
        {
          visibility: "on",
        },
        {
          color: "#ffffff",
        },
        {
          weight: 1.8,
        },
      ],
    },
    {
      featureType: "road.local",
      elementType: "geometry.stroke",
      stylers: [
        {
          color: "#d7d7d7",
        },
      ],
    },
    {
      featureType: "transit.line",
      stylers: [
        {
          saturation: 100,
        },
        {
          color: "#117fa5",
        },
        {
          weight: 1.8,
        },
      ],
    },
    {
      featureType: "water",
      elementType: "geometry.fill",
      stylers: [
        {
          color: "#d3d3d3",
        },
      ],
    },
  ],
};

/*
function tabs_map(positions) {
    function initMap() {
        map = new google.maps.Map(document.getElementById("map"), {
            center: new google.maps.LatLng(positions[0].lat, positions[0].lng),//Setting Initial Position
            zoom: zoomVal,
            disableDefaultUI: true,
            fullscreenControl: true,
            zoomControl: true,
        });
        map.setOptions({
            styles: styles['silver']
        });
        // This event listener will call addMarker() when the map is clicked.
        map.addListener("click", (event) => {
            addMarker(event.latLng);
        });
        // add event listeners for the buttons

        // Adds a marker at the center of the map.
        for (let i = 0; i < positions.length; i++) {
            setMarkers(map, positions[i]);
        }
    }
    window.initMap = initMap;
} */

function tabs_map(positions) {
  console.log(positions);

  function initMap() {
    if (typeof google !== "undefined" && google.maps) {
      map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(positions[0].lat, positions[0].lng), // Setting Initial Position
        // zoom: zoomVal,
        zoom: typeof zoomVal !== "undefined" && zoomVal ? zoomVal : 12,
        disableDefaultUI: true,
        fullscreenControl: true,
        zoomControl: true,
      });
      map.setOptions({
        styles: styles["silver"],
      });
      // This event listener will call addMarker() when the map is clicked.
      map.addListener("click", (event) => {
        addMarker(event.latLng);
      });
      // Adds a marker at the center of the map.
      for (let i = 0; i < positions.length; i++) {
        setMarkers(map, positions[i]);
      }
    } else {
      // Retry until the Google Maps API is available
      setTimeout(initMap, 100); // Retry after 100 milliseconds
    }
  }
  // Attach the initMap function to the window object
  window.initMap = initMap;
  // Check if Google Maps API is already available
  if (typeof google !== "undefined" && google.maps) {
    initMap();
  } else {
    // Add a script tag for the Google Maps API if it doesn't exist
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&callback=initMap`;
    script.defer = true;
    document.head.appendChild(script);
  }
}

// to add new markers and remove previous one
function addnew_marker(new_positions) {
  deleteMarkers();
  new_center(new_positions);
  for (let i = 0; i < new_positions.length; i++) {
    setMarkers(map, new_positions[i]);
  }
}
//custom
function closeInfoWindows() {
  for (var index = 0; index < infoWindows.length; index++) {
    var infoWindow = infoWindows[index];
    infoWindow.close();
  }
}

// set information for markers
function getInfoWindow(location) {
  var imgUrl = location.image;
  var imgHtml = imgUrl
    ? '<img src="' +
      imgUrl +
      '" class="infowindow__img" style="max-width:100%">'
    : "";
  var contentString =
    '<div class="infowindow">' +
    imgHtml +
    '<div class="infowindow__content" style="text-align:center;">' +
    '<h3 class="infowindow__title">' +
    location.name +
    "</h3>" +
    '<p class="infowindow__address">' +
    location.address +
    "</p>" +
    "</div>" +
    "</div>";
  var infowindow = new google.maps.InfoWindow({
    content: contentString,
  });
  return infowindow;
}

// Sets the map on all markers in the array.
function setMapOnAll(map) {
  for (let i = 0; i < markers.length; i++) {
    markers[i].setMap(map);
  }
}

// Removes the markers from the map, but keeps them in the array.
function hideMarkers() {
  setMapOnAll(null);
}

// Deletes all markers in the array by removing references to them.
function deleteMarkers() {
  hideMarkers();
  markers = [];
}

//add markers on map
function setMarkers(map, positions) {
  const image = {
    url: "https://www.justcoglobal.com/wp-content/themes/janusjustco/assets/images/map-pin.png",
    // This marker is 40 pixels wide by 40 pixels high.
    size: new google.maps.Size(40, 40),
  };

  // for (let i = 0; i < positions.length; i++) {
  const position = positions;

  var marker = new google.maps.Marker({
    position: {
      lat: position.lat,
      lng: position.lng,
    },
    map,
    icon: image,
    disableDefaultUI: true,
  });
  marker.addListener("click", () => {
    closeInfoWindows();
    var infoWindow = getInfoWindow({
      name: position.name,
      address: position.address,
      image: position.image,
    });
    infoWindow.open({
      anchor: marker,
      map: map,
      shouldFocus: true,
    });
    infoWindows.push(infoWindow);
  });
  markers.push(marker);
}

//new center on map
function new_center(positions) {
  if (map) {
    map.setCenter({
      lat: positions[0].lat,
      lng: positions[0].lng,
    });
  } else {
    console.error("Map is not initialized.");
  }
}
