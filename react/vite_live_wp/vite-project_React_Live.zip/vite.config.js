import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vite.dev/config/
export default defineConfig({
  base: "/react/",
  plugins: [react()],
  build: {
    manifest: true, // Generates a manifest file
    outDir: "dist", // Output directory for the build
    rollupOptions: {
      input: "index.html", // Corrected the path to index.html
    },
    minify: "esbuild", // Minifies the build using esbuild (fast and efficient)
    sourcemap: true, // Generate sourcemaps for debugging
    assetsDir: "assets", // Folder for static assets
    chunkSizeWarningLimit: 500, // Optional: to avoid chunk size warnings
  },
  server: {
    historyApiFallback: true,
  },
});
