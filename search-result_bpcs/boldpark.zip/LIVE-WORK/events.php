<?php
/*
Template Name: Community/Events
*/
get_header(); // Load the header template
?>

<!-- Common banner secion inner pages  -->
<?php if (have_rows('news_and_resources_page_section')) :
    while (have_rows('news_and_resources_page_section')) : the_row();

        if (get_row_layout() == 'banner_section') : ?>
            <!--section class="app_process_banner bg_grey">
    <div class="banner_main">
       <?php get_template_part('template-parts/sections/banner_inner_pages'); ?>
    </div> 
</section-->
            <!-- Common banner secion inner pages  -->

            <section class="our_difference_newbanner cmn_new_banner bg_grey">
                <div class="container-fluid px-0">
                    <?php get_template_part('template-parts/sections/banner_inner_pages_new'); ?>
                </div>
            </section>

            <!-- 02 Section about difference Start-->
            <!-- 02 Section about difference Start-->
            <?php
             elseif (get_row_layout() == 'upcoming_events') :
                $section_heading = get_sub_field("section_heading");
            ?>
            <section class="events_resources pt_extra inner_event_resources">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="hdng">
                                <?php echo $section_heading;?>
                            </h2>
                        </div>
                    </div>
                    <div class="row">
                        <?php 

                            $args = array(
                                'post_type'=> 'events',
                                'posts_per_page' => 6
                            );              

                            $the_query = new WP_Query( $args );
                            if($the_query->have_posts() ) : 
                                while ( $the_query->have_posts() ) : 
                                $the_query->the_post(); 
                                $post_id = get_the_ID();
                                $thumbnail_url = '';
                                
                                if (has_post_thumbnail()) {
                                    $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                }

                                $eventDate = get_field( 'event_date', $post_id );
                                $blurb = get_field( 'blurb', $post_id );
                                $eventTitle = get_the_title(); 
                                $eventExcerpt = get_the_excerpt(); 
                                $contact_email = get_field( 'contact_email', $post_id );
                                $contact_phone = get_field( 'contact_phone', $post_id );
                            ?>

                                    <div class="col-12 col-sm-6 col-md-4 col-lg-4 mt-4">
                                        <div class="card_main">
                                            <div class="img_main">
                                                <img src="<?php echo $thumbnail_url;?>">
                                            </div>
                                            <div class="content_main">
                                                <div class="top_cont">
                                                    <p><?php echo $eventDate;?></p>
                                                    <p><?php echo $blurb;?></p>
                                                    <h3 class="card_hdng"><?php echo $eventTitle;?></h3>
                                                </div>
                                                <div class="content_mid">
                                                    <p>
                                                        <?php echo $eventExcerpt;?>
                                                    </p>
                                                </div>
                                                <div class="cont_bottom">
                                                    <p>contact</p>
                                                    <p>
                                                        <a href="mailto:<?php echo $contact_email;?>">
                                                            <?php echo $contact_email;?>
                                                        </a>    
                                                    </p>
                                                    <p>
                                                        <a href="tel:<?php echo $contact_phone;?>">
                                                            <?php echo $contact_phone;?>
                                                        </a>    
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php
                                // content goes here
                                endwhile; 
                                wp_reset_postdata(); 
                            else: 
                            endif;

                        ?>
                    </div>
                </div>
            </section>
            <?php
        elseif (get_row_layout() == 'calendar_section') :
            $section_heading = get_sub_field("section_heading");
			$calendar_iframe_html = get_sub_field("calendar_iframe_html");
        ?>
            <section class="calenderBox">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="hdng"><?php echo $section_heading; ?></h2>
                            <div class="bpcs_calander">
                                <!-- <img src="/wp-content/uploads/2023/08/calender.png" alt=""> -->
                                <?php echo $calendar_iframe_html; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- 02 Section about difference end-->
            <!-- 02 Section about difference end-->
        <?php
        elseif (get_row_layout() == 'question_section') :
        ?>
            <!-- Questions start-->
            <section class="questions_sec without_animation fees_page">
                <?php get_template_part('template-parts/sections/single_question'); ?>
            </section>
            <!-- Questions end-->


<?php
        endif;
    endwhile;
endif;
get_footer(); // Load the footer template 
?>