<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <div id="page" class="site">


        <header>
            <div class="container">
                <div class="inner">
                    <div class="logo_wrap">
                        <?php
                        $custom_logo_id = get_theme_mod('custom_logo');
                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                        //   if logo image does'nt exist call site title and tagline
                        if (has_custom_logo()) {
                            // Output custom logo manually with link
                            $logo_url = esc_url($logo[0]);
                            $home_url = esc_url(home_url('/'));
                            $site_name = esc_attr(get_bloginfo('name'));

                            echo '<a href="' . $home_url . '" title="' . $site_name . '" rel="home">';
                            echo '<img src="' . $logo_url . '" alt="' . $site_name . '">';
                            echo '</a>';
                        } else { ?>
                            <a href="<?php bloginfo('url'); ?>"
                                title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
                            <!-- <p><?php bloginfo('description'); ?></p> -->
                            <?php
                        }
                        ?>
                    </div>

                    <button class="toggle-menu"></button>

                    <div class="navigation_wrap">
                        <?php
                        wp_nav_menu(array(
                            'menu_class' => "header_menu",
                            'container' => "nav",
                            'theme_location' => "header_menu",
                            'before' => '<div class="a-Wrap">',
                            'after' => '</div>',
                        ));
                        ?>
                        <div class="header_btns">
                            <?php if (is_active_sidebar('header_btns')) { ?>
                                <?php dynamic_sidebar('header_btns'); ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </header>