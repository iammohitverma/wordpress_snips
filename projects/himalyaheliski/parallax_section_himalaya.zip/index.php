<?php
/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
/* require __DIR__ . '/wp-blog-header.php'; */
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Himalya Heliski</title>
    <link rel="icon" type="image/x-icon" href="./assets/images/favicon.png" />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
    />

    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    />

    <!-- orbitron font -->
    <link rel="stylesheet" href="./assets/fonts/orbitron/stylesheet.css" />
    <!-- chivo font -->
    <link rel="stylesheet" href="./assets/fonts/chivo/stylesheet.css" />
    <!-- custom css -->
    <link rel="stylesheet" href="./assets/css/theme-style.css" />
  </head>
  <body>
    <!-- header -->
    <header>
      <div class="container">
        <button class="menu_toggle">
          <span class="icon"></span>
          <span class="text_wrap">
            <b class="toggleText menuText">Menu</b>
            <b class="toggleText closeText">Close</b>
          </span>
        </button>
        <div class="slide_navigation">
          <div class="inner">
            <button class="menu_toggle">
              <span class="icon"></span>
              <span class="text_wrap">
                <b class="toggleText menuText">Menu</b>
                <b class="toggleText closeText">Close</b>
              </span>
            </button>
            <nav>
              <ul class="menu">
                <li>
                  <a href="#">Packages </a>
                </li>
                <li>
                  <a href="#">Infos</a>
                </li>
                <li>
                  <a href="#">About</a>
                </li>
                <li>
                  <a href="#">Contact</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>

    <!-- hero section -->
    <section class="parallax_hero_section">
      <div class="banner_slides" id="scene">
        <div class="banner_slide bg cover" data-depth="0.15">
          <img src="./assets/images/banner-himalaya.jpg" alt="" class="cover" />
        </div>
        <div class="banner_slide triangle cover" data-depth="0.4">
          <img
            src="./assets/images/triangle_01.png"
            alt="triangle_01"
            class="cover"
          />
        </div>
        <div class="banner_slide boy cover" data-depth="0.8">
          <img src="./assets/images/boy_01.png" alt="boy" class="cover" />
        </div>
        <div class="banner_slide himalya cover d-none" data-depth="0.6">
          <img
            src="./assets/images/himalaya_01.png"
            alt="himalaya"
            class="cover"
          />
        </div>
        <div class="banner_slide hima cover" data-depth="0.6">
          <img src="./assets/images/hima.png" alt="himalaya" class="cover" />
        </div>
        <div class="banner_slide laya cover" data-depth="0.6">
          <img src="./assets/images/laya.png" alt="himalaya" class="cover" />
        </div>
        <div class="banner_slide heliski cover" data-depth="0.7">
          <img
            src="./assets/images/heliski_01.png"
            alt="heliski_01"
            class="cover"
          />
        </div>
      </div>
    </section>

    <img src="./assets/images/Home3.jpg" alt="" />

    <footer class="d-none">
      <div class="container">
        <div class="top">
          <div class="row">
            <div class="col-lg-4">
              <div class="widget_box">
                <div class="img_wrap">
                  <a href="#" class="logo">
                    <img src="./assets/images/white-logo.png" alt="logo" />
                  </a>
                </div>
                <div class="text_wrap">
                  <p>
                    <strong>Over 30 Years of Powder Skiing Excellence</strong>
                  </p>
                  <p>
                    Since 1990, Manali has been our home and the launchpad for
                    one of the world’s most thrilling heli-skiing operations.
                  </p>
                </div>
                <ul class="sci">
                  <li>
                    <a href="#">
                      <i class="fa-brands fa-facebook-f"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa-brands fa-instagram"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="widget_box center mx-auto">
                <h3 class="heading">Explore</h3>
                <div class="menu">
                  <ul>
                    <li>
                      <a href="#">Home</a>
                    </li>
                    <li>
                      <a href="#">Info</a>
                    </li>
                    <li>
                      <a href="#">About</a>
                    </li>
                    <li>
                      <a href="#">Team</a>
                    </li>
                    <li>
                      <a href="#">Packages</a>
                    </li>
                    <li>
                      <a href="#">Contact</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="widget_box">
                <h3 class="heading">Address</h3>
                <p>
                  Himalayaheliski <br />
                  The Nest, Village Chadiyari <br />
                  PO Vashishat, Tehsil Manali, District Kullu <br />
                  Himachal Pradesh 175103, India
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="copyright text-center">
          <p>
            © Copyright 2025 by Himalayaheliski. Imprint
            <a href="#">Privacy Policy</a> powered by
            <a href="https://techmind.co.in/" target="_blank"
              >Techmind Softwares</a
            >
          </p>
        </div>
      </div>
    </footer>

    <!-- bootstrap script -->
    <script
      type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    ></script>

    <!-- parallax script -->
    <!-- <script src="./assets/parallax-master/src/parallax.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js"></script>

    <!-- gsap script -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/ScrollTrigger.min.js"></script>

    <!-- custom script -->
    <script src="./assets/js/custom-script.js"></script>
    <script>
      // Disable keyboard shortcuts like F12, Ctrl+Shift+I, Ctrl+U etc.
      document.onkeydown = function (e) {
        if (
          e.keyCode === 123 || // F12
          (e.ctrlKey && e.shiftKey && e.keyCode === 73) || // Ctrl+Shift+I
          (e.ctrlKey && e.shiftKey && e.keyCode === 74) || // Ctrl+Shift+J
          (e.ctrlKey && e.keyCode === 85) || // Ctrl+U
          (e.ctrlKey && e.keyCode === 83) // Ctrl+S
        ) {
          return false;
        }
      };

      // Disable right click
      document.addEventListener("contextmenu", (event) =>
        event.preventDefault()
      );
      // Disable drag events
      document.addEventListener("dragstart", function (e) {
        e.preventDefault();
      });
    </script>
  </body>
</html>
