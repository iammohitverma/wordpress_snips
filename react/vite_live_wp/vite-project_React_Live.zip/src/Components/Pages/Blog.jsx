import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import BlogPosts from "../Sections/BlogPosts";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Blog() {
  const {
    data: acfData,
    isLoading,
    isError,
    error,
  } = useFetchAcfData(123, "blog");

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <HelmetConfig
        title={"Blog Page - My Website"}
        description={"This is the Blog page of my website."}
      />

      {acfData &&
        acfData.map((block, index) => {
          switch (block.acf_fc_layout) {
            case "banner":
              return <Banner key={index} data={block} />;
            case "blog_posts":
              return <BlogPosts key={index} data={block} />;
            default:
              return null;
          }
        })}
    </>
  );
}
export default Blog;
