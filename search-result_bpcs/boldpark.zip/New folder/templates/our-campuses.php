<?php 
/*
Template Name: About/Our Campuses
*/

get_header(); // Load the header template

?>
<!-- Common banner secion inner pages  -->
<?php if( have_rows('our_campuses_page_section') ): ?>
    <?php while( have_rows('our_campuses_page_section') ): the_row(); ?>
    <?php 
        //Banner Section.
        if( get_row_layout() == 'banner_section' ): ?>
<!--section class="specialist_program our_campus_banner">
    <div class="banner_main">
        <?php //get_template_part( 'template-parts/sections/banner_inner_pages' );  ?>
    </div>
</section-->
<section class="our_difference_newbanner cmn_new_banner bg_camp">
    <div class="container-fluid px-0">
         <?php get_template_part('template-parts/sections/banner_inner_pages_new'); ?>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php
    // intentionally_section  layout.
        elseif( get_row_layout() == 'intentionally_section' ): 
            
    ?>
<!-- 02 Section about difference Start-->
<section class="about_oD pt_extra our_campus_about">
    <?php get_template_part( 'template-parts/sections/question_without_animation' ); ?>
</section>
<!-- 02 Section about difference end-->
<?php
    // maylands_location layout.
        elseif( get_row_layout() == 'maylands_location' ): 
            $maylands_heading = get_sub_field('section_heading');
            $maylands_sub_heading = get_sub_field('section_sub_heading');
    ?>
<!-- 03 Section about difference Start-->
<section class="ourCampusList">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng"><?php echo $maylands_heading; ?></h2>
                    <b><?php echo $maylands_sub_heading; ?></b>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>
        <?php if( have_rows('programs') ): 
            while ( have_rows('programs') ) : the_row(); 
            $program_image = get_sub_field('image');
            $program_heading = get_sub_field('heading');
            $program_desc = get_sub_field('description');
            $program_button = get_sub_field('button');
                $program_button_url = $program_button['url'];
                $program_button_title = $program_button['title']; ?>
            <div class="row bottom">
                <div class="col-12">
                    <img src="<?php echo $program_image['url'];?>" alt="">
                    <!-- <h4 class="hdng pl-25">
                        <--?php echo$program_heading; ?>
                    </h4> -->
                </div>
                <div class="col-12 col-sm-12 d-flex align-items-center">
                    <p class="pl-25">
                    <?php echo $program_desc; ?>
                    </p>
                </div>
                <div class="col-12 col-sm-12">
                    <a href="<?php echo esc_url( $program_button_url ); ?>" class="cmn_btn pr-25"><?php echo esc_html( $program_button_title ); ?></a>
                </div>
            </div>
            <?php  
                endwhile; 
                    endif; ?> 
    </div>
</section>
<!-- 03 Section about difference end-->
<?php
    // wembly layout.
        elseif( get_row_layout() == 'wembly' ): 
            $wembly_heading = get_sub_field('section_heading');
    ?>
<!-- 04 Section about difference Start-->
<section class="ourCampusList campusGrid bg_grey p_set">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                        <?php echo$wembly_heading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>
        <div class="row">
        <?php if( have_rows('program') ): 
                    $count = 0;
                    $postno = 1;
                    while (have_rows('program')) {
                          the_row();
                          $count++;    
                        }
                     while ( have_rows('program') ) : the_row(); 
                     $wembly_program_image = get_sub_field('image');
                     $wembly_program_heading = get_sub_field('heading');
                     $wembly_program_desc = get_sub_field('description');
                     $wembly_program_button = get_sub_field('button');
                         $wembly_program_button_url = $wembly_program_button['url'];
                         $wembly_program_button_title = $wembly_program_button['title']; ?>
            <div class="col-12 col-md-6 <?php if(($postno == $count)&&($count % 2)!=0) {?>col-md-12<?php } ?>">
                <div class="row bottom">
                    <div class="col-12">
                        <img src="<?php echo $wembly_program_image['url'];?>" alt="">
                        <h4 class="hdng pl-25">
                            <?php echo$wembly_program_heading; ?>
                        </h4>
                    </div>
                    <div class="col-12 col-sm-12 d-flex align-items-center">
                        <p class="pl-25">
                        <?php echo$wembly_program_desc; ?>
                        </p>
                    </div>
                    <div class="col-12 col-sm-12">
                    <a href="<?php echo esc_url( $wembly_program_button_url ); ?>" class="cmn_btn pr-25"><?php echo esc_html( $wembly_program_button_title ); ?></a>
                    </div>
                </div>
            </div>
            <?php  
            $postno++;
               endwhile; 
                endif; ?> 
        </div>
    </div>
</section>
<!-- 04 Section about difference end-->
<?php
    // specialist_program layout.
        elseif( get_row_layout() == 'specialist_program' ): 
            $specialist_heading = get_sub_field('section_heading');
    ?>
<!-- 04 Section about difference Start-->
<section class="ourCampusList campusGrid pb-0">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                        <?php echo$specialist_heading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>
        <div class="row">
        <?php if( have_rows('programs') ): 
                     while ( have_rows('programs') ) : the_row(); 
                     $specialist_program_image = get_sub_field('image');
                     $specialist_program_heading = get_sub_field('heading');
                     $specialist_program_desc = get_sub_field('description');
                     $specialist_program_button = get_sub_field('button');
                         $specialist_program_button_url = $specialist_program_button['url'];
                         $specialist_program_button_title = $specialist_program_button['title']; ?>
            <div class="col-12 col-md-6">
                <div class="row bottom">
                    <div class="col-12">
                        <img src="<?php echo $specialist_program_image['url'];?>" alt="">
                        <h4 class="hdng pl-25">
                            <?php echo$specialist_program_heading; ?>
                        </h4>
                    </div>
                    <div class="col-12 col-sm-12 d-flex align-items-center">
                        <p class="pl-25">
                        <?php echo$specialist_program_desc; ?>
                        </p>
                    </div>
                    <div class="col-12 col-sm-12">
                    <a href="<?php echo esc_url( $specialist_program_button_url ); ?>" class="cmn_btn pr-25"><?php echo esc_html( $specialist_program_button_title ); ?></a>
                    </div>
                </div>
            </div>
            <?php  
               endwhile; 
                endif; ?> 
        </div>
    </div>
</section>
<!-- 04 Section about difference end-->
<?php
    // join_us layout.
        elseif( get_row_layout() == 'join_us_section' ): 
    ?>
<section class="join_us pt-0">
<?php get_template_part( 'template-parts/sections/join_us' ); ?>
</section>

<!-- Questions start-->
<?php
    // apply_now layout.
        elseif( get_row_layout() == 'apply_now_section' ): 
    ?>
<section class="questions_sec">
<?php get_template_part( 'template-parts/sections/apply_now' ); ?>
</section>
<!-- Questions end-->

<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>
