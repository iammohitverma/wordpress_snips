<?php
/**
 * The template for displaying front page
 *
 * (Home Page of Website)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package twentytwentyonechild
 */
get_header();
?>

<div class="" id="home-page">
    <?php the_content(); ?>
</div>
<?php get_footer(); ?>