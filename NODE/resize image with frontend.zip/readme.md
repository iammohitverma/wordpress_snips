Image Resizer with Frontend
This project allows users to upload multiple images, resize them based on user input for width and height, and return the resized images. If only the width is provided, the height is automatically adjusted to maintain the aspect ratio.

Features:
Upload multiple images.

Resize images based on provided width and height.

Maintain aspect ratio if height is not provided.

Resized images are saved in a separate resized folder.

Requirements:
Node.js (Version 14 or higher recommended)

Install Dependencies:

This project uses express, sharp, multer, and path for file handling and image resizing. Install them with:

npm install
Running the Application:
Start the Server:

To start the server, run the following command:
node server.js

This will start the server at http://localhost:3000.

Access the Frontend:

Open your browser and navigate to:

http://localhost:3000
You will see an interface to upload multiple images, specify the width (and height if required), and get the resized images.

Upload and Resize Images:

Select images to upload.

Provide the desired width (and optional height).

Click the Resize Images button to start resizing.

The resized images will be available in the resized/ folder.

Folder Structure:
graphql
Copy
Edit
resize_image_with_frontend/
├── public/ # Frontend (HTML page)
│ └── index.html # HTML form to upload and resize images
├── uploads/ # Original uploaded images
├── resized/ # Resized images will be saved here
├── server.js # Backend API to handle resizing
├── package.json # Project dependencies
Dependencies:
express: For setting up the server and API.

sharp: For image resizing.

multer: For handling file uploads.

path: For file and folder path resolution.

Notes:
Ensure the resized/ folder exists or it will be created automatically when resizing starts.

Only images with valid extensions (e.g., .jpg, .png, etc.) will be accepted for resizing.

License:
This project is open source. Feel free to fork, modify, and use it in your applications!
