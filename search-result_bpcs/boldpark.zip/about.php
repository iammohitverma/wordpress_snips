<?php
/*
Template Name: About Page
*/

get_header(); // Load the header template

?>

<style>
header,
footer {
    display: none;
}
</style>

<section>
    <div class="container">
        <div class="our_mission_main">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mv_left">
                        <div class="m_heading">
                            <h3>Our mission,<br> vision, values</h3>
                        </div>
                        <div class="m_img">
                            <img src="/wp-content/uploads/2023/05/welcome_hero.png">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mv_right">
                        <h6>3 lines to summaries mission, vision & values: months to Year 9 and our Maylands campus
                            catering
                            for young adults in Years 10 to 12.</h6>
                        <p>Bold Park Community School was launched in 1998, from the shared desire of educators and
                            families
                            to reimagine the kind of place a school could be. In the search for what is best, for both
                            the
                            wellbeing and promotion of learning, our approach draws from many sources. Our foundational
                            influences include educational theorists such as John Dewey, Lev Vygotsky and Howard
                            Gardner;
                            along with best practice models seen in Reggio Emilia and the Forest Schools movement. From
                            these grounding influences we have developed our progressive pedagogical practice from early
                            childhood through to college. We remain dynamic and responsive to new research and the
                            contemporary context without loosing our grounding vision to re-imagine school. With a
                            strong
                            commitment to reflective practice and the professional growth of our staff we have developed
                            a
                            whole of school approach to education that has a firm foundation and strong identity of
                            putting
                            the 'child at the centre' of what we do.<br><br> Our students love being at school and never
                            want to
                            leave.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php get_footer(); // Load the footer template 
?>