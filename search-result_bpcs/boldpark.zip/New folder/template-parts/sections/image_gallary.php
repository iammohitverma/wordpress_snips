<?php
/**
 * Template part for displaying Image Gallery
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
    
$image_grid = get_sub_field("images");
?>
<div class="img_gallery_main">
    <div class="container">
        <div class="img_gallery_wrap">
            <?php 
            if( $image_grid ):
                foreach( $image_grid as $image ):
            ?>
                <figure>
                <img src="<?php echo $image['url'];  ?>" alt="img">    
                </figure>
            <?php 
                endforeach;            
            endif;
            ?>
        </div>
    </div>
</div>
<div id="myModal" class="modal">
  <span id="close">×</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>
        