<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://leads.tmdemo.in/api/leads/store',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 
  'name='.$name.'&father_name='.$father_name.'&dob='.$dob.'&email'.$email.'=&company_name='.$company_name.'&country_code='.$country_code.'&phone_number='.$phone.'&landline_number='.$landline_number.'&father_number='.$father_number.'&emergency_number='.$emergency_number.'&website_url='.$website_url.'&title='.$title.'&short_description='.$short_description.'&long_description='.$long_description.'&address='.$address.'&city='.$city.'&state='.$state.'&zip='.$zip.'&country='.$country.'&detail_1='.$detail_1.'&detail_2='.$detail_2.'&detail_3='.$detail_3.'&detail_4='.$detail_4.'&detail_5='.$detail_5.'&lead_transaction_id='.$lead_transaction_id.'&lead_transaction_date='.$lead_transaction_date.'&programme='.$programme.'&specialization='.$specialization.'&utm_source='.$utm_source.'&utm_medium='.$utm_medium.'&utm_campaignid='.$utm_campaignid.'&utm_adgroupid='.$utm_adgroupid.'&utm_creativeid='.$utm_creativeid.'&utm_matchtype='.$utm_matchtype.'&utm_device='.$utm_device.'&utm_network='.$utm_network.'&utm_keyword='.$utm_keyword.'&utm_keywordid='.$utm_keywordid.'&utm_campaign='.$utm_campaign.'&gad_source='.$gad_source.'&gbraid='.$gbraid.'&gclid='.$gclid,
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded',
    'Authorization: Bearer ef0CSohUPv1745922092'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
