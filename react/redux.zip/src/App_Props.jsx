import { useState } from "react";
import { ComA } from "./Props/ComA";

import "./App.css";

function App() {
  const name = "Mohit";

  const [count, setCount] = useState(0);
  const countUpdate = () => {
    setCount(count + 1);
    console.log("test");
  };

  return (
    <div className="box">
      <h1>Count: {count}</h1>
      <ComA name={name} countUpdate={countUpdate} />
    </div>
  );
}

export default App;
