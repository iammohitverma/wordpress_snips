<?php 
$content_editor = get_sub_field('content_editor');
?>
<section class="content_editor_section pb_60">
    <div class="container">
        <div class="content_editor_default">
            <?php echo $content_editor; ?>            
        </div>
    </div>
</section>