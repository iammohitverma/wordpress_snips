<?php
$limit = $attributes['limit'];
?>

<canvas id="growth_chart"></canvas>