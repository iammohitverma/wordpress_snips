// SinglePost.jsx
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Loader from "../Sections/Loader";

function SinglePost() {
  const { slug } = useParams(); // useParams hook nal URL parameter slug nu access kar rahe haan
  const baseUrl = import.meta.env.VITE_API_URL; // Base URL WordPress API da

  const [post, setPost] = useState(null); // Post da data
  const [loading, setLoading] = useState(true); // Loading status

  useEffect(() => {
    // useEffect hook jado slug badalda hai, API call karna
    const fetchPost = async () => {
      try {
        // WordPress API nu call kar rahe haan jithe slug parameter pass ho reha hai
        const res = await axios.get(`${baseUrl}/wp-json/wp/v2/posts`, {
          params: { slug },
        });

        const postData = res.data; // Post da data fetch ho gaya
        const singlePost = postData[0]; // Pehla post, kyunki WordPress array return karda hai

        // Featured image fetch kar rahe haan agar available ho
        if (singlePost?.featured_media) {
          try {
            const imgRes = await axios.get(
              `${baseUrl}/wp-json/wp/v2/media/${singlePost.featured_media}`
            );
            // Image URL set karna
            singlePost.featured_image_url = imgRes.data.source_url;
          } catch (imgErr) {
            console.warn("Image not fetched:", imgErr);
            singlePost.featured_image_url = null;
          }
        } else {
          singlePost.featured_image_url = null;
        }

        setPost(singlePost); // Post state nu update kar rahe haan
      } catch (err) {
        console.error("Failed to load post", err);
      } finally {
        setLoading(false); // Loading false karna jado data load ho jaye
      }
    };

    fetchPost(); // FetchPost function call kar rahe haan
  }, [slug]); // Slug change hote hi API call dobara chalegi

  if (loading) return <Loader />;
  if (!post) return <div>Post not found.</div>;

  return (
    <section className="single_post container">
      <h1 dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
      {post.featured_image_url && (
        <img
          src={post.featured_image_url}
          alt={post.title.rendered}
          style={{ width: "100%", marginBottom: "20px" }}
        />
      )}
      <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} />
    </section>
  );
}

export default SinglePost;
