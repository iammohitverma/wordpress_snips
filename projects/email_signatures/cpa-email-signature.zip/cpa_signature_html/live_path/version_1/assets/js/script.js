let copyBtn = document.querySelector(".copyBtn");
const copyFunction = () => {
  const signatureContent = document.querySelector(".table_wrap").innerHTML;

  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = signatureContent;
  document.body.appendChild(tempDiv);

  const range = document.createRange();
  range.selectNode(tempDiv);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);

  try {
    document.execCommand("copy");
    alert("Email signature copied to clipboard!");
  } catch (err) {
    console.error("Failed to copy: ", err);
  }

  document.body.removeChild(tempDiv);
};

copyBtn.addEventListener("click", copyFunction);
