function onPageLoad() {
  // // Get saved template from localStorage
  // const saved = localStorage.getItem("gjs-saved-template");

  // if (saved) {
  //   const { html, css } = JSON.parse(saved);

  //   // Inject CSS into a <style> tag in <head>
  //   const style = document.createElement("style");
  //   style.innerHTML = css;
  //   document.head.appendChild(style);

  //   // Inject saved HTML into the #frontend container
  //   const frontendContainer = document.getElementById("frontend");
  //   frontendContainer.innerHTML = html;
  // }

  // Get data from firebase realtime database 📥
  const userRef = firebase.database().ref("admin/builderData");
  userRef.once("value").then((snapshot) => {
    const data = snapshot.val();

    if (data) {
      const { html, css } = data;

      if (html || css) {
        const style = document.createElement("style");
        style.innerHTML = css;
        document.head.appendChild(style);

        const frontendContainer = document.getElementById("frontend");
        frontendContainer.innerHTML = html;
      }
    }
  });
}

window.addEventListener("load", onPageLoad);
