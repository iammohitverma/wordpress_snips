function afterPageLoad() {
  // Parallax Banner
  let parallaxInstance = null;

  function handleResponsiveBehavior() {
    const totalWidth = document.documentElement.clientWidth;

    if (totalWidth >= 992) {
      const scene = document.getElementById("scene");
      if (scene && !parallaxInstance) {
        parallaxInstance = new Parallax(scene);
      }
    } else {
      if (parallaxInstance) {
        parallaxInstance.disable(); // Disable Parallax behavior on small screens
        parallaxInstance = null;
      }
    }
  }
  handleResponsiveBehavior();
  window.addEventListener("resize", handleResponsiveBehavior);

  //   Header
  let header = document.querySelector("header");
  let body = document.querySelector("body");
  let menu_toggle = document.querySelectorAll(".menu_toggle");
  function openMenu(e) {
    menu_toggle.forEach((button) => {
      button.classList.toggle("active");
    });
    header.classList.toggle("active");
    body.classList.toggle("vh-100");
    body.classList.toggle("overflow-hidden");
  }
  menu_toggle.forEach((button) => {
    button.addEventListener("click", openMenu);
  });

  document.addEventListener("click", (e) => {
    if (
      !e.target.classList.contains("slide_navigation") &&
      !e.target.classList.contains("menu_toggle")
    ) {
      menu_toggle.forEach((button) => {
        button.classList.remove("active");
        header.classList.remove("active");
        body.classList.remove("vh-100");
        body.classList.remove("overflow-hidden");
      });
    }
  });
}
window.addEventListener("load", afterPageLoad);

// lightgallery js start
function initLightGallery() {
  lightGallery(document.getElementById("gallary_container"));
}
function afterWindowLoad() {
  initLightGallery({
    speed: 500,
    mode: "lg-fade",
    zoom: true,
    download: false,
  });
}
window.addEventListener("load", afterWindowLoad);

// Packages section slider
var swiper = new Swiper(".packages_slider .mySwiper", {
  slidesPerView: 1,
  spaceBetween: 0,
  pagination: {
    el: ".packages_slider .swiper-pagination",
    clickable: true,
  },
  breakpoints: {
    768: {
      slidesPerView: 2,
      spaceBetween: 30,
    },
  },
});
// lightgallery js end

// Get in touch animation start
$(".animate_tilt").tilt({
  glare: true,
  maxGlare: 0.5,
});
// Get in touch animation end

// data AOS init
AOS.init({
  disable: "mobile", // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
  duration: 2000, // values from 0 to 3000, with step 50ms
  easing: "ease-in-out-back", // default easing for AOS animations
  once: true, // whether animation should happen only once - while scrolling down
  mirror: false, // whether elements should animate out while scrolling past them
});

/*******************************************************************/
// Disable keyboard shortcuts like F12, Ctrl+Shift+I, Ctrl+U etc.
/*******************************************************************/
document.onkeydown = function (e) {
  if (
    e.keyCode === 123 || // F12
    (e.ctrlKey && e.shiftKey && e.keyCode === 73) || // Ctrl+Shift+I
    (e.ctrlKey && e.shiftKey && e.keyCode === 74) || // Ctrl+Shift+J
    (e.ctrlKey && e.keyCode === 85) || // Ctrl+U
    (e.ctrlKey && e.keyCode === 83) // Ctrl+S
  ) {
    return false;
  }
};

// Disable right click
document.addEventListener("contextmenu", (event) => event.preventDefault());
// Disable drag events
document.addEventListener("dragstart", function (e) {
  e.preventDefault();
});
