function Loader() {
  const loader = "/loader.gif";
  return (
    <>
      <div className="loader">
        <img src={loader} alt="" />
      </div>
    </>
  );
}
export default Loader;
