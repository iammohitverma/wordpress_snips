import { MyContext } from "./MyContext";

function MyProvider({ children }) {
  const myData = {
    fname: "Mohit",
    lname: "Verma",
  };
  return <MyContext.Provider value={myData}>{children}</MyContext.Provider>;
}

export { MyProvider };
