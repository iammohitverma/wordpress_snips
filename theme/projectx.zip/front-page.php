<?php
/**
 * The template for displaying front page
 *
 * (Home Page of Website)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package projectx-theme
 */
get_header();
?>




<!-- home banner -->
<section class="hero lg_banner pt_100 pb_100" style="--bgImage: url('/wp-content/uploads/2024/10/hero_banner.jpg')">
	<div class="container">
		<div class="content_wrap text-center">
			<h1 class="hdng fs_84 shape white top_center_shape d-block" style="--dataShape: url('/wp-content/uploads/2024/10/circle_shape.svg')">Good advice about <br> relationships</h1>
			<a href="#" class="arrow_btn">Talk to someone</a>
		</div>
	</div>
</section>


<!-- respectful relationships -->
<section class="two_col_section pt_120 pb_120" style="background-color: #ffffff">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="img_wrap">
					<img src="/wp-content/uploads/2024/10/respect_relationship.png" alt="">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="text_wrap">
					<h2 class="hdng fs_44 shape bottom_left_shape" style="--dataShape: url('/wp-content/uploads/2024/10/heading_shape_1.svg')">We help to build good
					respectful relationships</h2>
					<p>This website has you covered! It gives helpful tips on how to have good, respectful relationships with others romantic or not, how to take care of yourself and your friends if things get tough.</p>

					<ul class="icon_list">
						<li>
							<img src="/wp-content/uploads/2024/10/researchers_icon.svg" alt="">
							<p>Our co-researchers
							are aged from 16 to 18</p>
						</li>
						<li>
							<img src="/wp-content/uploads/2024/10/committee_approved.svg" alt="">
							<p>Human Research Ethics
							Committee Approved </p>
						</li>
						<li>
							<img src="/wp-content/uploads/2024/10/map_icon.svg" alt="">
							<p>Based in Boorloo - Perth,
							on Whadjuk Noongar lands</p>
						</li>
					</ul>

					<a href="#" class="arrow_btn mt_40">More About Us</a>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Relationships & Tips -->
<section class="relationship_tips_section pt_120 pb_120" style="background-color: #015B6D">
	<div class="one_side_container ms-auto">
		<div class="sec_heading">
			<h2 class="hdng white fs_44 shape bottom_right_shape" style="--dataShape: url('/wp-content/uploads/2024/10/heading_shape_1.svg')">Relationships & Tips</h2>
		</div>
		<div class="swiper" id="relationships_slider">
			<div class="swiper-wrapper">
				<div class="swiper-slide">
					<div class="tips_card">
						<div class="img_wrap">
							<img src="/wp-content/uploads/2024/10/relationships_2.png" alt="">
						</div>
						<div class="text_wrap">
							<h4 class="hdng white">Talk it Out</h4>
							<p>Make sure you're always honest and open with each other. Share what's on your mind and really listen to others.</p>
						</div>
					</div>
				</div>
				<div class="swiper-slide">
					<div class="tips_card">
						<div class="img_wrap">
							<img src="/wp-content/uploads/2024/10/relationships_2.png" alt="">
						</div>
						<div class="text_wrap">
							<h4 class="hdng white">Talk it Out</h4>
							<p>Make sure you're always honest and open with each other. Share what's on your mind and really listen to others.</p>
						</div>
					</div>
				</div>
				<div class="swiper-slide">
					<div class="tips_card">
						<div class="img_wrap">
							<img src="/wp-content/uploads/2024/10/relationships_2.png" alt="">
						</div>
						<div class="text_wrap">
							<h4 class="hdng white">Talk it Out</h4>
							<p>Make sure you're always honest and open with each other. Share what's on your mind and really listen to others.</p>
						</div>
					</div>
				</div>
				<div class="swiper-slide">
					<div class="tips_card">
						<div class="img_wrap">
							<img src="/wp-content/uploads/2024/10/relationships_2.png" alt="">
						</div>
						<div class="text_wrap">
							<h4 class="hdng white">Talk it Out</h4>
							<p>Make sure you're always honest and open with each other. Share what's on your mind and really listen to others.</p>
						</div>
					</div>
				</div>				
				<div class="swiper-slide">
					<div class="tips_card">
						<div class="img_wrap">
							<img src="/wp-content/uploads/2024/10/relationships_2.png" alt="">
						</div>
						<div class="text_wrap">
							<h4 class="hdng white">Talk it Out</h4>
							<p>Make sure you're always honest and open with each other. Share what's on your mind and really listen to others.</p>
						</div>
					</div>
				</div>				
			</div>	
		</div>
	</div>
	<div class="container">
		<div class="swiper-pagination"></div>
	</div>
</section>



<?php get_footer();?>

