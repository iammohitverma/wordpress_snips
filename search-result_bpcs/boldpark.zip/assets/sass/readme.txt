#1. variables.scss include all variable used through out the website 
#2. Container and global css found in Global.scss
#3. mixin.scss file include all functios that are used in website 
#4. Header Fotter css found in hdr-ftr.scss
#5. body.scss file include all css reladed to body html except header and footer 

#HOW TO USE MIXINS

    # use for common paddings - pass parameters 
    @include cmn_paddings_m(padding-top-value, padding-bottom-value);

    # use for common Buttons 
    @include cmn_btns_m;

    # use for common [paragraph style] - pass parameters 
    @include g_para_m(text-transform-value);

    # use for all common heading - pass parameter in this sequence font-size,line-height,font-weight,color */
    @include g_hdng_m(30px, 10px, 500, $black);

    # use for all bg images - pass parameter in this sequence path, size, position,repeat */
    bg_image_m(../images/image.png, cover, center center, no-repeat)