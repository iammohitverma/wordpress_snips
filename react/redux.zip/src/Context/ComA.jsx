import ComB from "./ComB";
function ComA() {
  return <ComB />;
}
export { ComA };
