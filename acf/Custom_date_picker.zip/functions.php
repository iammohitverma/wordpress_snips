<?php

function get_event_slots_for_date()
{
    if (isset($_POST['date'])) {
        $selected_date = $_POST['date'];  // This is now in 'YYYY-MM-DD' format

        // 77 is the page/post ID which is required to get the ACF field's data
        $pageID = "77";
        $slots_data = [];
        if (have_rows('event_booking', $pageID)):
            while (have_rows('event_booking', $pageID)):
                the_row();
                $date_value = get_sub_field('date_time_picker');
                // Compare the two dates
                if ($date_value == $selected_date) {
                    $full_day_booking = get_sub_field('full_day_booking');
                    $event_slots = get_sub_field('event_slots');
                    if ($event_slots && $full_day_booking == "no") {
                        foreach ($event_slots as $row) {
                            $start_time = $row['start_time'];
                            $end_time = $row['end_time'];
                            $slots_data[] = [
                                'start_time' => $start_time,
                                'end_time' => $end_time
                            ];
                        }
                    }
                }
            endwhile;
        else:
        endif;

        // Respond with JSON
        echo json_encode($slots_data);
    }
    wp_die();  // Always call wp_die() after an AJAX request
}
add_action('wp_ajax_get_event_slots_for_date', 'get_event_slots_for_date');
add_action('wp_ajax_nopriv_get_event_slots_for_date', 'get_event_slots_for_date');