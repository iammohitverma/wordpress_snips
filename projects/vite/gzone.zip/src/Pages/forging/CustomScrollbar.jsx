import React, { useEffect, useRef } from 'react';

const CustomScrollbar = () => {
    const scrollThumbRef = useRef(null);
    const scrollBarRef = useRef(null);

    useEffect(() => {
        const scrollThumb = scrollThumbRef.current;
        const scrollBar = scrollBarRef.current;
        const heightContainer = document.querySelector(".player_cards_wrap");

        // Function to update thumb height and position
        function updateThumb() {
            const containerHeight = heightContainer.clientHeight; // Height of the scrolling container
            const contentHeight = heightContainer.scrollHeight; // Total height of content
            const scrollBarHeight = scrollBar.clientHeight; // Height of the scrollbar

            // Calculate the thumb height based on the visible content vs total content
            const thumbHeight = Math.max((containerHeight / contentHeight) * scrollBarHeight, 30); // Minimum thumb height set to 30px
            scrollThumb.style.height = `${thumbHeight}px`;

            updateThumbPosition(); // Update position of the thumb
        }

        // Function to update thumb position based on scroll
        function updateThumbPosition() {
            const scrollY = heightContainer.scrollTop; // Current scroll position of the container
            const containerHeight = heightContainer.clientHeight; // Height of the scrolling container
            const contentHeight = heightContainer.scrollHeight; // Total height of content
            const scrollBarHeight = scrollBar.clientHeight; // Height of the scrollbar
            const thumbHeight = scrollThumb.clientHeight; // Height of the thumb (updated)

            // Calculate max scroll and thumb position
            const maxScroll = contentHeight - containerHeight;
            const maxThumbPosition = scrollBarHeight - thumbHeight;

            // Update thumb position
            const thumbPosition = (scrollY / maxScroll) * maxThumbPosition;
            scrollThumb.style.transform = `translateY(${thumbPosition}px)`;
        }

        // Initialize scroll event listener
        function initScroll() {
            heightContainer.addEventListener("scroll", updateThumbPosition);
            window.addEventListener("resize", updateThumb); // Recalculate on window resize
            updateThumb(); // Initial update
        }

        initScroll();

        // Common drag logic for mouse and touch
        function startDrag(e) {
            e.preventDefault();
            const startY = e.clientY || e.touches[0].clientY;
            const startScrollTop = heightContainer.scrollTop;
            const thumbHeight = scrollThumb.clientHeight;
            const scrollBarHeight = scrollBar.clientHeight;
            const maxScroll = heightContainer.scrollHeight - heightContainer.clientHeight;

            function onDragMove(e) {
                const currentY = e.clientY || e.touches[0].clientY;
                const deltaY = currentY - startY;

                // Calculate new scroll position based on the thumb movement
                const thumbPosition = (startScrollTop + deltaY * (maxScroll / (scrollBarHeight - thumbHeight))) || 0;
                heightContainer.scrollTop = Math.max(0, Math.min(thumbPosition, maxScroll));

                // Update the thumb position
                updateThumbPosition();
            }

            function stopDrag() {
                document.removeEventListener("mousemove", onDragMove);
                document.removeEventListener("mouseup", stopDrag);
                document.removeEventListener("touchmove", onDragMove);
                document.removeEventListener("touchend", stopDrag);
            }

            document.addEventListener("mousemove", onDragMove);
            document.addEventListener("mouseup", stopDrag);
            document.addEventListener("touchmove", onDragMove);
            document.addEventListener("touchend", stopDrag);
        }

        scrollThumb.addEventListener("mousedown", startDrag);
        scrollThumb.addEventListener("touchstart", startDrag);

        // Clean up event listeners on unmount
        return () => {
            heightContainer.removeEventListener("scroll", updateThumbPosition);
            window.removeEventListener("resize", updateThumb);
            scrollThumb.removeEventListener("mousedown", startDrag);
            scrollThumb.removeEventListener("touchstart", startDrag);
        };
    }, []); // Empty array ensures this only runs once on mount

    return (
        <div className="scroll_bar" ref={scrollBarRef}>
            <button className="scroll_thumb" ref={scrollThumbRef}>
                <img src="/Forge_Main_Screen_Scrollbar_Scroller_2.png" alt="scroll_thumb" className="scroll_thumb_img" />
            </button>
        </div>
    );
};

export default CustomScrollbar;
