<?php

// -----------------------------
// Remove Parent Theme Styles
// -----------------------------

// Dequeue and deregister the parent theme's main stylesheet
function dequeue_twentytwentyone_parent_style()
{
    wp_dequeue_style('twenty-twenty-one-style'); // Remove Twenty Twenty-One main style
    wp_deregister_style('twenty-twenty-one-style'); // Unregister the style completely
}
add_action('wp_enqueue_scripts', 'dequeue_twentytwentyone_parent_style', 20); // Run after parent styles are added

// -----------------------------
// Enqueue Child Theme Styles & Scripts
// -----------------------------

function twentytwentyone_child_scripts()
{

    // check if woocommerce is activated in website start
    $ifWooActivate = false;
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        $ifWooActivate = true;
    } else {
        $ifWooActivate = false;
    }
    // check if woocommerce is activated in website end

    if ($ifWooActivate) {
        wp_enqueue_style('jagsness-woocommerce-style', get_stylesheet_directory_uri() . '/assets/woocommerce/style.css', false, _JN_VERSION, 'all');
    }

    // Optional: Dequeue some additional styles from parent theme
    wp_dequeue_style('twentytwentyone-block-style'); // Remove block style
    wp_dequeue_style('twentytwentyone-print-style'); // Remove print style

    // Enqueue child theme main style (style.css)
    wp_enqueue_style('child-style', get_stylesheet_uri());

    // Enqueue custom fonts
    wp_enqueue_style('font-forum-style', get_stylesheet_directory_uri() . '/assets/fonts/forum/stylesheet.css', '', true);
    wp_enqueue_style('font-dmsans-style', get_stylesheet_directory_uri() . '/assets/fonts/dm_sans/stylesheet.css', '', true);

    // Enqueue Bootstrap 5.3.7 CSS
    wp_enqueue_style('bootstrap-5.3.7-style', get_stylesheet_directory_uri() . '/assets/bootstrap-5.3.7-dist/css/bootstrap.min.css', '', true);

    // Enqueue Font Awesome 7 CSS
    wp_enqueue_style('fontawesome-free-7.0.0-style', get_stylesheet_directory_uri() . '/assets/fontawesome-free-7.0.0-web/css/all.min.css', '', true);

    // Enqueue Owl Carousel CSS (core and theme)
    wp_enqueue_style('OwlCarousel2-2.3.4-style', get_stylesheet_directory_uri() . '/assets/OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css', '', true);
    wp_enqueue_style('OwlCarousel2-2.3.4-theme-style', get_stylesheet_directory_uri() . '/assets/OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css', '', true);

    // Enqueue Base CSS
    wp_enqueue_style('theme-style', get_stylesheet_directory_uri() . '/assets/css/theme-style.css', array(), null);

    // Enqueue SASS CSS (if needed)
    // wp_enqueue_style('sass-style', get_stylesheet_directory_uri() . '/assets/css/sass-style.css', array(), null);

    // jQuery
    wp_enqueue_script('jquery-3_7_1-script', get_stylesheet_directory_uri() . '/assets/js/jquery-3.7.1.min.js', '', true);

    // Enqueue Bootstrap JS bundle
    wp_enqueue_script('bootstrap-5.3.7-script', get_stylesheet_directory_uri() . '/assets/bootstrap-5.3.7-dist/js/bootstrap.bundle.min.js', '', true);

    // Enqueue Owl Carousel JS
    wp_enqueue_script('OwlCarousel2-2.3.4-script', get_stylesheet_directory_uri() . '/assets/OwlCarousel2-2.3.4/dist/owl.carousel.min.js', '', true);

    // Chart JS library for charts
    wp_enqueue_script('chart-js-script', get_stylesheet_directory_uri() . '/assets/js/chart.min.js', '', true);

    // Chart JS labels library for charts
    wp_enqueue_script('chart-js-labels-script', get_stylesheet_directory_uri() . '/assets/js/chartjs-plugin-datalabels@2.js', '', true);

    // Enqueue your custom theme JS
    wp_enqueue_script('my-custom-script', get_stylesheet_directory_uri() . '/assets/js/theme-script.js', '', true);
}
add_action('wp_enqueue_scripts', 'twentytwentyone_child_scripts'); // Enqueue all assets
