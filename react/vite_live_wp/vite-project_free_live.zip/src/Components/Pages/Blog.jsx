import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import BlogPosts from "../Sections/BlogPosts";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Blog() {
  const { acfData, loading, error } = useFetchAcfData(123, "blog");

  if (loading) {
    return <Loader />; // Loading state dikhao jab data aaraha ho
  }

  if (error) {
    return <p>Error: {error}</p>; // Error message dikhao agar API fail ho
  }

  return (
    <>
      <HelmetConfig
        title={"Blog Page - My Website"}
        description={"This is the Blog page of my website."}
      />

      {acfData.map((block, index) => {
        switch (block.acf_fc_layout) {
          case "banner":
            return <Banner key={index} data={block} />;
          case "blog_posts":
            return <BlogPosts key={index} data={block} />;
          default:
            return null;
        }
      })}
    </>
  );
}
export default Blog;
