<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package himalayaheliski-theme
 */

?>


<?php
    // Book your trip section is global section path below
    $book_your_trip_section = get_field('book_your_trip_section');
    if($book_your_trip_section == 'show'){
        include  get_template_directory(). '/template-parts/global_book_your_trip/book_your_trip.php';
    }
?>

<footer>
    <div class="top pt_60 pb_40">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="widget_box left">
                        <div class="heading_wrap">
                            <h4 class="main_heading hr_70 fs_42 text-white">
                                <?php echo get_field('contact_heading', 'option');?>
                            </h4>
                        </div>
						<div class="content_editor_default">
                            <?php echo get_field('address', 'option');?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="widget_box center">
                        <div class="heading_wrap">
                            <h4 class="main_heading hr_70 fs_42 text-white">
                                <?php echo get_field('partner_heading', 'option');?>
                            </h4>
                        </div>
                        <?php if( have_rows('partner_logos', 'option') ): ?>
                            <div class="logos_wrap">
                                <?php while( have_rows('partner_logos', 'option') ): the_row(); 
                                    $logo_url = get_sub_field('logo_url', 'option');
                                    $logo = get_sub_field('logo', 'option');
                                    ?>
                                    <a href="<?php echo $logo_url;?>" class="logo">
                                        <img src="<?php echo $logo['url']?>" alt="<?php echo $logo['alt']?>">
                                    </a>
                                <?php endwhile; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="widget_box right">
                        <?php if( have_rows('social_icons', 'option') ): ?>
                            <ul class="sci">
                                <?php while( have_rows('social_icons', 'option') ): the_row(); 
                                    $icon_url = get_sub_field('icon_url', 'option');
                                    $icon = get_sub_field('icon', 'option');
                                    ?>
                                    <li>
                                        <a href="<?php echo $icon_url;?>">
                                            <?php echo $icon;?>
                                        </a>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php endif; ?>
                     
                       <p><?php echo get_field('copyright_text', 'option');?></p>
                       <?php
                            $footer_menu = get_field('footer_menu', 'option');
                            if($footer_menu == "show"){
                                wp_nav_menu(  array(
                                    'theme_location'    => "footer", 
                                ) );
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <p><a href="mailto:<?php echo get_field('footer_email', 'option');?>"><?php echo get_field('footer_email', 'option');?></a></p>
        </div>
    </div>
</footer>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>
