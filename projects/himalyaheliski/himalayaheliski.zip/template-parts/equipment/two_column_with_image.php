<?php  
$content = get_sub_field('content');
$image = get_sub_field('image');
?>

<section class="two_column_with_image pb_100">
    <div class="container">
        <div class="row flex-md-row flex-column-reverse">
            <div class="col-md-6 flex-grow-1">
                <div class="content_editor_default">
                    <?php echo $content; ?>
                </div>
            </div>
            <?php if($image): ?>
                <div class="col-md-6">
                    <div class="img_wrap">
                        <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['url']; ?>" class="cover">
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>