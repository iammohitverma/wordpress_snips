const Profile = () => {
    return (
        <div className="profile_wrap">
            <div className="profile_head">
                <div className="profile_image">
                    <img src="/player_card_image.png" alt="player_card_image" />
                </div>
                <div className="profile_info">
                    <div className="info">
                        <span className="hdng">Token Id: &nbsp;</span>
                        <span className="textBlue">546843</span>
                    </div>
                    <div className="info">
                        <span className="hdng">Owner: &nbsp;</span>
                        <span className="textBlue">Anonymous</span>
                    </div>
                    <div className="info">
                        <span className="hdng">Class: &nbsp;</span>
                        <span className="textBlue">Artisan</span>
                    </div>
                    <div className="info">
                        <span className="hdng">Subclass: &nbsp;</span>
                        <span className="textBlue">Blacksmith</span>
                    </div>
                    <div className="red_channel">1 Chevron</div>
                </div>
            </div>
            <div className="profile_body">
                <div className="two_col_row">
                    <div className="col">
                        <div className="info">
                            <span className="hdng">Current Action : &nbsp;</span>
                            <span className="textBlue">Blacksmith</span>
                        </div>
                    </div>
                    <div className="col">
                        <div className="info">
                            <span className="hdng">Time Remaining : &nbsp;</span>
                            <span className="textBlue">00:00:17</span>
                        </div>
                    </div>
                </div>
                <div className="two_col_row">
                    <div className="col">
                        <div className="level_box">
                            <span className="hdng">Level : &nbsp;</span>
                            <span className="textRed">Blacksmith</span>
                        </div>
                    </div>
                    <div className="col">
                        <div className="level_box">
                            <span className="hdng">Time Remaining : &nbsp;</span>
                            <span className="textRed">00:00:17</span>
                        </div>
                    </div>
                </div>
                <div className="recharge_wrap">
                    <div className="progress_area">
                        <div className="info">
                            <span className="hdng">Energy Level : &nbsp;</span>
                            <span className="textBlue">00:00:17</span>
                        </div>
                        <div className="progressbar_wrap" style={{ "--dataPercent": "50%" }}>
                            <div className="progressbar_inner top" style={{ "--progressBackground": "#f65666" }}>
                                <div className="progress_bar" style={{ "--progressColor": "#38dfdb" }}></div>
                            </div>
                            <div className="progressbar_inner bottom" style={{ "--progressBackground": "#f65666" }}>
                                <div className="progress_bar" style={{ "--progressColor": "#38dfdb" }}></div>
                            </div>
                        </div>
                    </div>
                    <button className="recharge_btn">Recharge</button>
                </div>
                <div className="results_wrap">
                    <div className="info">
                        <span className="hdng">Last Forge Attempt : &nbsp;</span>
                        <span className="textBlue">00:00:17</span>
                    </div>
                    <div className="info">
                        <span className="hdng">Class : &nbsp;</span>
                        <span className="textBlue">00:00:17</span>
                    </div>
                    <div className="info">
                        <span className="hdng">Type : &nbsp;</span>
                        <span className="textBlue">ACE</span>
                    </div>
                    <div className="info results">
                        <span className="hdng">Result : &nbsp;</span>
                        <span className="textBlue">Success</span>
                    </div>
                </div>
                <div className="result_icon">
                    <img src="/rare.png" alt="resultImage" />
                    <span className="modelName">Ace Blade</span>
                    <span className="modelNumber">5014056</span>
                </div>
            </div>
        </div>
    )
}
export default Profile;