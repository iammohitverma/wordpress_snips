import React from 'react'
import Header from "./Components/Header";
import CustomScrollbar from "./CustomScrollbar";
import PlayerCard from "./Components/MainScreen/PlayerCard";
import PlayerData from "./Components/MainScreen/PlayerData";
import './ForgingStyle.css';

const backgroundImage = {
    background: `url("/Forging_Background.jpg") no-repeat center / cover`,
};
const backgroundFrame = {
    background: `url("/Forge_Main_Screen_Border_Black_Back.png") no-repeat center / 100% 100%`,
};

function MainScreen() {
    return (
        <>
            <Header />
            <section className="gaming_screen_mv" style={backgroundImage}>
                <div className='container_mv'>
                    <div className="forge_main">
                        <div className="title_area">
                            <div className="screen_badge">
                                <img src="/Forge_Main Screen_Icon.png" alt="Icon" />
                            </div>
                            <h1 className="screen_title">
                                <img src="/Forge_Main_Screen_Title.png" alt="The Forge" />
                            </h1>
                        </div>
                        <div className="player_container" style={backgroundFrame}>
                            <CustomScrollbar />

                            <div className="player_cards_wrap">
                                {
                                    PlayerData.map(element => {
                                        return (
                                            <PlayerCard
                                                key={element.id}
                                                cardImage={element.cardImage}
                                                cryptoplan={element.cryptoplan}
                                                playerclass={element.playerclass}
                                                subclass={element.subclass}
                                            />
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default MainScreen;