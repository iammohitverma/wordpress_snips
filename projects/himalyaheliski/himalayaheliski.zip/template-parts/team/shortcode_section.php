<?php
    $shortcode = get_sub_field('shortcode');
    echo do_shortcode( $shortcode );
?>