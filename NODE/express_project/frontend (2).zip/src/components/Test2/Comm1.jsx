import React, { useState } from "react";
import { useTest } from '../../context/TestContext';
import { Link } from "react-router-dom";

export default function Comm1() {
    const { testData, setTestData } = useTest();

    const handleChange = (e) => {
        const { name, value } = e.target;

        setTestData((prev) => {
            const updatedData = { ...prev, [name]: value };
            console.log('Updated Test Data:', updatedData);  // Debug log

            return updatedData;
        });
    };



    return (
        <div className="min-h-screen bg-gradient-to-b from-[#FFF9F0] to-[#F7E9D7] flex justify-center items-start py-16 px-4">
            <div className="w-full max-w-3xl bg-white rounded-lg shadow-md border border-gray-200 p-8">
                {/* Header panel with logo and step info */}
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center space-x-2">
                        {/* Logo flame icon */}
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-6 w-6 text-orange-500"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2}
                            aria-hidden="true"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M12 3c0 2.993-3 5-3 8a3 3 0 006 0c0-3-3-5-3-8z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M12 12c0-1.105-1-2-1-2s1 2 1 4a1 1 0 102 0c0-1.333-2-2-2-2z"
                            />
                        </svg>
                        <span className="font-semibold text-gray-900 text-lg">
                            Candle Burn-Test Log
                        </span>
                    </div>

                    <div className="text-sm text-gray-500 select-none">
                        Step 1 of 4
                        <span className="inline-flex ml-3 space-x-1">
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                            <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                            <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                        </span>
                    </div>
                </div>

                {/* Form content */}
                <div>
                    <h2 className="font-semibold text-gray-900 mb-6 text-xl">
                        Material Details
                    </h2>

                    {/* Input field: Wick Supplier */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Wick Supplier:
                        </span>
                        <input
                            type="text"
                            name="Wick"
                            value={testData.Wick || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., XYZ Wick Co."
                        />
                    </label>

                    {/* Input field: Fragrance Oil Name */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Fragrance Oil Name:
                        </span>
                        <input
                            type="text"
                            name="Fragrance"
                            value={testData.Fragrance || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., Lavender Bliss"
                        />
                    </label>

                    {/* Input field: Volume & Percentage Load */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Volume & Percentage Load (e.g., 10ml, 8%):
                        </span>
                        <input
                            type="text"
                            name="Volume"
                            value={testData.Volume || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 10ml, 8%"
                        />
                    </label>

                    {/* Input field: Fragrance Supplier */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Fragrance Supplier:
                        </span>
                        <input
                            type="text"
                            name="FragranceSupplier"
                            value={testData.FragranceSupplier || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., ScentWorks"
                        />
                    </label>

                    {/* Input field: Use Dye Color */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Use Dye Color? (Yes/No):
                        </span>
                        <select
                            name="UseDyeColor"
                            value={testData.UseDyeColor || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                        >
                            <option value="No">No</option>
                            <option value="Yes">Yes</option>
                        </select>
                    </label>

                    {/* Input field: Use Dye Stabilizer */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Use Dye Stabilizer? (Yes/No):
                        </span>
                        <select
                            name="UseDyeStabilizer"
                            value={testData.UseDyeStabilizer || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                        >
                            <option value="No">No</option>
                            <option value="Yes">Yes</option>
                        </select>
                    </label>

                    {/* Input field: Wax Melting Temperature */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Wax Melting Temperature (*C):
                        </span>
                        <input
                            type="number"
                            name="WaxMeltingTemperature"
                            value={testData.WaxMeltingTemperature || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 75"
                        />
                    </label>

                    {/* New Input field: Blending Temperature */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Blending Temperature (*C):
                        </span>
                        <input
                            type="number"
                            name="BlendingTemperature"
                            value={testData.BlendingTemperature || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 70"
                        />
                    </label>

                    {/* New Input field: Pouring Temperature */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Pouring Temperature (*C):
                        </span>
                        <input
                            type="number"
                            name="PouringTemperature"
                            value={testData.PouringTemperature || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 60"
                        />
                    </label>

                    {/* New Input field: Cooling Time */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Cooling Time (hours):
                        </span>
                        <input
                            type="number"
                            name="CoolingTime"
                            value={testData.CoolingTime || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 2"
                        />
                    </label>

                    {/* New Input field: Container Type */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Container Type:
                        </span>
                        <input
                            type="text"
                            name="ContainerType"
                            value={testData.ContainerType || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., Oxford Style Candle Jar"
                        />
                    </label>

                    {/* New Input field: Container Supplier */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Container Supplier:
                        </span>
                        <input
                            type="text"
                            name="ContainerSupplier"
                            value={testData.ContainerSupplier || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., Wic Supplies"
                        />
                    </label>

                    {/* New Input field: Container Size */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">
                            Container Size:
                        </span>
                        <input
                            type="text"
                            name="ContainerSize"
                            value={testData.ContainerSize || ''} onChange={handleChange}
                            className="
                w-full 
                border 
                border-gray-300 
                rounded-md 
                px-3 
                py-2 
                text-gray-900 
                placeholder-gray-400 
                focus:outline-none 
                focus:border-blue-600 
                focus:ring-1 
                focus:ring-blue-600
                transition-shadow
                hover:shadow-md
                hover:border-blue-500
              "
                            placeholder="e.g., 8oz, 250ml"
                        />
                    </label>

                    {/* Placeholder space for future inputs */}
                    <div className="mt-8 border-t border-gray-200 pt-6 text-gray-400 italic text-center">
                        <div className="flex justify-between items-center mt-4">
                            <Link to={"/home/test-1"} className="bg-red-500 text-white px-4 py-2 rounded-lg">Back</Link>

                            <Link to={"/home/test-3"} className="bg-green-500 text-white px-4 py-2 rounded-lg">Next</Link>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
