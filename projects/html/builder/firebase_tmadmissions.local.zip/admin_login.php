<?php
session_start();

// Hardcoded admin credentials (for demo purposes)
$ADMIN_USERNAME = 'admin';
$ADMIN_PASSWORD = 'admin@123#'; // Change to a strong password!

// Get JSON input from fetch (if using fetch API)
$input = json_decode(file_get_contents('php://input'), true);

$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

// Basic validation
if ($username === $ADMIN_USERNAME && $password === $ADMIN_PASSWORD) {
    // Set session variable to mark user as logged in
    $_SESSION['admin_logged_in'] = true;
    echo json_encode(['success' => true, 'message' => 'Login successful']);
} else {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
}
?>

