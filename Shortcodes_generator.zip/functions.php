<?php
/**
 * shortcode_generator.
 */
require get_template_directory() . '/inc/shortcode_generator_cpt.php';
require get_template_directory() . '/inc/shortcode_generator_function.php';

