document.addEventListener("DOMContentLoaded", function () {
  const cssStyles = [
    "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css",
    "./assets/css/custom-style.css",
  ];
  const jsScripts = ["https://code.jquery.com/jquery-3.6.0.min.js"];
  const editor = grapesjs.init({
    container: "#gjs",
    fromElement: true, // This loads the existing HTML as editable components
    width: "100%",
    height: "100vh",
    storageManager: {
      id: "gjsdata-", // Prefix for localStorage keys
      type: "local", // Save to localStorage
      autosave: false, // Auto-save on changes
      autoload: true, // Load saved data on init
      stepsBeforeSave: 1, // Save after every change
    },
    plugins: ["gjs-blocks-basic"],
    pluginsOpts: {
      "gjs-blocks-basic": {},
    },
    canvas: {
      styles: cssStyles,
      scripts: jsScripts,
    },
    // Disable telemetry to avoid the 400 error
    telemetry: false,
  });

  // ✅ custom blocks
  editor.BlockManager.add("my-block", {
    label: "2 Columns mohit",
    content: `<div class="row"><div class="col">Column 1</div><div class="col">Column 2</div></div>`,
    category: "Layout",
  });

  // Add custom button to the panel ✅
  editor.Panels.addButton("options", {
    id: "download-html",
    className: "fa-solid fa-download",
    command: "download-html",
    attributes: { title: "Download HTML" },
  });

  // Define the download command
  editor.Commands.add("download-html", {
    run(editor) {
      const html = editor.getHtml();
      const css = editor.getCss();
      const fullHtml = `
        <!DOCTYPE html>
        <html>
          <head>
              <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
              />
              <link
                href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
                rel="stylesheet"
              />
              <link rel="stylesheet" href="./assets/css/custom-style.css" />
            <style>${css}</style>
          </head>
          <body>
            ${html}
          </body>
        </html>
      `;

      const blob = new Blob([fullHtml], { type: "text/html" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "template.html";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
  });

  // Add Save Template button ✅
  editor.Panels.addButton("options", [
    {
      id: "save-template",
      className: "fa fa-save",
      command: "save-template",
      attributes: { title: "Save Template" },
    },
  ]);

  // Save Template command
  editor.Commands.add("save-template", {
    run(editor, sender) {
      sender && sender.set("active", false);

      const html = editor.getHtml();
      const css = editor.getCss();
      const template = { html, css };

      localStorage.setItem("gjs-saved-template", JSON.stringify(template));
      alert("Your changes are successfully saved! 😀");
    },
  });

  // Optional: Load saved template on init if exists ✅
  const saved = localStorage.getItem("gjs-saved-template");
  if (saved) {
    const template = JSON.parse(saved);
    editor.setComponents(template.html);
    editor.setStyle(template.css);
  }
});
