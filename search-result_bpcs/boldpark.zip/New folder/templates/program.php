<?php

/*

Template Name: Programs

*/



get_header(); // Load the header template



?>



<!-- Common banner secion inner pages  -->

<?php if (have_rows('program_page_sections')) : ?>

    <?php while (have_rows('program_page_sections')) : the_row(); ?>

        <?php

        //Banner Section.

        if (get_row_layout() == 'banner_section') : ?>

            <section class="our_difference_newbanner cmn_new_banner bg_lightpnk">
                <div class="container-fluid px-0">
                    <div class="banner_main">
                        <?php 
                            $parent_pageId = wp_get_post_parent_id(get_the_ID());
                            $parent_page = get_the_title($parent_pageId);
                            $parent_page_url = get_the_permalink($parent_pageId);
                            $page_title = $wp_query->post->post_title; 
                        ?>
                        <div class="container">
                            <div class="breadcrumbs">
                                <ul>
                                    <?php if($parent_pageId != 0){ ?>
                                    <li>
                                        <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                                    </li>
                                    <?php } ?>
                                    <li>
                                        <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <?php 
                            $banner_heading = get_sub_field('banner_heading');
                            $banner_desc = get_sub_field('banner_description');
                            $banner_img = get_sub_field('banner_image');
                        ?>
                        <div class="banner_content_wrap">
                            <div class="row">
                                <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                                    <div class="left_main">

                                        <div class="left_img">
                                        <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                        <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                                    <div class="banner_content_inner">
                                        <div class="right_cont">
                                            <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading;?></h2>
                                            <p> <?php echo $banner_desc; ?></p>
                                        </div>
                                        <div class="banner_links">
                                           <?php get_template_part( 'template-parts/sections/banner_links' ); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        <!-- Section 02 start-->

        <?php elseif (get_row_layout() == 'programs') : ?>

            <?php

            // check if the nested repeater field has rows of data

            if (have_rows('program_blocks')) :

            ?>

                <div class="program_list_loop_wrapper">

                    <?php

                    $count  = 0;

                    while (have_rows('program_blocks')) : the_row();

                    ?>

                        <section class="join_us programList <?php $count++;
                                                            if ($count == 1) {
                                                                echo 'pt_extra';
                                                            } ?>">

                            <div class="container">

                                <div class="row">

                                    <div class="col-md-6 col-lg-7 my-2 my-md-0">

                                        <?php $image = get_sub_field('image');

                                        if (!empty($image)) : ?>



                                            <div class="inner pr-25 image_wrapper">

                                                <img src="<?php echo esc_url($image['url']); ?>" alt="">

                                            </div>

                                        <?php endif; ?>

                                    </div>

                                    <div class="col-md-6 col-lg-5 my-2 my-md-0">

                                        <div class="inner pl-25">

                                            <?php $program_heading = get_sub_field('heading'); ?>

                                            <?php $program_description = get_sub_field('description'); ?>

                                            <?php if($program_heading){ ?>

                                                <h4 class="hdng">

                                                    <?php echo $program_heading; ?>

                                                </h4>
                                            <?php } ?>

                                            <p>

                                                <?php echo $program_description; ?>

                                            </p>

                                            <?php

                                            $link = get_sub_field('button');

                                            if ($link) :

                                                $link_url = $link['url'];
												$link_title = $link['title'];
                                            ?>

                                                <a class="cmn_btn" href="<?php echo esc_url($link_url); ?>"><?php echo $link_title; ?></a>

                                            <?php endif; ?>



                                        </div>

                                    </div>



                                </div>

                            </div>

                        </section>

                    <?php endwhile; ?>

                </div>

            <?php

            endif;

            ?>

            <!-- Section 02 end-->

        <?php elseif (get_row_layout() == 'specialist_program') :

            $specialist_heading = get_sub_field('heading');

            $specialist_button = get_sub_field('button');

            $specialist_button_url = $specialist_button['url'];

            $specialist_button_title = $specialist_button['title'];

        ?>

            <!-- Section 03 start-->

            <section class="specialist_program_list bg_grey">

                <div class="container">

                    <div class="row d-flex justify-content-center">

                        <div class="col-12 col-md-12 col-lg-3 col-xl-4 mb-4 mb-lg-0">

                            <div class="inner">

                                <h3 class="hdng">

                                    <?php echo $specialist_heading; ?>

                                </h3>

                                <a href="<?php echo esc_url($specialist_button_url); ?>" class="cmn_btn">

                                    <?php echo esc_html($specialist_button_title); ?>

                                </a>

                            </div>

                        </div>

                        <div class="col-12 col-md-12 col-lg-9 col-xl-8">

                            <div class="inner">

                                <ul>

                                    <?php if (have_rows('links')) :

                                        while (have_rows('links')) : the_row();

                                            $specialist_program = get_sub_field('links');

                                            $specialist_program_url = $specialist_program['url'];

                                            $specialist_program_title = $specialist_program['title']; ?>



                                            <li>

                                                <a href="<?php echo esc_url($specialist_program_url); ?>" class="arrow_btn">

                                                    <span>

                                                        <?php echo esc_html($specialist_program_title); ?>

                                                        <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">

                                                            <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>

                                                        </svg>

                                                    </span>

                                                </a>

                                            </li>

                                    <?php

                                        endwhile;

                                    endif; ?>

                                </ul>

                            </div>

                        </div>

                    </div>

                </div>

            </section>

            <!-- Section 03 end-->

        <?php elseif (get_row_layout() == 'testimonial_grid') : ?>

            <!-- 04 Section testimonials start-->

            <section class="testimonials_grid bg_drkgrey">

                <?php get_template_part('template-parts/sections/grid_testimonial'); ?>

            </section>

            <!-- 04 Section testimonials end-->

        <?php elseif (get_row_layout() == 'join_us_section') : ?>

            <!-- 05 Section join us start-->

            <section class="join_us mt-90">

                <?php get_template_part('template-parts/sections/join_us'); ?>

            </section>

            <!-- 05 Section join us end-->

        <?php elseif (get_row_layout() == 'apply_now_section') : ?>

            <!-- Questions start-->

            <section class="questions_sec">

                <?php get_template_part('template-parts/sections/apply_now'); ?>

            </section>

            <!-- Questions end-->

        <?php endif; ?>

    <?php endwhile; ?>

<?php endif; ?>

<?php get_footer(); // Load the footer template 
?>