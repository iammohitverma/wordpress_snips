<section class="book_trip pb_100">
    <div class="container">
        <div class="book_trip_wrap">
            <?php
                $trip_heading = get_field('trip_heading', 'option');
                if($trip_heading){
            ?>
            <div class="heading_wrap">
                <h2 class="main_heading fs_48"><?php echo $trip_heading;?></h2>
            </div>
            <?php } ?>

            <?php
                $trip_content = get_field('trip_content', 'option');
                if($trip_content){
            ?>
            <div class="content_editor_default mb_20">
                <?php echo $trip_content;?>
            </div>
            <?php } ?>
            
            <?php 
            $link = get_field('book_trip_button', 'option');
            if( $link ): 
                $link_url = $link['url'];
                $link_title = $link['title'];
                $link_target = $link['target'] ? $link['target'] : '_self';
                ?>
                <a class="hl_btn text-uppercase" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
            <?php endif; ?>
        </div>
    </div>
</section>
