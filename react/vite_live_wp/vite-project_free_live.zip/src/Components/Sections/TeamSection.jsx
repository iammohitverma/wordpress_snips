import React from "react";

function TeamSection({ data }) {
  const sectionData = data || {};
  console.log(sectionData);

  const { section_heading = "Default Heading", team = [] } = sectionData;

  return (
    <>
      <section className="team">
        <div className="container">
          <div className="heading_wrap">
            <h1 className="text-body-emphasis mb-4">{section_heading}</h1>
          </div>
          <div className="row">
            {team.map((item, key) => (
              <div className="col-lg-4" key={key}>
                <div className="team_card">
                  <img
                    src={item.team_member_image.url}
                    className="card-img-top"
                    alt={item.team_member_heading}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{item.team_member_heading}</h5>
                    <p className="card-text">{item.team_member_details}</p>
                    <a href="#" className="btn btn-primary">
                      Go somewhere
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
export default TeamSection;
