
<section class="contact_section pb_100">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="form_wrap">
                    <?php
                        $shortcode = get_sub_field('form_shortcode');
                        echo do_shortcode( $shortcode );
                    ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="address_wrap">
                    <div class="content_editor_default pt_reset text_white">
                        <?php echo get_sub_field('address');?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


