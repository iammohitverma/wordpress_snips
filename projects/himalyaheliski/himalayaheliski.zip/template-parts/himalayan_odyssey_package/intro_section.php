<section class="top_intro_section pt_100 pb_100">
    <div class="container">
        <div class="heading_wrap">
            <h1 class="main_heading fs_48 center"><?php echo get_sub_field('heading');?></h1>
        </div>
        <div class="content_editor_default p_fs_28 mw_860 mx-auto">
            <?php echo get_sub_field('content');?>
        </div>
    </div>
</section>
