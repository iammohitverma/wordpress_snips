$(window).on("load", function () {

    // set initial variables
    let header = $("header");
    let topbar = $("header .topbar");

    $("body").css("--headerHeight", header.outerHeight() + "px");
    $("body").css("--topbarHeight", -topbar.outerHeight() + "px");

    // sticky header
    $(window).on("scroll", function () {
        if ($(this).scrollTop() > topbar.outerHeight()) {
            header.addClass("sticky");
        } else {
            header.removeClass("sticky");
        }
    });

    // toggle menu
    $(".toggle-menu").click(function (e) {
        $(this).toggleClass("active");
        header.toggleClass("active");
        header.find("nav").slideToggle();
    });


    // banner text effect
    Splitting();

    // const target = document.querySelector('[data-splitting]');
    // Splitting({ target: target, by: 'words' });

    // courses cards hover effect
    if (window.innerWidth > 768) { // or any breakpoint you prefer
        $('.course_wrap').tilt({
            maxTilt: 15,
            glare: true,
            maxGlare: .3
        })
    }

    // Aos animations
    AOS.init({
        disable: 'phone', // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
        startEvent: 'DOMContentLoaded',
        initClassName: 'aos-init',
        animatedClassName: 'aos-animate',
        useClassNames: false,
        disableMutationObserver: false,
        debounceDelay: 50,
        throttleDelay: 99,
        offset: 250,
        delay: 30,
        duration: 2000,
        easing: 'ease-out-back',
        once: false,
        mirror: false,
        anchorPlacement: 'top-bottom',
    });
});
