import React from "react";
import { Helmet } from "react-helmet";

const HelmetConfig = ({ title, description, metaTags = [] }) => {
  return (
    <Helmet>
      <title>{title ? title : "Default Title"}</title>
      <meta
        name="description"
        content={
          description ? description : "Default description for the website"
        }
      />
      {metaTags &&
        metaTags.map((metaTag, index) => (
          <meta key={index} name={metaTag.name} content={metaTag.content} />
        ))}
      {/* Add more common meta tags if necessary */}
    </Helmet>
  );
};

export default HelmetConfig;
