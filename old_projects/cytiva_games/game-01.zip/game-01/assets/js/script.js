$(document).ready(function () {


    var timer;
    var iqScore;

    //    $("[data-toggle='popover']").on({
    $("#gameOneHoveringPoints .point").on({
        'mouseover': function (event) {
            var currentElem = $(this).html(event.target);
            timer = setTimeout(function () {
                $(currentElem).addClass('active');
                $('span.point').popover('hide');
                $(currentElem).popover('show').off('click').siblings();




                if ($(currentElem).hasClass("point1")) {
                    $('#featureOne').modal('show');
                }

                if ($(currentElem).hasClass("point2")) {
                    $('#featureTwo').modal('show');
                }

                if ($(currentElem).hasClass("point3")) {
                    $('#featureThree').modal('show');
                }

                if ($(currentElem).hasClass("point4")) {
                    $('#featureFour').modal('show');
                }

                if ($(currentElem).hasClass("point5")) {
                    $('#featureFive').modal('show');
                }

                if ($('span.point.active').length >= 5) {
                    
                    /*** score game 01 ****/
                    iqScore = 50
                    $('.game-score').html("Your Score is " + "<b>" + iqScore + "</b>");
                }
                
                

                if ($('span.point.active').length == 1) {
                    $("#runProgress").css("width" , "20%");
                    $("#runProgress").css("border-width" , "2px");
                }
                if ($('span.point.active').length == 2) {
                    $("#runProgress").css("width" , "40%")
                }
                if ($('span.point.active').length == 3) {
                    $("#runProgress").css("width" , "60%")
                }
                if ($('span.point.active').length == 4) {
                    $("#runProgress").css("width" , "80%")
                }
                if ($('span.point.active').length == 5) {
                    $("#runProgress").css("width" , "100%")
                }

                $(".gm-popup-close").click(function () {
                    if ($('span.point.active').length >= 5) {
                        $('#staticBackdropScore').modal({
                            backdrop: 'static',
                            keyboard: false
                        })
                    }
                })

            }, 500);
        },
        'mouseout': function () {
            clearTimeout(timer);
        }
    });

    $("#playnextGame").click(function () {
        window.location.href = '#';
        // Check browser support
        if (typeof (Storage) !== "undefined") {
            // Store
            sessionStorage.setItem("gameId", "game-2");
            // Retrieve
            // document.getElementById("result").innerHTML = sessionStorage.getItem("lastname");
            // } else {
            // document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            // }
            console.log(sessionStorage.getItem("gameId"));
        }
    });
    
    
    
});

//window.onload = (event) => {
//  $('#staticBackdrop').modal({
//        backdrop: 'static',
//        keyboard: false
//    })
//};


$(window).on("load" , function() {
  $('#staticBackdrop').modal({
        backdrop: 'static',
        keyboard: false
    })
});
