<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>
<div class="blog_single" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="print_blog">
<?php 
if( have_rows('single_news_sections') ):

    while ( have_rows('single_news_sections') ) : the_row();

        if( get_row_layout() == 'banner_section' ):
            $banner_image = get_sub_field('banner_image'); 
            $blog_category = get_the_term_list(get_the_ID(), 'category', ',', ',');?>
            <section class="our_difference_newbanner cmn_new_banner bg_grey blog_banner">
                <div class="container-fluid px-0">
                    <div class="banner_main">
                        <div class="container">
                            <div class="breadcrumbs">
                                <ul>   
                                     <li>
                                        <a href="#">Community</a>
                                    </li>
                                    <li>
                                        <a href="#">News & Recsources</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div> 
                <div class="banner_content_wrap">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                            <div class="left_main">
                                <div class="left_img">
                                    <img src="<?php echo esc_url($banner_image['url']); ?>">
                                </div>
                            </div>
                        </div>
                    <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                    <div class="banner_content_inner">
                    <div class="right_cont">
                        <div class="meta_info">
                            <ul>
                                <li>
                                   <?php echo get_the_date( 'F j, Y' ); ?>
                                </li>
                                <!-- <li>
                                    <a href="#">8 min Read</a>
                                </li> -->
                                <li>
                                    <?php $blogscategories = explode(',', $blog_category);
												foreach ($blogscategories as $blogcategory) {
										?>
													<?php echo $blogcategory; ?>
										<?php } ?>	
                                </li>
                            </ul>
                        </div>
                        <?php echo '<h2 class="banner_mainheading sec_title_90"> ' . get_the_title() . ' </h2> '; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
       <?php 
        elseif( get_row_layout() == 'section_first' ): 
            $content = get_sub_field('post_content');
            $image = get_sub_field('image');
            $description = get_sub_field('post_description');?>
            <section class="blog_post_content">
                <div class="blog_single_container">
                <div class="post_content">
                    <h3><?php echo $content ?></h3>
                </div>
                <div class="post_image">
                    <img src="<?php echo esc_url($image['url']); ?>" alt="post_image">
                </div>
                <div class="post_description">
                    <p><?php echo $description ?></p>
                </div>
                </div>
            </section>

            <?php elseif( get_row_layout() == 'section_second' ): 
            $blockquote_content = get_sub_field('blockquote');
            $author_name = get_sub_field('author_name');?>
            <section class="blockquote_content">
                <div class="blog_single_container">
                <div class="post_block_quote">
                <blockquote>
                <?php echo $blockquote_content ?>
                </blockquote>
                <p><?php echo $author_name ?></p>
                </div>
                </div>
            </section>
            
            <?php elseif( get_row_layout() == 'section_third' ): 
            $heading = get_sub_field('heading');
            $content = get_sub_field('content');
            $image = get_sub_field('image');?>
            <section class="section_heading">
                <div class="blog_single_container">
                <div class="post_section">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-12">
                        <div class="post_section_heading">
                            <h3><?php echo $heading ?></h3>
                        </div>
                        <div class="post_section_content">
                            <p><?php echo $content ?></p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-12">
                        <div class="post_section_image">
                            <img src="<?php echo esc_url($image['url']); ?>" alt="post_section_image">
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </section>
        </div>

            <?php elseif( get_row_layout() == 'section_fourth' ):
             $content = get_sub_field('content'); 
             $share = get_sub_field('share_to');  ?>
             <section class="section_heading_desc">
                <div class="blog_single_container">
                    <div class="post_section_content_desc">
                        <p><?php echo $content ?></p>
                    </div>
                    <div class="post_social_icons">
                <div class="row">
                    <div class="col-lg-7 col-md-6 col-sm-12 col-12">
                        <div class="facebook_details">
                            <div class="text">
                                <p>share this on</p>
                            </div>
                            <div class="icon">
                                <a href="http://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank">
                                <img src="/wp-content/uploads/2024/03/facebook_icon.png" alt="facebook_icon">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12 col-12">
                        <div class="email_sec">
                            <div class="email_details">
                                <div class="icon">
                                    <img src="/wp-content/uploads/2024/03/email_icon.png.png" alt="email_icon">
                                </div>
                                <div class="text">
                                    <p><a href="mailto:?subject=Check%20out%20this%20post&body=Check%20out%20this%20post:%20<?php echo rawurlencode(get_the_title() . ' ' . get_permalink()) ?>">Email this article</a></p>
                                </div>
                            </div>
                            <div class="print_details">
                                <div class="icon">
                                    <img src="/wp-content/uploads/2024/03/printer_icon.png" alt="printer_icon">
                                </div>
                                <div class="text print_btn">
                                    <p>Print this article</p>
                                </div>
                            </div>
                    </div>
                    
                </div>
                </div>
            </div>
                </div>
            </section>

            <?php elseif( get_row_layout() == 'section_fifth' ):
            $heading = get_sub_field('heading');?>
             <section class="events_resources pt_extra inner_event_resources related_articles">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="hdng"><?php echo $heading ?></h2>
                        </div>
                    </div>
                    <?php
                    // Get the current post ID
                    $post_id = get_the_ID();

                    // Get the categories of the current post
                    $categories = get_the_category($post_id);

                    if ($categories) {
                        $category_ids = array();
                        foreach ($categories as $category) {
                            $category_ids[] = $category->term_id;
                        }

                        // Query for related posts
                        $args = array(
                            'post__not_in' => array($post_id),
                            'posts_per_page' => 3, // Adjust the number of related posts to display
                            'orderby' => 'date', // Get the latest related articles
                            'order' => 'DESC', // Get the latest related articles in descending order
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'category',
                                    'field' => 'id',
                                    'terms' => $category_ids,
                                    'operator' => 'IN',
                                ),
                            ),
                        );

                    $related_posts_query = new WP_Query($args);

                    // Display related posts
                    if ($related_posts_query->have_posts()) { ?>
                    <div class="row">
                        <?php while ($related_posts_query->have_posts()) {
                            $related_posts_query->the_post(); 
                            $blog_category = get_the_term_list(get_the_ID(), 'category', ',', ',');
                        ?>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-4 mt-4">
                            <div class="card_main">
                                <div class="img_main">
                                   <?php if ( has_post_thumbnail() ) : ?>
									<figure><?php the_post_thumbnail(); ?></figure>
									<?php else : ?>
									<img src="/wp-content/uploads/2023/11/download.png" alt="post" />
								<?php endif; ?>
                                </div>
                                <div class="content_main">
                                    <div class="top_cont">
                                        <p><?php echo get_the_date( 'F j, Y' ); ?></p>  
                                    
                                        	<?php echo '<h3 class="card_hdng"> <a href="' . get_permalink() . '">' . get_the_title() . '</a> </h3> '; ?>
                                    </div>
                                    <div class="content_mid">
                                        <?php  echo '<p> ' . get_the_excerpt() . ' </p> '; ?>
                                    </div>
                                    <div class="read_more_btn">
                                        <a href="<?php echo get_permalink(); ?>" class="cmn_btn">Read more</a>
                                    </div> 
                                </div>
                            </div>
                        </div>
                         <?php } wp_reset_postdata(); ?>
                    </div>
                    <?php } } ?>
                </div>
            </section>

            <?php elseif( get_row_layout() == 'apply_now_section' ):?>
            <section class="questions_sec pt_80">
                <?php get_template_part('template-parts/sections/apply_now'); ?>
            </section>
            
       <?php endif;

    // End loop.
    endwhile;

// No value.
else :
    // Do something...
endif;
?>

</div>



