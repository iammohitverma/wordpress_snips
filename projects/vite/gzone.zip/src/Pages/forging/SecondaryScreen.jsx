import React from 'react'
import Header from "./Components/Header";
import Profile from "./Components/SecondaryScreen/Profile";
import ForgeTabs from "./Components/SecondaryScreen/ForgeTabs";
import './ForgingStyle.css';

const backgroundImage = {
    background: `url("/Forge_Secondary_Screen_Background.jpg") no-repeat center / cover`,
};
const boxFrame = {
    background: `url("/Forge_Secondary_Screen_Left_Div_Frame.png") no-repeat center / 100% 100%`,
};

function SecondaryScreen() {
    return (
        <>
            <Header />
            <section className="gaming_screen_mv h_auto" style={backgroundImage}>
                <div className='container_mv'>
                    <div className="forge_main">
                        <div className="secondary_screen_wrap">
                            <h1 className='title'>Select an item for your blacksmith to forge</h1>
                            <img src="/Forge_Secondary_Screen_Blacksmith_Character.png" alt="Avtar" class="avtar" />
                            <div className="col_two_row">
                                <div className="box left" style={boxFrame}>
                                    <Profile />
                                </div>
                                <div className="box right">
                                    <div className="title_head">
                                        <img src="/the_forge.png" alt="The Forge" />
                                    </div>
                                    <ForgeTabs />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default SecondaryScreen;