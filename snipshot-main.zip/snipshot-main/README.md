# snipshot
Shopify and WordPress Code Snippets
