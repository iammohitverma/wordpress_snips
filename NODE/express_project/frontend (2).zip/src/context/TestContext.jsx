import { createContext, useState, useContext } from 'react';

const TestContext = createContext();

export function useTest() {
    return useContext(TestContext);
}

export function TestProvider({ children }) {
    const [testData, setTestData] = useState({});

    return (
        <TestContext.Provider value={{ testData, setTestData }}>
            {children}
        </TestContext.Provider>
    );
}
