import React from 'react'
import Comm1 from '../components/Home/Comm1'

const Home = () => {
  return (
    <div>
      <Comm1 />
    </div>
  )
}

export default Home
