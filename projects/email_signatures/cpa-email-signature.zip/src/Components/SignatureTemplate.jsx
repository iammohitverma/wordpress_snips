import { useState } from "react";

import { MasterSignature } from "./MasterSignature";

// Signature css
import "../assets/css/signature.css";

export const SignatureTemplate = () => {
  // Function to copy the table content to clipboard
  const copyFunction = () => {
    // Get the HTML content of the table
    const tableContent = document.querySelector(".table_wrap table").outerHTML;

    // Create a temporary div element to hold the HTML content
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = tableContent;

    // Append the div to the body (it needs to be in the DOM to be copied)
    document.body.appendChild(tempDiv);

    // Select the content
    const range = document.createRange();
    range.selectNode(tempDiv);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    // Copy the selected content
    try {
      document.execCommand("copy");
      alert("Email signature copied to clipboard!");
    } catch (err) {
      console.error("Failed to copy: ", err);
    }

    // Clean up by removing the temporary div
    document.body.removeChild(tempDiv);
  };

  const ourExpertsList = {
    matthew: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_matthew.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/matthew_new_140.png",
      expertName: "Matthew Hughes",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Managing Director",
      expertPositionLgSecondRow: "Buyer's Agent & QPIA",
      expertContact: "0437 777 377",
      expertEmail: "matthew@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    matthew_v2: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_matthew.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/matthew_140.png",
      expertName: "Matthew Hughes",
      expertPositionSm: "",
      expertPositionLgFirstRow: "CEO",
      expertPositionLgSecondRow: "",
      expertContact: "0437 777 377",
      expertEmail: "matthew@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/cpa_group_logo_300_2.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_3.png",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    stacey: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_stacey.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/stacey_billerwell_new_140.png",
      expertName: "Stacey Billerwell",
      expertPositionSm: "",
      expertPositionLgFirstRow: "National Acquisitions Adviser",
      expertPositionLgSecondRow: "",
      expertContact: "0419 713 330",
      expertEmail: "stacey@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    ben: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_ben.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/ben_new_140.png",
      expertName: "Ben Chamberlain",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Buyers Agent",
      expertPositionLgSecondRow: "",
      expertContact: "0488 776 628",
      expertEmail: "ben@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    becky: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_becky.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/becky_new_140.png",
      expertName: "Becky Hughes",
      expertPositionSm: "",
      expertPositionLgFirstRow: "PR & Marketing Manager",
      expertPositionLgSecondRow: "",
      expertContact: "0438 912 422",
      expertEmail: "becky@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    anthony: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_anthony.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/anthony_rizzacasa_new_140.png",
      expertName: "Anthony Rizzacasa",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Senior Development Manager",
      expertPositionLgSecondRow: "",
      expertContact: "0403 359 733",
      expertEmail: "anthony@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    breewest: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_bree_ea.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/bree_west_new_140.png",
      expertName: "Bree West",
      expertPositionSm: "",
      expertPositionLgFirstRow: "EXECUTIVE ASSISTANT TO MATTHEW HUGHES",
      expertPositionLgSecondRow: "",
      expertContact: "",
      expertEmail: "bree@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "",
      footerInfoRowTwo: "",
    },
    scott: {
      headerImage:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/header_scott.png",
      expertImg:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/scott_new_140.png",
      expertName: "Scott Ayles",
      expertPositionSm: "",
      expertPositionLgFirstRow: "Senior Finance Adviser",
      expertPositionLgSecondRow: "",
      expertContact: "",
      expertEmail: "scott@cpadvisory.com.au",
      companyLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/cla_logo_200.png",
      brandLogo:
        "https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg",
      footerInfoRowOne: "Capital Lending Advisory Pty Ltd, ABN 76 276 916 611",
      footerInfoRowTwo:
        "Credit Representative 505312 is authorised under Australian Credit Licence 389238",
    },
  };

  const [expert, setExpert] = useState("matthew");
  const [expertData, setExpertData] = useState(ourExpertsList.matthew);

  const onHandleSelectChange = (event) => {
    const selectedExpert = event.target.value;
    setExpert(selectedExpert);
    setExpertData(ourExpertsList[selectedExpert]); // Update expert data based on the new selection
  };

  return (
    <>
      <header>
        <div className="container_okmg">
          <a
            href="https://www.cpadvisory.com.au/"
            className="logo"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/cpa-logo.svg"
              alt=""
            />
          </a>
        </div>
      </header>
      <section className="email_signature_wrap">
        <div className="container_okmg">
          <div className="form_wrap">
            <div className="head">
              <h1 className="signature_header">Email Signature</h1>
              <h2 className="signature_sub_header">
                Preview and Select Signature
              </h2>
              <p className="signature_description">
                Choose from the generated email signature options to view and
                select the one that best fits your needs.
              </p>
            </div>

            <form>
              <div className="input_control">
                <label htmlFor="experts">
                  Our Experts: Signature Preview Options
                </label>
                <select
                  name="experts"
                  id="experts"
                  onChange={(e) => onHandleSelectChange(e)}
                  value={expert}
                >
                  <option value="matthew">Matthew Hughes</option>
                  <option value="matthew_v2">Matthew Hughes - Version 2</option>
                  <option value="stacey">Stacey Billerwell</option>
                  <option value="ben">Ben Chamberlain</option>
                  <option value="anthony">Anthony Rizzacasa</option>
                  <option value="becky">Becky Hughes</option>
                  <option value="breewest">Bree West</option>
                  <option value="scott">Scott Ayles</option>
                </select>
              </div>
            </form>
          </div>
          <div className="inner">
            <div className="table_wrap">
              <MasterSignature expertData={expertData} />
            </div>
          </div>

          <div className="copy_btn_wrap">
            <div className="container_okmg">
              <button className="copyBtn" onClick={copyFunction}>
                Copy email signature
              </button>
            </div>
          </div>
        </div>
      </section>
      <footer>
        <div className="container_okmg">
          <p>© 2024 Capital Property Advisory</p>
        </div>
      </footer>
    </>
  );
};
