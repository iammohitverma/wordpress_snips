<section class="inner_pages_common_banner">
    <div class="container-fluid px-0">
        <?php
            $image = get_sub_field('image');
            if( $image ){ ?>
            <div class="banner_image">
                <img
                    src="<?php echo $image['url']?>"
                    alt="<?php echo $image['alt']?>"
                    class="cover"
                />
            </div>
        <?php } ?>
    </div>
</section>