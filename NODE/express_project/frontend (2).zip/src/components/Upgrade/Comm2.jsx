import React from "react";

const Comm2 = () => {
    return (
        <div className="flex justify-center items-center py-10 bg-orange-100">
            <div className="flex space-x-6">
                {/* Free Plan Card */}
                <div className="flex flex-col p-10 bg-white rounded-lg shadow-md">
                    <h2 className="text-xl font-semibold">Free</h2>
                    <p className="text-3xl font-bold text-gray-700">$0<span className="text-sm">/forever</span></p>
                    <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            1 burn test
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Basic session tracking
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Limited notes
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Basic PDF reports
                        </li>
                    </ul>
                    <button className="mt-6 px-4 py-2 rounded-md text-gray-700 border border-gray-200">
                        Current Plan
                    </button>
                </div>

                {/* Premium Plan Card */}
                <div className="flex flex-col p-10 px-24 bg-white rounded-lg shadow-md border-2 border-orange-400">
                    <h2 className="text-xl font-semibold">Premium</h2>
                    <p className="text-3xl font-bold text-gray-700">$9.99<span className="text-sm">/month</span></p>
                    <ul className="mt-4 space-y-2">
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            10 burn tests
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Photo uploads
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            SMS reminders
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Detailed PDF reports
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Advanced analytics
                        </li>
                        <li className="flex items-center">
                            <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-4 8H6.414L11 6.414V8h-1.586L6 11.586V10zm8-1.828L12.414 10H14v-1.586L15.586 8 14 6.414V8h-1.586L15.586 10z" /></svg>
                            Priority support
                        </li>
                    </ul>
                    <button className="mt-6 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition duration-300">
                        Upgrade Now
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Comm2;
