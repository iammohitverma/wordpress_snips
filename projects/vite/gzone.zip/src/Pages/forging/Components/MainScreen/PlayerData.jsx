const PlayerData = [
    {
        id: 1,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 2,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 3,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 4,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 5,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 6,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 7,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
    {
        id: 8,
        cardImage: "/player_card_image.png",
        cryptoplan: "1847",
        playerclass: "Artisan",
        subclass: "Blacksmith",
    },
];

export default PlayerData;
