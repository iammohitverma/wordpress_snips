import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Login from './pages/Login'
import Signup from './pages/Signup'
import Otp from './pages/Otp'
import Home from './pages/Home'
import Upgrade from './pages/Upgrade'
import Logs from './pages/Logs'
import Test1 from './pages/Test1'
import Test2 from './pages/Test2'
import { TestProvider } from './context/TestContext';
import Test3 from './pages/Test3'
import Test4 from './pages/Test4'
import Test5 from './pages/Test5'
import Admin from './pages/Admin'

function App() {


  return (
    <>
      <TestProvider>
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Login />} />
            <Route path='/signup' element={<Signup />} />
            <Route path='/verify-otp' element={<Otp />} />
            <Route path='/home' element={<Home />} />
            <Route path='/upgrade' element={<Upgrade />} />
            <Route path='/logs' element={<Logs />} />
            <Route path='/home/test-1' element={<Test1 />} />
            <Route path='/home/test-2' element={<Test2 />} />
            <Route path='/home/test-3' element={<Test3 />} />
            <Route path='/home/test-4' element={<Test4 />} />
            <Route path='/home/test-5' element={<Test5 />} />
            <Route path='/admin/home' element={<Admin />} />

          </Routes>
        </BrowserRouter>
      </TestProvider>
    </>
  )
}

export default App
