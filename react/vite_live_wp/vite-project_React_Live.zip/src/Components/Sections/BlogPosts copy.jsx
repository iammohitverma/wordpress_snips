import axios from "axios";
import React, { useEffect, useState } from "react";
import Loader from "./Loader";
import { NavLink } from "react-router-dom";

const placeholder = "/placeholder_1080_675.jpg"; // Fallback placeholder image

function BlogPosts({ data }) {
  console.log(data);

  const baseUrl = import.meta.env.VITE_API_URL;
  const sectionData = data || {};
  const { posts } = sectionData;

  const [selectedPosts, setSelectedPosts] = useState([]);
  const [fetchedPosts, setFetchedPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (selectedPosts.length === 0) return;

    const fetchPosts = async () => {
      setLoading(true);
      try {
        const postData = await Promise.all(
          // ensure karde haan ke saare API calls complete ho jaan us to baad hi result mile
          selectedPosts.map(async (id) => {
            // Har post ID lai post data fetch kita ja reha hai
            const res = await axios.get(`${baseUrl}/wp-json/wp/v2/posts/${id}`);
            const post = res.data;

            // Featured image ID post object ch 'featured_media' field vich houndi hai
            if (post.featured_media) {
              try {
                // Oh ID use karke image da full data leya ja reha hai
                const imageRes = await axios.get(
                  `${baseUrl}/wp-json/wp/v2/media/${post.featured_media}`
                );
                // Image da URL post object ch add kar ditta ja reha hai
                post.featured_image_url = imageRes.data.source_url;
              } catch (imgErr) {
                // Je image fetch ch error aayi taan warning ditti ja rehi hai te null set kar ditta
                console.warn(`Post image not fetched:`, imgErr);
                post.featured_image_url = null;
              }
            } else {
              // Je image ID hi nahi hai taan null set kar ditta
              post.featured_image_url = null;
            }

            return post; // Har post object (image URL naal) return ho reha hai
          })
        );

        // Saare updated post objects state ch store kar ditta ja reha hai
        setFetchedPosts(postData);
      } catch (error) {
        console.error("Post not found:", error);
      } finally {
        setLoading(false); // Loading khatam ho gaya
      }
    };

    fetchPosts();
  }, [selectedPosts, baseUrl]);

  useEffect(() => {
    // acf ki relation field se selected posts ki ID ek variable me store krwana
    if (posts && posts.length) {
      const ids = posts.map((item) => item.ID);
      setSelectedPosts(ids);
    }
  }, [posts]);

  if (loading) {
    return <Loader />; // Loading state dikhao jab data aaraha ho
  }

  return (
    <section className="blog_posts">
      <div className="container">
        <div className="heading_wrap">
          <h3 className="text-body-emphasis">Posts</h3>
        </div>
        <div className="row">
          {fetchedPosts.length > 0 ? (
            fetchedPosts.map((item, key) => (
              <div className="col-lg-4" key={key}>
                <div className="blog_card">
                  <img
                    src={item.featured_image_url || placeholder} // Use the featured image URL or fallback to placeholder
                    className="card-img-top"
                    alt={item.title.rendered}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{item.title.rendered}</h5>
                    {/* Sanitize and render HTML content */}
                    <p
                      className="card-text"
                      dangerouslySetInnerHTML={{
                        __html: item.excerpt.rendered,
                      }}
                    />
                    <NavLink
                      to={`/blog/${item.slug}`}
                      className="btn btn-primary"
                    >
                      Read More
                    </NavLink>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div>No posts selected.</div>
          )}
        </div>
      </div>
    </section>
  );
}

export default BlogPosts;
