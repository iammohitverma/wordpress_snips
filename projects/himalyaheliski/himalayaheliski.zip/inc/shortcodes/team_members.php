<section class="team_section pb_100">
    <div class="container">
        <div class="row">

<?php
$args = array(
    'post_type' => 'team',
    'posts_per_page' => -1,
    'orderby' => 'date',
    'order' => 'ASC'
);
$the_query = new WP_Query( $args );

if ( $the_query->have_posts() ) {
	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$title = get_the_title();
		$img = get_the_post_thumbnail_url();
        $thumbnail = get_the_post_thumbnail_url( get_the_ID(), 'large' ); 
		$role = get_field( "role", get_the_ID() );
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="team_card">
                <div class="img_box">
                    <a href="<?php echo $img;?>" class="img_card" data-src="<?php echo $img;?>" >
                        <img src="<?php echo $thumbnail;?>" alt="<?php echo $title;?>" class="cover">
                    </a>
                </div>
                <div class="details">
                    <h4><?php echo $title;?></h4>
                    <p><?php echo $role;?></p>
                </div>
            </div>
        </div>
    <?php
	}
} else {
	esc_html_e( 'Sorry, no posts matched your criteria.' );
}
wp_reset_postdata();
?>


            
        </div>
    </div>
</section>