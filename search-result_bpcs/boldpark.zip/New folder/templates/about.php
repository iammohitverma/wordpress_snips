<?php
/*
Template Name: About Page
*/

get_header(); // Load the header template

?>
<!-- Section 01 Banner -->
<?php if (have_rows('about_page_section')) : ?>
<?php while (have_rows('about_page_section')) : the_row(); ?>
<?php
        //Banner Section.
        if (get_row_layout() == 'banner_section') :
        ?>
<section class="our_difference_newbanner cmn_new_banner bg_sb">
    <div class="container-fluid px-0">
        <div class="banner_main">
            <div class="container">
                <div class="breadcrumbs">
                    <ul>
                        <li>
                            <a href="javascript:void(0)" class="active">About</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                    <div class="left_main">

                        <div class="left_img">
                            <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/08/about.png">
                        </div>
                    </div>
                </div>

                <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                    <div class="right_cont">
                        <h2 class="banner_mainheading sec_title_90">About</h2>
                        <p>Fostering belonging, cultivating collaborative excellence, and empowering learners.</p>
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                    <div class="banner_links">
                        <ul>
                            <li class="2 "><a href="#" class="">Our campuses</a></li>
                            <li class="4 "><a href="#" class="">Our People</a></li>
                            <li class="5 "><a href="#" class="">Employment</a></li>
                        </ul>            
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Section 01 Banner -->

<!-- Section 02 ouer mission -->

<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'our_mission_vision') :
        ?>
<section>
    <div class="container">
        <div class="our_mission_main">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mv_left">
                        <div class="m_heading">
                            <?php $sectionheading = get_sub_field('section_heading'); ?>
                            <h3 class="bg_hdng sec_title_90">
                                <?php echo $sectionheading; ?>
                            </h3>
                        </div>
                        <?php $image = get_sub_field('image');
                                    if (!empty($image)) : ?>
                        <div class="m_img">
                            <img src="<?php echo esc_url($image['url']); ?>" alt="welcome_hero" />
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 d-flex align-items-center">
                    <?php $missiondesc = get_sub_field('heading'); ?>
                    <div class="mv_right">
                        <?php $missionheading = get_sub_field('heading'); ?>
                        <?php $missionheadesc = get_sub_field('description'); ?>
                        <h6 class="hdng">
                            <?php echo $missionheading; ?>
                        </h6>
                        <p>
                            <?php echo $missionheadesc; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Section 02 ouer mission -->
<?php elseif (get_row_layout() == 'video_section') : ?>
<!-- Section 03 video -->
<section class="single-video-sec hide_temp">
    <?php get_template_part('template-parts/sections/videos_section'); ?>
</section>
<!-- Section 03 video -->

<!-- Section 04 Principal -->
<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'principal_message') :
        ?>
<section class="bg_grey principal_section scroll_margin_top" id="principal_welcome">
    <div class="container">
        <div class="principal_main">
            <div class="row">
                <div class="col-lg-4">
                    <div class="principal_left">
                        <?php

                                    $section_heading = get_sub_field('section_heading');
                                    $image = get_sub_field('principal_photo');
                                    if (!empty($image)) : ?>
                        <h3 class="common_heading sec_title_60">
                            <?php echo $section_heading; ?>
                        </h3>

                        <img src="<?php echo esc_url($image['url']); ?>" alt="principal" />
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-8">
                    <?php $message_desc = get_sub_field('message'); ?>
                    <div class="principal_right">

                        <?php echo $message_desc; ?>
                    </div>
                </div>
                <!--<div class="col-lg-12">
                    <div class="principal_bottom">
                        <hr class="cmn_hr" />
                        <?php //$bottom_content = get_sub_field('message_for_bottom_section'); ?>
                        <p>
                            <?php //echo $bottom_content; ?>
                        </p>
                        <div class="princi_links">
                            <?php
                                        // check if the nested repeater field has rows of data
                                       // if (have_rows('link')) :
                                        ?>

                            <?php
                                           // while (have_rows('link')) : the_row();
                                                //$link = get_sub_field('links');
                                                //if ($link) :
                                                   // $link_url = $link['url'];
                                                   // $link_title = $link['title'];
                                                    //$link_target = $link['target'] ? $link['target'] : '_self';
                                            ?>
                            <a class="arrow_btn"
                                href="<?php //echo esc_url($link_url); ?>"><?php// echo esc_html($link_title); ?>
                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z"
                                        fill="#1E1E1E"></path>
                                </svg>
                            </a>
                            <?php// endif; ?>
                            <?php// endwhile; ?>

                            <?php
                                       // endif;
                                        ?>
                        </div>
                    </div>
                </div>-->
            </div>
        </div>
    </div>

    <img src="/wp-content/uploads/2023/05/princi_shape_01.png" class="s_left" alt="">
    <img src="/wp-content/uploads/2023/05/princi_shape_02.png" class="s_right" alt="">
    <img src="/wp-content/uploads/2023/05/princi_shape_03.png" class="s_middle" alt="">
</section>
<!-- Section 04 Principal -->

<!-- section 05 animated_links -->
<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'animation_section') :
        ?>
<section class="animated_links greyYellow">
    <div class="container">
        <?php
                    // check if the nested repeater field has rows of data
                    if (have_rows('animations')) :
                    ?>
        <div class="row">
            <?php
                            while (have_rows('animations')) : the_row();
                                $animation_heading = get_sub_field('heading');
                                $link = get_sub_field('button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];

                            ?>
            <div class="col-lg-12">
                <div class="tm-anim-wrap-v2 max_600 col-50">
                    <div class="box lightgrey">
                        <a class="btn fs60" href="<?php echo esc_url($link_url); ?>"
                            target="<?php echo esc_attr($link_target); ?>"><span><?php echo esc_html($link_title); ?></span><?php echo $animation_heading; ?></a>
                        <?php endif; ?>
                        <div class="shapes lightgrey">
                            <span class="shape hexagon"></span>
                            <span class="shape square"></span>
                            <span class="shape rectangle"></span>
                            <span class="shape rectangle2"></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>

        </div>
        <?php
                    endif;
                    ?>
    </div>
</section>
<!-- section 05 animated_links -->


<!-- Section 06 Accordian -->
<?php
        // Welcome section  layout.
        elseif (get_row_layout() == 'accordion_section') :
        ?>
        <section class="accordian_wrapper new_about bg_grey scroll_margin_top" id="about_accordion">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                    <?php
                        // check if the nested repeater field has rows of data
                        if( have_rows('accordions') ):
                    ?>
                        <?php while ( have_rows('accordions') ) : the_row(); 
                              $accordion_heading = get_sub_field('accordion_heading'); 
                              $accordion_content = get_sub_field('accordion_content');  
                        ?>
                        <div class="accordion-item">
                            <div class="accordion-item-header">
                                 <?php echo $accordion_heading ;?>                      
                            </div><!-- /.accordion-item-header -->
                            <div class="accordion-item-body">
                                <div class="accordion-item-body-content">
                                    <?php echo $accordion_content ;?>
                                   
                                </div>
                            </div><!-- /.accordion-item-body -->
                        </div>
                        <?php
                         endwhile; 
                            endif;
                        ?>
                    </div>
                </div>
            </div>
    </div>
</section>
<!-- Section 06 Accordian -->
<?php elseif (get_row_layout() == 'testimonial_section') : ?>
<!-- 07 Section testimonials start-->
<section class="testimonials_grid bg_white">
    <?php get_template_part('template-parts/sections/grid_testimonial'); ?>
</section>
<!-- 07 Section testimonials end-->

<?php elseif (get_row_layout() == 'join_us_section') : ?>
<!-- section 08 join us  -->
<section class="join_us">
    <?php get_template_part('template-parts/sections/join_us'); ?>
</section>
<!-- section 08 join us  -->

<?php elseif (get_row_layout() == 'apply_now_section') : ?>
<!-- section 09 Questions start-->
<section class="questions_sec">
    <?php get_template_part('template-parts/sections/apply_now'); ?>
</section>
<!-- section 09 Questions end-->


<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template 
?>