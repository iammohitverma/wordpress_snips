<section class="video_gallery pb_100">
    <div class="container">
        <div class="video_gallery_wrap">
            <div class="row justify-content-center">
            <?php 
            $rows = get_sub_field('videos');
            if( $rows ) {
                foreach( $rows as $row ) {
                    $video_type = $row['video_type'];
                    $youtube_embed_src = $row['youtube_embed_src'];
                    $video = $row['video'];
                    ?>

                    <?php if(($video_type == "youtube") && ($youtube_embed_src)){ ?>
                    <!-- iframe -->
                        <div class="col-lg-6 col-12">
                            <div class="video_wrap">
                                <iframe src="<?php echo $youtube_embed_src;?>" allow="fullscreen" class="cover"></iframe>
                                <img src="/wp-content/uploads/2025/04/loader_video.gif" alt="video_loader">
                            </div>
                        </div>
                    <?php } ?>

                    <?php if(($video_type == "media") && ($video)){ ?>
                    <!-- video -->
                        <div class="col-lg-6 col-12">
                            <div class="video_wrap">
                                <video width="320" height="240" controls class="cover">
                                    <source src="<?php echo $video['url'];?>" type="video/mp4">
                                </video>
                            </div>
                        </div>
                    <?php } ?>
                <?php }
            }
            ?>
            </div>
        </div>
    </div>
</section>