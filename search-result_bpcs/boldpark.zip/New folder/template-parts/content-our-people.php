<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <section class="popupWrapper-test">
        <div class="people_popup container-fluid">
            <div class="container">
                <div class="cross">
                    <span class="one"></span>
                    <span class="two"></span>
                </div>
                <p>PEDAGOGISTA</p>
                <h3>Nicole Hunter</h3>
                <div class="about_peple row">
                    <div class="col-md-3">
                        <div class="wrapper">
                            <img src="./assets/images/image1.png" alt="">
                            <p>QUALIFICATIONS: <br> Bachelor of ScienceGraduate Diplomas in Education (Science and Early Childhood)Masters of Education
                            </p>
                            <span>AT BPCS SINCE:
                            2004</span>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="people_blog">
                            <p>Nicole fervently believes that quality early life relationships, experiences and education are critical in providing a solid foundation for healthy life patterns and continuous learning. Nicole has both contributed to and experienced
                                the growth of Bold Park Community School as a parent, teacher and board member; first joining the community in 2001, when the school was a one-room primary school! She became part of the Early Childhood teaching team in
                                2004.
                                <br> From 2008 until 2015 Nicole was Early Childhood Co-Team Leader with the responsibility of expanding the outdoor learning program and National Quality Standards. In 2016 Nicole was appointed to the role of Pedagogista.
                                This role sees her working, in collaboration, with the teaching teams and leadership to align the principles, practices and philosophy of Bold Park with current educational research and translate these into the daily experience
                                of students and families. <br> To this role, Nicole draws not only her many years of experience in the Bold Park context, but also her teaching experience in a breadth of contexts including high school science and early
                                years learning. Nicole is grateful to have had the opportunity to travel internationally to visit educational contexts of Reggio Emilia and has recently completed her Master’s of Education in Teaching and Learning.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</article><!-- #post-<?php the_ID(); ?> -->


