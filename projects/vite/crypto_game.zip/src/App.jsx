import React from "react";
import { Routes, Route } from "react-router-dom";



import Main from "./Pages/forging/MainScreen";
import Secondary from "./Pages/forging/SecondaryScreen";


function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Main />} />
        <Route path="Secondary" element={<Secondary />} />
      </Routes>
    </>
  )
}
export default App;
