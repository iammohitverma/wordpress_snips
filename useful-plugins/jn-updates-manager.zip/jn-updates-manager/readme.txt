=== JN Updates Manager ===
Contributors: Harry  
Tags: plugin updates, disable updates, prevent updates, update control  
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4  
Stable tag: 1.0.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

A lightweight plugin to selectively disable update notifications for specific plugins through an intuitive admin interface.

== Description ==

**JN Updates Manager** allows site administrators to disable update checks for specific plugins.

This is especially useful for:
- Preventing accidental updates of custom or modified plugins
- Avoiding compatibility issues during critical periods
- Managing large installations where certain plugins must remain untouched

The plugin adds a dedicated settings page where you can:
- View a list of all installed plugins
- Select one or more plugins to disable their update notifications
- Enable/disable updates with one click
- Save and persist settings easily

✅ Built with performance in mind  
✅ No bloat — uses WordPress native APIs  
✅ Scripts and styles are minified and optimized for faster loading

== Features ==

- Disable update notifications for specific plugins  
- "Select All" or "Remove All" options for bulk control  
- Clean and responsive admin UI  
- Stored settings use the native WordPress Options API  
- Fully compatible with latest WordPress versions  

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.  
   _(Includes minified JS and CSS under `/assets/` for optimized performance)_  
2. Activate the plugin via the "Plugins" menu in WordPress.  
3. Navigate to: **Settings > JN Updates manager**  
4. Select the plugins you want to exclude from update checks and save.

== Frequently Asked Questions ==

= Will this affect core or theme updates? =  
No. This plugin only disables updates for the specific plugins you select. Core, theme, and other plugin updates will continue as usual.

= Is this safe to use in production? =  
Yes. It uses WordPress's built-in filtering system (`site_transient_update_plugins`) and follows best practices with proper sanitization and option storage.

= Can I re-enable updates later? =  
Absolutely. Just deselect the plugin(s) from the settings page and save. Update notifications will return automatically.

= Where are settings stored? =  
Settings are saved using the WordPress Options API in a single option key: `jn_disabled_plugins`.

== Screenshots ==

1. Admin interface for selecting plugins to disable updates
2. "Select All" and "Remove All" bulk buttons
3. Disabled plugin list displayed as tags

== Changelog ==

= 1.0.0 =
* Initial public release
* Admin UI with plugin selector and tag-style disabled list
* Select All / Remove All support
* Minified CSS and JS for better performance
* Main files (CSS/JS) are minified and located in the `/assets/` folder alongside their minified versions.

== Upgrade Notice ==

= 1.0.0 =
First official version. Adds the ability to selectively disable update notifications for plugins.
