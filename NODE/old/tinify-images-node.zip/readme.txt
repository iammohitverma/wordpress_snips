Run following command 
`npm install`
`node compress.js`
