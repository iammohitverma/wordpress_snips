import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import AboutSection from "../Sections/AboutSection";
import TeamSection from "../Sections/TeamSection";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Home() {
  const {
    data: acfData,
    isLoading,
    isError,
    error,
  } = useFetchAcfData(8, "home");

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <HelmetConfig
        title={"Home Page - My Website"}
        description={"This is the homepage of my website."}
      />

      {acfData?.map((block, index) => {
        switch (block.acf_fc_layout) {
          case "banner":
            return <Banner key={index} data={block} />;
          case "our_team":
            return <TeamSection key={index} data={block} />;
          case "about":
            return <AboutSection key={index} data={block} />;
          default:
            return null;
        }
      })}
    </>
  );
}
export default Home;
