import { ComA } from "./Context/ComA";

import "./App.css";

function App() {
  return (
    <>
      <div className="box">
        <h1>App</h1>
        <ComA />
      </div>
    </>
  );
}

export default App;
