<div class="row">
    <div class="col-12">
        <div class="people_list">
            <ul>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>PAUL WHITEHEAD</h4>
                        <p>SCHOOL PRINCIPAL</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>NICOLE HUNTER</h4>
                        <p>PEDAGOGISTAL</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>SUE WYATT</h4>
                        <p>BUSINESS MANAGER</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>TIM VIDLER</h4>
                        <p>COLLEGE TEAM LEADER</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>FELICITY KINSELLA</h4>
                        <p>PRIMARY TEAM LEADER</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>GABBI LOVELADY</h4>
                        <p>EARLY CHILDHOOD TEAM LEADER AND LEAD CLASSROOM TEACHER</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>RHYS GEORGE</h4>
                        <p>ARTS TEAM LEADER AND MEDIA SPECIALIST</p>
                    </div>
                </li>
                <li>
                    <div class="teacher_img">
                        <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" class="img-fluid" alt="">
                        <a href="JavaScript:void(0)">Read More</a>
                    </div>
                    <div class="teacher_desc">
                        <h4>MALORA ROSARIO</h4>
                        <p>MIDDLE SCHOOL TEAM LEADER</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<section class="popupWrapper">
    <div class="people_popup container-fluid">
        <div class="container">
            <div class="cross">
                <span class="one"></span>
                <span class="two"></span>
            </div>
            <p>PEDAGOGISTA</p>
            <h3>Nicole Hunter</h3>
            <div class="about_peple row">
                <div class="col-md-3">
                    <div class="wrapper">
                        <img src="./assets/images/image1.png" alt="">
                        <p>QUALIFICATIONS: <br> Bachelor of ScienceGraduate Diplomas in Education (Science and Early
                            Childhood)Masters of Education
                        </p>
                        <span>AT BPCS SINCE:
                            2004</span>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="people_blog">
                        <p>Nicole fervently believes that quality early life relationships, experiences and education
                            are critical in providing a solid foundation for healthy life patterns and continuous
                            learning. Nicole has both contributed to and experienced
                            the growth of Bold Park Community School as a parent, teacher and board member; first
                            joining the community in 2001, when the school was a one-room primary school! She became
                            part of the Early Childhood teaching team in
                            2004.
                            <br> From 2008 until 2015 Nicole was Early Childhood Co-Team Leader with the responsibility
                            of expanding the outdoor learning program and National Quality Standards. In 2016 Nicole was
                            appointed to the role of Pedagogista.
                            This role sees her working, in collaboration, with the teaching teams and leadership to
                            align the principles, practices and philosophy of Bold Park with current educational
                            research and translate these into the daily experience
                            of students and families. <br> To this role, Nicole draws not only her many years of
                            experience in the Bold Park context, but also her teaching experience in a breadth of
                            contexts including high school science and early
                            years learning. Nicole is grateful to have had the opportunity to travel internationally to
                            visit educational contexts of Reggio Emilia and has recently completed her Master’s of
                            Education in Teaching and Learning.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>