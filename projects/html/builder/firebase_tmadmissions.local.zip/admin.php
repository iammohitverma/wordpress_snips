<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: login");  
    exit;
}else {
    header("Location: admin_dashboard");  
    exit;
}