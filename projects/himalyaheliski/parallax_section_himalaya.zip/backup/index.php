<?php
/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
/* require __DIR__ . '/wp-blog-header.php'; */
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Himalaya Heliski</title>
  </head>

  <style>
    * {
      padding: 0;
      margin: 0;
      box-sizing: border-box;
    }
    img {
      width: 100%;
	  pointer-events: none; /* Disable image interaction */
      -webkit-user-drag: none; /* Prevent dragging in Safari */
    }
    body {
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }
  </style>

  <body>
	<img src="https://himalayaheliski.tmdemo.in/wp-content/uploads/2025/05/home.jpg" alt="img" style="vertical-align: middle;" />

  </body>
</html>

<script>
    // Disable keyboard shortcuts like F12, Ctrl+Shift+I, Ctrl+U etc.
    document.onkeydown = function(e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && e.keyCode === 73) || // Ctrl+Shift+I
        (e.ctrlKey && e.shiftKey && e.keyCode === 74) || // Ctrl+Shift+I
        (e.ctrlKey && e.keyCode === 85) || // Ctrl+U
        (e.ctrlKey && e.keyCode === 83) // Ctrl+S
      ) {
        return false;
      }
    };
    
    // Disable right click
    document.addEventListener('contextmenu', event => event.preventDefault());
	// Disable drag events
    document.addEventListener('dragstart', function(e) {
      e.preventDefault();
    });
</script>
