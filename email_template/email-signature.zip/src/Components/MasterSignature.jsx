export const MasterSignature = ({ expertData }) => {
  return (
    <>
      <table width="600" align="start" cellSpacing="0" cellPadding="0">
        <tbody>
          <tr>
            <td>
              <table width="100%" align="start" cellSpacing="0" cellPadding="0">
                <tbody>
                  <tr>
                    <td>
                      <table
                        align="start"
                        width="600"
                        style={{
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "200px",
                                // textAlign: "right",
                                padding: "20px 30px",
                                backgroundColor: "#30526d",
                                borderTopLeftRadius: "10px",
                                borderBottomLeftRadius: "10px",
                              }}
                            >
                              <img
                                src={expertData.expertImg}
                                alt=""
                                style={{
                                  width: "120px",
                                  height: "120px",
                                }}
                              />
                            </td>
                            <td
                              style={{
                                width: "400px",
                                verticalAlign: "middle",
                                padding: "20px 30px",
                                paddingLeft: "0px",
                                backgroundColor: "#30526d",
                                borderTopRightRadius: "10px",
                                borderBottomRightRadius: "10px",
                              }}
                            >
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "24px",
                                  fontWeight: "600",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "1px",
                                }}
                              >
                                {expertData.expertName}
                              </p>
                              <div>
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/bar_2.png"
                                  alt=""
                                  style={{
                                    width: "25px",
                                    verticalAlign: "middle",
                                  }}
                                />
                              </div>

                              {expertData.expertPositionSm && (
                                <>
                                  <p
                                    style={{
                                      fontFamily: "Roboto, sans-serif",
                                      fontSize: "10px",
                                      fontWeight: "400",
                                      color: "#fff",
                                      textTransform: "uppercase",
                                      letterSpacing: "2px",
                                      marginBottom: "5px",
                                    }}
                                  >
                                    {expertData.expertPositionSm}
                                  </p>
                                  <div
                                    style={{
                                      marginBottom: "5px",
                                    }}
                                  ></div>
                                </>
                              )}
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                  marginBottom: "3px",
                                }}
                              >
                                {expertData.expertPositionLgFirstRow}
                              </p>
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                }}
                              >
                                {expertData.expertPositionLgSecondRow}
                              </p>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "300px",
                                verticalAlign: "top",
                                padding: "20px 0 0 0px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td>
                                      <p>
                                        <a
                                          href={`tel: ${expertData.expertContact}`}
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "14px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/mobile_pink.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          {expertData.expertContact}
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="tel:08 9323 0000"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "14px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/telephone_pink.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          1300 CAPITAL
                                        </a>
                                      </p>

                                      <p>
                                        <a
                                          href={`mailto: ${expertData.expertEmail}`}
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "14px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                            wordBreak: "break-all",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/email_pink.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          {expertData.expertEmail}
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="https://cpadvisory.com.au/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "14px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/globe_pink.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          cpadvisory.com.au
                                        </a>
                                      </p>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td
                              style={{
                                width: "300px",
                                textAlign: "right",
                                paddingRight: "0px",
                                paddingTop: "20px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td
                                      style={{
                                        width: "300px",
                                        textAlign: "right",
                                      }}
                                    >
                                      <a
                                        href="https://www.cpadvisory.com.au/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          paddingTop: "0px",
                                        }}
                                      >
                                        <img
                                          src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/capital_logo_200.jpg"
                                          alt=""
                                          style={{
                                            width: "200px",
                                          }}
                                        />
                                      </a>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      style={{
                                        padding: "0px 0px",
                                        width: "300px",
                                        paddingTop: "15px",
                                        textAlign: "right",
                                      }}
                                    >
                                      <p>
                                        <a
                                          href="https://www.instagram.com/capitalpropertyadvisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginLeft: "0",
                                            marginRight: "0",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/instagram_r.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                        <a
                                          href="https://www.facebook.com/capitalpropertyadvisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginRight: "0",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/facebook_r_2.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                        <a
                                          href="https://au.linkedin.com/company/capital-property-advisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginRight: "0",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/linkedin_r_2.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                        <a
                                          href="https://open.spotify.com/show/02cyiNPOIIRRXCzCaDcP2g?si=37d97901349f493b&nd=1&dlsi=158951d90f264278"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginRight: "0",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/spotify_r.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                      </p>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                padding: "20px 0px",
                                width: "600px",
                                paddingTop: "20px",
                              }}
                            >
                              <img
                                src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/combine_brand_logo_2.jpg"
                                alt=""
                              />
                              {/* <a
                                href="http://rebaa.com.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/rebaa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/pipa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/qualified-property-investment-adviser-property-investment-adviser/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/qpia.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://members.reiwa.com.au/s/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/reiwa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a> */}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};
