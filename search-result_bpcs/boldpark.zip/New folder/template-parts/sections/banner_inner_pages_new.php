<?php
/**
 * Template part for displaying Banner
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>
<?php 
$parent_pageId = wp_get_post_parent_id(get_the_ID());
$parent_page = get_the_title($parent_pageId);
$parent_page_url = get_the_permalink($parent_pageId);
$page_title = $wp_query->post->post_title; 
?>
 <div class="banner_main">
    <div class="container">
        <div class="breadcrumbs">
            <ul>
                    <?php if($parent_pageId != 0){ ?>
                <li>
                    <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                </li>
                <?php } ?>
                <li>
                    <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="banner_content_wrap">
        <div class="row">
        <?php 
                    $banner_heading = get_sub_field('banner_heading');
                    $banner_desc = get_sub_field('banner_description');
                    $banner_img = get_sub_field('banner_image');
                ?>
            <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                <div class="left_main">

                    <div class="left_img">
                        <!-- <img src="<?php echo $banner_img['url'];?>"> -->
                        <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                <div class="banner_content_inner">
                    <div class="right_cont">
                        <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading;?></h2>
                        <p><?php echo $banner_desc; ?></p>
                    </div>
					 <div class="banner_links">
                    <?php get_template_part( 'template-parts/sections/banner_links' ); ?>  
						 </div>
                </div>
            </div>
        </div>
    </div>
</div>
