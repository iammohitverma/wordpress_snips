import React from 'react';

const Comm1 = () => {
    return (
        <div className="bg-[#fef5e0] py-10">
            <div className="text-center mb-6">
                <h2 className="text-2xl font-bold">Choose Your Plan</h2>
                <p className="mt-2 text-gray-600">Unlock powerful features to enhance your candle testing experience</p>
            </div>
            <div className="flex justify-center space-x-8">
                <div className="bg-white shadow-md hover:shadow-lg transition-shadow duration-300 rounded-lg p-6 text-center w-80">
                    <div className="flex justify-center mb-4">
                        <img src="/path/to/photo-icon.png" alt="Photo Documentation Icon" className="w-12 h-12" />
                    </div>
                    <h3 className="font-semibold text-lg">Photo Documentation</h3>
                    <p className="text-gray-500 mt-2">Upload photos for each burn session to track visual changes</p>
                </div>
                <div className="bg-white shadow-md hover:shadow-lg transition-shadow duration-300 rounded-lg p-6 text-center w-80">
                    <div className="flex justify-center mb-4">
                        <img src="/path/to/sms-icon.png" alt="SMS Reminders Icon" className="w-12 h-12" />
                    </div>
                    <h3 className="font-semibold text-lg">SMS Reminders</h3>
                    <p className="text-gray-500 mt-2">Get notified when it’s time to check your candles</p>
                </div>
                <div className="bg-white shadow-md hover:shadow-lg transition-shadow duration-300 rounded-lg p-6 text-center w-80">
                    <div className="flex justify-center mb-4">
                        <img src="/path/to/report-icon.png" alt="Detailed Reports Icon" className="w-12 h-12" />
                    </div>
                    <h3 className="font-semibold text-lg">Detailed Reports</h3>
                    <p className="text-gray-500 mt-2">Generate comprehensive PDF reports with charts and analytics</p>
                </div>
            </div>
        </div>
    );
};

export default Comm1;
