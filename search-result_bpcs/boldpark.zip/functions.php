<?php
if (!defined('_JN_VERSION')) {
    // Replace the version number of the theme on each release.
    define('_JN_VERSION', '1.0.0');
}

if (!function_exists('boldpark_theme_setup')) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function boldpark_theme_setup()
    {
        /*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');

        /**
         * Add support for core custom logo.
         *
         * @link https://codex.wordpress.org/Theme_Logo
         */
        // Logo support
        $defaults = array(
            'height'               => 100,
            'width'                => 400,
            'flex-height'          => true,
            'flex-width'           => true,
            'header-text'          => array('site-title', 'site-description'),
            'unlink-homepage-logo' => false,
        );

        add_theme_support('custom-logo', $defaults);

        /**
         * Enqueue scripts and styles.
         */

        function boldpark_scripts()
        {
            wp_enqueue_style('boldpark-style', get_stylesheet_uri(), array(), _JN_VERSION);
            wp_enqueue_style('boldpark-bootstrap-style', get_template_directory_uri() . '/assets/css/bootstrap/bootstrap.min.css', false, _JN_VERSION, 'all');
            wp_enqueue_style('boldpark-fontawesome-style', get_template_directory_uri() . '/assets/css/fontawesome/css/all.min.css', false, _JN_VERSION, 'all');

            // owl and slick both are linked use one of them at once 
            wp_enqueue_style('boldpark-owl-style', get_template_directory_uri() . '/assets/css/owl/owl.min.css', false, _JN_VERSION, 'all');
            wp_enqueue_style('boldpark-degular_opensans-font-style', get_template_directory_uri() . '/assets/fonts/degular-opensans/stylesheet.css', false, _JN_VERSION, 'all');
            wp_enqueue_style('boldpark-animate-style', get_template_directory_uri() . '/assets/css/animate/animate.css', false, _JN_VERSION, 'all');
            wp_enqueue_style('boldpark-theme-style', get_template_directory_uri() . '/assets/css/theme-style.css', false, _JN_VERSION, 'all');
 
            wp_enqueue_script('boldpark-jquery-script', get_template_directory_uri() . '/assets/js/jquery/jquery-3.6.0.min.js', array(), _JN_VERSION, true);
            wp_enqueue_script('boldpark-bootstrap-script', get_template_directory_uri() . '/assets/js/bootstrap/bootstrap.bundle.min.js', array(), _JN_VERSION, true);
            wp_enqueue_script('boldpark-wow-script', get_template_directory_uri() . '/assets/js/wow/wow.min.js', array(), _JN_VERSION, true);
            // wp_enqueue_script('boldpark-printout.js', get_template_directory_uri() . '/assets/js/printout/printout.js', array(), _JN_VERSION, true);

            // owl and slick both are linked use one of them at once  
            wp_enqueue_script('boldpark-owl-script', get_template_directory_uri() . '/assets/js/owl/owl.min.js', array(), _JN_VERSION, true);
            // wp_enqueue_script('boldpark-print-js', get_template_directory_uri() . '/assets/js/printout.min.js', array(), _JN_VERSION, true);
            wp_enqueue_script('boldpark-theme-script', get_template_directory_uri() . '/assets/js/function.js', array(), _JN_VERSION, true);
        }
        add_action('wp_enqueue_scripts', 'boldpark_scripts');

        /* ------ Admin Login Page Design ------ */
        require get_template_directory() . '/inc/theme/login_p_design.php';

        /* ------ Revert To Classic Editor & Classic Widgets ------ */
        require get_template_directory() . '/inc/theme/c_editor_c_widgets.php';

        /* ------ Register News and resources post type ------ */
        // require get_template_directory() . '/inc/theme/post_type_news_resources.php';
       // require get_template_directory() . '/inc/theme/post_type_events.php';

        /* ------ Register Custom Menus ------ */
        require get_template_directory() . '/inc/theme/menus.php';

        
        /* ------ Register Customizer ------ */
        require get_template_directory() . '/inc/theme/customizer.php';

        /* ------ Register Widgets ------ */
        require get_template_directory() . '/inc/theme/widgets.php';

        /* ------ Register Post Type ------ */
        require get_template_directory() . '/inc/theme/custom_post.php';



        // Remove <p> and <br/> from Contact Form 7  (Uncomment this filter if you use CF7)
        //add_filter('wpcf7_autop_or_not', '__return_false');

        // / Leadership tabbing On Our-People page Shortcode /
        function leadershiptabbing()
        {
            require get_template_directory() . '/inc/shortcodes/leadership-tabbing.php';
        }
        add_shortcode('leadership-tabs', 'leadershiptabbing');
    }
endif;
add_action('after_setup_theme', 'boldpark_theme_setup');

// load more posts functionality for news and resources posts listing page
function load_more_posts_news_resources()
{
    $args = array(
        'post_type' => 'newsresources',
        'posts_per_page' => 3,
        'offset'        => $_POST['paged'],
    );
    $ajaxposts = new WP_Query($args);

    $post_html = '';

    if ($ajaxposts->have_posts()) {
        while ($ajaxposts->have_posts()) {
            $ajaxposts->the_post();

            $url = get_the_permalink();
            $postThumbUrl = get_the_post_thumbnail_url();
            $date = get_the_date('d-m-Y');
            $the_title = get_the_title();
            $the_excerpt = get_the_excerpt();
            $email_option_news_resources = get_field('email_option_news_resources');
            $show_contact = '';
            if ($email_option_news_resources) {
                $show_contact = '
            <div class="contact">
                <p>contact</p> 
                <a href="mailto:' . $email_option_news_resources . '">
                    ' . $email_option_news_resources . '
                </a>
            </div>';
            } else {
                $show_contact = '';
            }

            $post_html .= '<div class="col-12 col-sm-6 col-lg-4">
            <div class="tm-event-box">
                <div class="img-box">
                    <img src="' . $postThumbUrl . '" alt="' . $the_title . '" />
                </div>
                <div class="text-box">
                    <div class="top">
                        <p>' . $date . '</p>
                        <h4>' . $the_title . '</h4>
                    </div>
                    <div class="middle">
                        <p>' . $the_excerpt . '</p>
                    </div>
                    <div class="bottom">
                        <a href="' . $url . '" class="btn">View</a>' .
                $show_contact
                . '</div>
                </div>
            </div>
        </div>';
            // var_dump($ajaxposts->the_post());
            // $response .= get_template_part('parts/card', 'newsresources');
        }
    } else {
        $post_html = '';
    }

    echo $post_html;

    exit();
}
add_action('wp_ajax_load_more_posts_news_resources', 'load_more_posts_news_resources');
add_action('wp_ajax_nopriv_load_more_posts_news_resources', 'load_more_posts_news_resources');


//Create Shorcode  
function image_slider_function()
{
    include 'inc/shortcodes/image-slider.php';
}

add_shortcode('image_slider', 'image_slider_function');


//Create Shorcode  
function teachers_shortcode_function()
{
    include 'inc/shortcodes/teacher_shortcode.php';
}

add_shortcode('teachers_section', 'teachers_shortcode_function');

// fetch_post_related_to_category
function fetch_post_related_to_event_category(){
    $html = '';
    $eventscat_id = $_POST['id'];

    if ($eventscat_id == 0) {
        // WP Query
        $args = array(
            'post_type' => 'events',
            'post_status' => 'publish',
            'posts_per_page' => 6,
        );
    } else {
        // WP Query
        $args = array(
            'post_type' => 'events',
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'event-category',
                    'field'    => 'id',
                    'terms'    => $eventscat_id
                )
            ),
            'posts_per_page' => 6,
        );
    }
    $arr_posts = new WP_Query($args);
    if ($arr_posts->have_posts()) :
        while ($arr_posts->have_posts()) :
            $arr_posts->the_post();
            $term_list = get_the_terms(get_the_ID(), 'event-category');
            $term_array = array();
            if (is_array($term_list) || is_object($term_list))
            {
                foreach($term_list as $terml){
                    $term_array[] = $terml->name;
                }
                $eventDate = get_field( 'event_date');
                $contact_email = get_field( 'contact_email');
                $contact_phone = get_field( 'contact_phone');
                $event_buttons = get_field( 'event_buttons');
            }
            $term_name_ap = implode(" ", $term_array);
            $html .= '           
                <div class="col-12 col-sm-12 col-md-6 col-lg-4 mt-4">
                <div class="card_main">
                    <div class="img_main">
                        <a href="/our-newly-renovated-early-learning-centre-is-now-open/">
                            <img src="'.get_the_post_thumbnail_url().'" alt="">
                        </a>
                    </div>
                    <div class="content_main">
                        <div class="top_cont">
                            <p>'.$eventDate.'</p>
                            <p><?php echo $blurb;?></p>
                            <h3 class="card_hdng"> <a>' . get_the_title() . '</a> </h3>
                        </div>
                        <div class="content_mid">
                            <p>
                                ' . get_the_excerpt() . '
                            </p>
                        </div>
                        <div class="cont_bottom">';
                           
                            if( $event_buttons ) { 
                                $html .= '<div class="read_more_btn">';
                                 
                                    foreach( $event_buttons as $event_button ) {
                                        $image = $event_button["event_button"];
                                    
                                       $html.='<a href="'.$image["url"].'" class="cmn_btn">'.$image["title"].'</a>';
                                     }
                                $html.= '</div>'; 
                            }
                            $html.= '<p>contact</p>
                            <p>
                                <a href="mailto:'.$contact_email.'">
                                    '.$contact_email.'
                                </a>    
                            </p>
                            <p>
                                <a href="tel:'.$contact_phone.'">
                                   '.$contact_phone.'
                                </a> 
                            </p>
                        </div>
                    </div>
                </div>
            </div>';
            

        endwhile;
    endif;
    wp_reset_postdata();
    // Return a response
    echo $html;
    // Don't forget to exit
    exit();
}

add_action('wp_ajax_fetch_post_related_to_event_category', 'fetch_post_related_to_event_category');
add_action('wp_ajax_nopriv_fetch_post_related_to_event_category', 'fetch_post_related_to_event_category');

// fetch_post_related_to_category
function fetch_post_related_to_newsandevent_category(){
    $html = '';
    $newscat_id = $_POST['id'];

    if ($newscat_id == 0) {
        // WP Query
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => 6,
        );
    } else {
        // WP Query
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'category',
                    'field'    => 'id',
                    'terms'    => $newscat_id
                )
            ),
            'posts_per_page' => 6,
        );
    }
    $arr_posts = new WP_Query($args);
    if ($arr_posts->have_posts()) :
        while ($arr_posts->have_posts()) :
            $arr_posts->the_post();
            $term_list = get_the_terms(get_the_ID(), 'category');
            $term_array = array();
            if (is_array($term_list) || is_object($term_list))
            {
                foreach($term_list as $terml){
                    $term_array[] = $terml->name;
                   
                }
            }
            $term_name_ap = implode(" ", $term_array);
			$html .= '  <div class="col-12 col-sm-6 col-lg-4 mt-4">
							<div class="card_main">
								<div class="img_main">
                                   <figure>
                                    <img src="'.get_the_post_thumbnail_url().'" alt="">
                                    </figure>
                                </div>
								<div class="content_main">
									 <div class="top_cont">
										<p> ' . get_the_date( "F j, Y") . ' </p> 
                                        <h3 class="card_hdng"> <a href="' . get_permalink() . '">' . get_the_title() . '</a> </h3>
									</div>
									<div class="content_mid">
										 <p> ' . get_the_excerpt() . ' </p> 
									</div>
                                    <div class="read_more_btn">
                                        <a href="' . get_permalink() . '" class="cmn_btn">Read more</a>
                                    </div> 
									
								</div>
							</div>
						</div>';

        endwhile;
    endif;
    wp_reset_postdata();
    // Return a response
    echo $html;
    // Don't forget to exit
    exit();
}
add_action('wp_ajax_fetch_post_related_to_newsandevent_category', 'fetch_post_related_to_newsandevent_category');
add_action('wp_ajax_nopriv_fetch_post_related_to_newsandevent_category', 'fetch_post_related_to_newsandevent_category');

// fetch_post_related_to_category

function fetch_post_related_to_category(){
    ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    // Do something with the data
    $html = '';
    $cat_id = $_POST['id'];

    if ($cat_id == 0) {
        // WP Query
        $args = array(
            'post_type' => 'our-people',
            'post_status' => 'publish',
            'posts_per_page' => 25,
        );
    } else {
        // WP Query
        $args = array(
            'post_type' => 'our-people',
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'people-category',
                    'field'    => 'id',
                    'terms'    => $cat_id
                )
            ),
            'posts_per_page' => 25,
        );
    }
    $arr_posts = new WP_Query($args);
    if ($arr_posts->have_posts()) :
        while ($arr_posts->have_posts()) :
            $arr_posts->the_post();
            $term_list = get_the_terms(get_the_ID(), 'people-category');
            $term_array = array();
            if (is_array($term_list) || is_object($term_list))
            {
                foreach($term_list as $terml){
                    $term_array[] = $terml->name;
                    // $term_array[] = get_term_link($terml->slug, 'case-category');
                }
            }
            $term_name_ap = implode(" ", $term_array);
            $position = get_field('position');
         if( get_field('qualification') ){
            $qualification = '<p><b>Qualification:</b>'.get_field('qualification').'</p>';
         }else{
             $qualification = '';
         }
         if( get_field('bpos') ){
            $bpos = '<p><b>AT BPCS SINCE:</b>'.get_field('bpos').'</p>';
         }else{
            $bpos = ''; 
         }
         $content = get_the_content();
            
            $formatted_content = nl2br($content);
            if (empty($content)) {
                $readmore = '';
            }
            else{
                $readmore = '<span class="read_more_popup">
                Read More
            </span>';
            }
            $html .= '<li>
                        <figure>
                            <img src="'.get_the_post_thumbnail_url().'" alt="">
                            
                        '.$readmore.'
                        </figure>
                        <div class="teacher_desc">
                            <h5 class="tchr_name">'.get_the_title().'</h5>
                            <h6 class="tchr_post">'.$position.'</h6>
                        </div>

                        <!-- This code is just for appending in popup -->
                        <div class="modalBody" style="display:none!important;opacity:0!important;">
                            <p>'.$position.'</p>
                            <h3>'.get_the_title().'</h3>
                            <div class="about_peple row">
                                <div class="col-md-3">
                                    <div class="wrapper">
                                        <img src="'.get_the_post_thumbnail_url().'" alt="">
                                       
                                            '.$qualification.'
                                        
                                        
                                            '.$bpos.'
                                        
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="people_blog">
                                        <p>
                                            '.$formatted_content.'
                                            
                                           
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- This code is just for appending in popup -->

                    </li>';
        endwhile;
    endif;
    wp_reset_postdata();
    // Return a response
    echo $html;
    // Don't forget to exit
    exit();
}
add_action('wp_ajax_fetch_post_related_to_category', 'fetch_post_related_to_category');
add_action('wp_ajax_nopriv_fetch_post_related_to_category', 'fetch_post_related_to_category');


function remove_wp_api_tags() {
    // Remove WordPress REST API link tag
    remove_action('wp_head', 'rest_output_link_wp_head', 10);
    // Remove WordPress REST API link in HTTP headers
    remove_action('template_redirect', 'rest_output_link_header', 11);
    // Remove RSD (Really Simple Discovery) link
    remove_action('wp_head', 'rsd_link');
    // Remove WLW (Windows Live Writer) manifest link
    remove_action('wp_head', 'wlwmanifest_link');
    // Remove WordPress shortlink
    remove_action('wp_head', 'wp_shortlink_wp_head', 10);
    // Remove oEmbed discovery links
    remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
    // Remove oEmbed-specific JavaScript from the front-end and back-end
    remove_action('wp_head', 'wp_oembed_add_host_js');
}
add_action('init', 'remove_wp_api_tags');

// Function to change "posts" to "news" in the admin side menu
function change_post_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'News/Blog';
    $submenu['edit.php'][5][0] = 'News/Blog';
    $submenu['edit.php'][10][0] = 'Add News/Blog';
    $submenu['edit.php'][16][0] = 'Tags';
    echo '';
}
add_action( 'admin_menu', 'change_post_menu_label' );
// Function to change post object labels to "news"
function change_post_object_label() {
    global $wp_post_types;
    $labels = &$wp_post_types['post']->labels;
    $labels->name = 'News/Blog';
    $labels->singular_name = 'News/Blog';
    $labels->add_new = 'Add News/Blog';
    $labels->add_new_item = 'Add News/Blog';
    $labels->edit_item = 'Edit News/Blog';
    $labels->new_item = 'News/Blog';
    $labels->view_item = 'View News/Blog';
    $labels->search_items = 'Search News/Blog';
    $labels->not_found = 'No News Articles found';
    $labels->not_found_in_trash = 'No News Articles found in Trash';
}
add_action( 'init', 'change_post_object_label' );



// Allow SVG
add_filter( 'wp_check_filetype_and_ext', function($data, $file, $filename, $mimes) {

  global $wp_version;
  if ( $wp_version !== '4.7.1' ) {
     return $data;
  }

  $filetype = wp_check_filetype( $filename, $mimes );

  return [
      'ext'             => $filetype['ext'],
      'type'            => $filetype['type'],
      'proper_filename' => $data['proper_filename']
  ];

}, 10, 4 );

function cc_mime_types( $mimes ){
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter( 'upload_mimes', 'cc_mime_types' );

function fix_svg() {
  echo '<style type="text/css">
        .attachment-266x266, .thumbnail img {
             width: 100% !important;
             height: auto !important;
        }
        </style>';
}
add_action( 'admin_head', 'fix_svg' );