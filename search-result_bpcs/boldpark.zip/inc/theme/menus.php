<?php



/* ------ Register Custom Menus ------ */



// if (!function_exists('boldpark_register_custom_menus')) :

//     function boldpark_register_custom_menus()

//     {

//         register_nav_menus( array(

//             'primary_menu' => __( 'Primary Menu', 'boldpark' ),

//             'mega_menu' => __( 'Mega Menu', 'boldpark' ),

//         ) );

//     }

//     add_action('after_setup_theme', 'boldpark_register_custom_menus');

// endif;



register_nav_menus(array(

    'primary_menu' => __('Primary Menu', 'boldpark'),

    'primary_top_menu' => __('Primary Top Menu', 'boldpark'),

    // 'mega_menu' => __( 'Mega Menu', 'boldpark' ),

    'mega_menu_one' => __('Mega Menu 1', 'boldpark'),

    'mega_menu_two' => __('Mega Menu 2', 'boldpark'),

    'mega_menu_three' => __('Mega Menu 3', 'boldpark'),

    'mega_menu_four' => __('Mega Menu 4', 'boldpark'),

    'mega_menu_five' => __('Mega Menu 5', 'boldpark'),

    'mega_menu_six' => __('Mega Menu 6', 'boldpark'),

    'mega_menu_seven' => __('Mega Menu 7', 'boldpark'),
    
    'program_menu' => __('Program Banner Menu', 'boldpark'),

    'footer_menu' => __('footer', 'boldpark'),

    'footer_menu_two' => __('footer two', 'boldpark'),

));



/* ------ Add List (li) Class In Custom Menu ------ */

// function add_li_class($classes, $item, $args, $depth)

// {

//     if ($args->theme_location == 'header') {

//         $classes[] = 'nav-item';

//     }

//     return $classes;

// }

// add_filter('nav_menu_css_class', 'add_li_class', 10, 4);





/* ------ Add Anchor (a) Class In Custom Menu ------ */

// function add_a_class($atts, $item, $args, $depth)

// {



//     if ($args->theme_location == 'header') {

//         $atts['class'] = "nav-link";

//     }

//     return $atts;

// }

// add_filter('nav_menu_link_attributes', 'add_a_class', 10, 4);



// add caret for submenus
function bpcs_menu_arrow($item_output, $item, $depth, $args) {
    if (in_array('menu-item-has-children', $item->classes)) {
        $arrow = '<span class="subMenuAngle"> <i class="fas fa-chevron-down"></i></span>'; // Change the class to your font icon
        $item_output = str_replace('</a>', '</a>'. $arrow .'', $item_output);
    }
    return $item_output;
}
add_filter('walker_nav_menu_start_el', 'bpcs_menu_arrow', 10, 4);