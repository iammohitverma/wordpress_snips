<?php 
/*
Template Name: Community Page
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('community_page_sections') ): ?>
    <?php while( have_rows('community_page_sections') ): the_row(); ?>
    <?php 
        //Banner Section.
        if( get_row_layout() == 'banner_section' ):?>
<!--section class="app_process_banner bg_grey">
    <div class="banner_main">
        <?php // get_template_part( 'template-parts/sections/banner_inner_pages' ); ?>
    </div>
</section-->
<!-- Common banner secion inner pages  -->
<section class="our_difference_newbanner cmn_new_banner bg_grey">
    <div class="container-fluid px-0">
         <?php get_template_part('template-parts/sections/banner_inner_pages_new'); ?>
    </div>
</section>

<?php
    // Welcome section  layout.
        elseif( get_row_layout() == 'be_part_section' ): 
    ?>
<section class="community_part pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                <?php $community_heading = get_sub_field('heading'); ?>
                    <h3 class="hdng">
                        <?php echo $community_heading ;?>
                    </h3>
                    <?php $community_desc = get_sub_field('description'); ?>
                    <p><?php echo $community_desc ;?> </p>
                </div>
            </div>
         <?php if( have_rows('hover_button') ): ?>
               <div class="col-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner pr-25">
                    <ul class="full_s_btn">
                    <?php  while ( have_rows('hover_button') ) : the_row(); 
                                    $community_button = get_sub_field('button');
                                    if( $community_button ): 
                                    $community_url = $community_button['url'];
                                    $community_title = $community_button['title'];
									$community_link_target = $community_button['target'] ? $community_button['target'] : '_self';
                                    ?>
                        <li>
                            <a href="<?php echo esc_url($community_url); ?>" target="<?php echo esc_attr( $community_link_target ); ?>"><?php echo esc_html( $community_title ); ?></a>
                        </li>
                        <?php endif; 
                        endwhile; ?>
                    </ul>
                </div>
             </div>
             <?php endif; ?>
        </div>
    </div>
</section>
<!-- 02 Section about difference end-->
<!-- 02 Section about difference end-->
<?php
elseif( get_row_layout() == 'question_section' ): 
?>
<!-- Questions start-->
<section class="questions_sec without_animation community">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->
<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>
