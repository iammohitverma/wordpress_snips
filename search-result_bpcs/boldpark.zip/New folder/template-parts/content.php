<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<h5 style="text-align:center">Posts Listing Template</h5>
	<?php the_content(); ?>
</article><!-- #post-<?php the_ID(); ?> -->


