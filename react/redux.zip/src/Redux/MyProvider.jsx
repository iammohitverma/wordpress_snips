import { createContext } from "react";
const MyFirstName = createContext();
function MyProvider({ children }) {
  const myData = {
    fname: "Mohit",
    lname: "Verma",
  };
  // return <MyFirstName.Provider value="Mohit">{children}</MyFirstName.Provider>;
  return <MyFirstName.Provider value={myData}>{children}</MyFirstName.Provider>;
}
export { MyFirstName, MyProvider };
