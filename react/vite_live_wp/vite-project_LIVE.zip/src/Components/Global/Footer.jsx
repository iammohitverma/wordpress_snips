import React from "react";

function Header() {
  return (
    <>
      <footer className="py-5 bg-dark">
        <p className="text-center text-white mb-0">© 2025 Company, Inc</p>
      </footer>
    </>
  );
}
export default Header;
