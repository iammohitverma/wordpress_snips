function onPageLoad() {
  // Get saved template from localStorage
  const saved = localStorage.getItem("gjs-saved-template");

  if (saved) {
    const { html, css } = JSON.parse(saved);

    // Inject CSS into a <style> tag in <head>
    const style = document.createElement("style");
    style.innerHTML = css;
    document.head.appendChild(style);

    // Inject saved HTML into the #frontend container
    const frontendContainer = document.getElementById("frontend");
    frontendContainer.innerHTML = html;
  }

  // [******** 🔥 Initialize firebase on loading 🔥 *******]
  const firebaseConfig = {
    apiKey: "AIzaSyBG2eDEe795hbrzJQzQo9dBteBjrgIvZ8c",
    authDomain: "test-5e3e4.firebaseapp.com",
    databaseURL: "https://test-5e3e4-default-rtdb.firebaseio.com",
    projectId: "test-5e3e4",
    storageBucket: "test-5e3e4.firebasestorage.app",
    messagingSenderId: "1082841988367",
    appId: "1:1082841988367:web:87108f036a3aee2dbc527a",
    measurementId: "G-QH0D9LJRG1",
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const db = firebase.database();

  // Get data from firebase realtime database 📥
  const userRef = firebase.database().ref("projectData/");
  userRef.once("value").then((snapshot) => {
    const data = snapshot.val();
    if (data) {
      const { html, css } = data;
      const style = document.createElement("style");
      style.innerHTML = css;
      document.head.appendChild(style);

      const frontendContainer = document.getElementById("frontend");
      frontendContainer.innerHTML = html;
    }
  });
}

window.addEventListener("load", onPageLoad);
