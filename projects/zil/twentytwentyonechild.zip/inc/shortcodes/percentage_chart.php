<div class="percentageChartWrap">
    <canvas id="percentageChart"></canvas>
</div>