<?php
/**
 * Template part for displaying Why This Quetion Section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
    $why_this_section = get_sub_field('content');
    $why_this_section_link = get_sub_field('link');
?>
<div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-12 col-sm-10 col-md-8 col-lg-6">
                        <div class="inner">
                            <?php echo $why_this_section; ?>
                            <a href="<?php echo $why_this_section_link['url'];?>" class="arrow_btn">
                    <?php echo $why_this_section_link['title'];?>
                        <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"/>
                        </svg>

                    </a>
                        </div>
                    </div>
                </div>
            </div>