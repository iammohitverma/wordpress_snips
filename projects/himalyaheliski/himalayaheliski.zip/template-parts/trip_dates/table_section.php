<?php
$heading = get_sub_field('heading');
$table = get_sub_field('table');
$table_heading = $table['table_heading'];
$table_content = $table['table_content'];
$table_footer = $table['table_footer'];
?>
<section class="common_table_sec pb_100">
    <div class="container">
        <div class="common_table pt-0">
            <div class="heading_wrap">
                <?php if ($heading): ?>
                    <h3 class="sec_heading"><?php echo $heading; ?></h3>
                <?php endif; ?>
            </div>
            <?php if ($table): ?>
                <div class="table_wrap">
                    <table border="0" cellpadding="0" cellspacing="0" class="table w-100">
                        <?php if ($table_heading): ?>
                            <thead>
                                <?php
                                foreach ($table_heading as $heading):
                                    $first_column = $heading['first_column'];
                                    $second_column = $heading['second_column'];
                                    ?>
                                    <tr>
                                        <th><?php echo $first_column; ?></th>
                                        <th><?php echo $second_column; ?></th>
                                    </tr>
                                <?php endforeach; ?>
                            </thead>
                        <?php endif; ?>
                        <?php if ($table_content): ?>
                            <tbody>
                                <?php
                                foreach ($table_content as $content):
                                    $first_column = $content['first_column'];
                                    $second_column = $content['second_column'];
                                    ?>
                                    <tr>
                                        <td><?php echo $first_column; ?></td>
                                        <td><?php echo $first_column; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        <?php endif; ?>
                    </table>
                    <?php if ($table_footer): ?>
                        <p><?php echo $table_footer; ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>