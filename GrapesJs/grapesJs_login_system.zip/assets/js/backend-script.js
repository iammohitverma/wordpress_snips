function onPageLoad() {
  const editor = window.editor;
  // ✅ custom blocks
  editor.BlockManager.add("my-block", {
    label: "2 Columns mohit",
    content: `<div class="row"><div class="col">Column 1</div><div class="col">Column 2</div></div>`,
    category: "Layout",
  });

  // Add custom button to the panel ✅
  editor.Panels.addButton("options", {
    id: "download-html",
    className: "fa-solid fa-download",
    command: "download-html",
    attributes: { title: "Download HTML" },
  });

  // Define the download command
  editor.Commands.add("download-html", {
    run(editor) {
      const html = editor.getHtml();
      const css = editor.getCss();
      const fullHtml = `
        <!DOCTYPE html>
        <html>
          <head>
              <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
              />
              <link
                href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
                rel="stylesheet"
              />
              <link rel="stylesheet" href="./assets/css/custom-style.css" />
            <style>${css}</style>
          </head>
          <body>
            ${html}
          </body>
        </html>
      `;

      const blob = new Blob([fullHtml], { type: "text/html" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "template.html";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
  });

  // Add Save Template button ✅
  editor.Panels.addButton("options", [
    {
      id: "save-template",
      className: "fa fa-save",
      command: "save-template",
      attributes: { title: "Save Template" },
    },
  ]);

  // Save Template command
  editor.Commands.add("save-template", {
    run(editor, sender) {
      sender && sender.set("active", false);

      const html = editor.getHtml();
      const css = editor.getCss();

      // save to localStorage
      // const template = { html, css };
      // localStorage.setItem("gjs-saved-template", JSON.stringify(template));
      // alert("Your changes are successfully saved! 😀");

      // Save to Firebase realtime database 💾
      firebase
        .database()
        .ref("admin/builderData")
        .set({
          html: html,
          css: css,
        })
        .then(() => {
          alert("Data saved successfully!");
        })
        .catch((error) => {
          console.error("Error saving data:", error);
        });
    },
  });

  // Optional: Load saved template on init if exists ✅
  // const saved = localStorage.getItem("gjs-saved-template");
  // if (saved) {
  //   const template = JSON.parse(saved);
  //   editor.setComponents(template.html);
  //   editor.setStyle(template.css);
  // }
}
window.addEventListener("load", onPageLoad);
