$(function () {
  $("#staticBackdrop").modal({
    backdrop: "static",
    keyboard: false,
  });
  // There's the gallery and the trash
  var $gallery = $("#bulbGallery"),
    $trash = $("#trash");
  var bulbVal = "";
  var barParentWidth = $(".progressBar").outerWidth();
  var loadingBar = $("#runProgress");
  var barWidth = 0;
  console.log(loadingBar);
  loadingBar.css("width", "0%");
  var score = 0;
  // Let the gallery items be draggable
  $("li .light", $gallery).draggable({
    cancel: "a.ui-icon", // clicking an icon won't initiate dragging
    revert: "invalid", // when not dropped, the item will revert back to its initial position
    containment: "document",
    helper: "clone",
    cursor: "grabbing",
  });

  // Let the trash be droppable, accepting the gallery items
  $trash.droppable({
    accept: "#bulbGallery > li .light.ui-draggable",
    classes: {
      "ui-droppable-active": "ui-state-highlight",
    },
    drop: function (event, ui) {
      mohitFun(ui.draggable);
    },
  });

  // My Function
  var sequenceOrder = [
    "uv",
    "red",
    "green",
    "blue",
    "nirlong",
    "nirshort",
    "whitelight",
  ];
  var i = 0;
  function mohitFun($item) {
    bulbVal = $item[0].getAttribute("data-light");
    console.log(bulbVal);

    if (sequenceOrder[i] == bulbVal) {
      $(".score").addClass("animate__bounce");
      setTimeout(function () {
        $(".score").removeClass("animate__bounce");
      }, 1000);
      score += 20;
      barWidth += barParentWidth / 7;
      loadingBar.css("width", barWidth + "px");
      $item.draggable({
        disabled: true,
      });
      i++;
      scoreUpdate();
      $item.css("filter", "drop-shadow(0px 0px 15px #fff)");
    } else {
      $item.addClass("shake");
      $(".score").css("background-color", "red");
      $(".score").addClass("animate__wobble");
      setTimeout(function () {
        $(".score").removeClass("animate__wobble");
      }, 1000);
      setTimeout(function () {
        $item.removeClass("shake");
        $(".score").css("background-color", "#06cebb");
      }, 1000);
      $item.draggable({
        disabled: false,
      });
      score -= 2;
      scoreUpdate();
    }
  }
  // Update Score Here
  function scoreUpdate() {
    $(".score").text(score);
    setTimeout(function () {
      if (i == 7) {
        $("#staticBackdropScore").modal({
          backdrop: "static",
          keyboard: false,
        });
        $(".game-score").html(`Your Score is <b> ${score} </b>`);
      }
    }, 1000);
  }
});
