<?php
/*
Template Name: Our Difference
*/
get_header(); // Load the header template

global $wp_query;
?>
	<?php 
    if (have_rows('our_difference_sections')) : 
        while (have_rows('our_difference_sections')) : the_row(); ?>
        
        <?php
            //Banner Section.
        if (get_row_layout() == 'banner_section') : ?>
        
<section class="our_difference_newbanner bg_grey cmn_new_banner">
    <div class="container-fluid px-0">
        <?php 
            $parent_pageId = wp_get_post_parent_id(get_the_ID());
            $parent_page = get_the_title($parent_pageId);
            $parent_page_url = get_the_permalink($parent_pageId);
            $page_title = $wp_query->post->post_title; 
        ?>
        <div class="banner_main">
            <div class="container">
                <div class="breadcrumbs">
                    <ul>
                        <?php if($parent_pageId != 0){ ?>
                            <li>
                                <a href="<?php echo $parent_page_url; ?>">
                                    <?php echo $parent_page; ?>
                                </a>
                            </li>
                            <?php } ?>
                                <li>
                                    <a href="javascript:void(0)" class="active">
                                        <?php echo $page_title; ?>
                                    </a>
                                </li>
                    </ul>
                </div>
            </div>
            <div class="banner_content_wrap">
                <div class="row">
                    <?php 
                        $banner_heading = get_sub_field('banner_heading');
                        $banner_desc = get_sub_field('banner_description');
                        $banner_img = get_sub_field('banner_image');
                    ?>
                        <div class="col-lg-5 col-md-6 col-sm-12 col-12">
                            <div class="left_main">
                                <div class="left_img"> 
                                <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-6 col-sm-12 col-12">
                            <div class="banner_content_inner">
                                <div class="right_cont">
                                    <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading;?></h2>
                                    <p>
                                        <?php echo $banner_desc; ?>
                                    </p>
                                </div>
								<div class="banner_links">
									<?php get_template_part( 'template-parts/sections/banner_links' ); ?>
								</div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 02 Section about difference Start-->
<?php elseif (get_row_layout() == 'video_section') :

    $section_heading = get_sub_field('section_heading');
    $heading = get_sub_field('heading');
    $description = get_sub_field('description');
?>
<section class="about_oD pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner">
                    <h2 class="hdng">
    <?php echo $section_heading; ?>
</h2>
                    <h3 class="sub_hdng">
    <?php echo $heading; ?>
</h3> </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner editor">
                    <p>
                        <?php echo $description; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 02 Section about difference end-->

<!-- Section 03 Video Section -->
<section class="single-video-sec hide_temp">
    <?php get_template_part('template-parts/sections/videos_section');  ?>
</section>
<!-- Section 03 Video Section End -->

<!-- Section 04 Accordian -->
	<?php elseif (get_row_layout() == 'accordion_section_new') :
        $acc_section_heading = get_sub_field('section_heading');
    ?>
<section class="accordian_wrapper new_design bg_grey">
	<div class="container">
		<div class="row">
            <div class="col-12">
                <h3 class="hdng">
                    <?php echo $acc_section_heading; ?>
                </h3>
                <div class="cmn_hr"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <?php
                    // check if the nested repeater field has rows of data
                    if( have_rows('accordions') ):
                    while ( have_rows('accordions') ) : the_row(); 
                    $accordion_heading = get_sub_field('accordion_heading'); 
                    $left_description = get_sub_field('accordion_left_description');
                    $right_image = get_sub_field('accordion_right_image');
                ?>
                <div class="accordion-item">
                    <div class="accordion-item-header">
                        <?php echo $accordion_heading ;?>
                    </div>
                    <!-- /.accordion-item-header -->
                    <div class="accordion-item-body" style="max-height: 0px;">
                        <div class="accordion-item-body-content">
                            <div class="row">
                                <?php if(empty($right_image)){ ?>
                                <div class="col-lg-12">
                                    <div class="left_content_accord">
                                        <p>
                                            <?php echo $left_description ;?>
                                        </p>
                                    </div>
                                </div>
                                <?php }else{ ?>
                                    <div class="col-lg-6">
                                    <div class="left_content_accord">
                                        <p>
                                            <?php echo $left_description ;?>
                                        </p>
                                    </div>
                                </div>
                                    <?php } ?>
                                    <?php if (!empty($right_image)) :?> 
                                <div class="col-lg-6">
                                    <div class="right_content_accord">
                                            <img src="<?php echo esc_url($right_image['url']); ?>">
                                    </div>
                                </div>
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.accordion-item-body -->
                </div>
                    <!-- /.accordion-item -->
                <?php endwhile; 
                    endif;
                ?>
            </div>
        </div>
    </div>
</section>
<?php elseif (get_row_layout() == 'our_difference_section') :
    $diff_section_heading = get_sub_field('section_heading');
?>
<!-- Section 05 hover expand items -->
<section class="ourDifferenceItems">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="hdng">
                    <?php echo $diff_section_heading; ?>
                </h3> 
            </div>
        </div>
    </div>
    <div class="items">
        <?php $i = 0; if (have_rows('blocks')) : ?>
            <ul>
                <?php while (have_rows('blocks')) : the_row();
                    $blocks_heading = get_sub_field('blocks_heading');
                    $blocks_link = get_sub_field('blocks_link');
                ?>
                    <li>
                        <div>
                            <h4 class="itemHdng">
                                <?php echo $blocks_heading; ?>
                            </h4>
                            <!-- ?php echo $blocks_link['url']; ?-->
                            <a href="javascript:void(0);" class="arrow_btn openPopup" data-id="popup-0<?php echo $i; ?>">
                                <?php echo $blocks_link['title']; ?>
                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                                    </svg>
                            </a>
                        </div>
                    </li>
                <?php $i++; endwhile; ?>
            </ul>
            <?php endif; ?>
    </div>
</section>

<?php
$section_color = array("bg_m_green", "bg_m_yellow", "bg_m_grey","bg_m_blue","bg_m_pink","bg_m_lGreen");
$i = 0; if (have_rows('blocks')) : 
     while (have_rows('blocks')) : the_row();
    ?>
<section class="modal_wrapper <?php echo $section_color[$i]; ?>" id="popup-0<?php echo $i; ?>">
    <div class="modal_b">
        <?php echo get_sub_field('block_popup'); ?>
        <img src="/wp-content/uploads/2023/09/close.png" alt="" class="close_popup_modal">
    </div>
</section>
<?php $i++; endwhile; endif; ?>
<!-- 06 Section testimonials start-->
<?php
    // Testimonial section  layout.
    elseif( get_row_layout() == 'testimonials_grid_section' ): 
?>
<section class="testimonials_grid bg_grey">
    <?php get_template_part( 'template-parts/sections/grid_testimonial' ); ?>
</section>
<!-- 06 Section testimonials end-->

<!-- Section 07 hover expand items -->
<?php elseif (get_row_layout() == 'join_us_section') :?>
<section class="join_us">
    <?php get_template_part('template-parts/sections/join_us'); ?>
</section>
<!-- Section 07 hover expand items End -->

<!-- Section 08 Apply Now Start -->
<?php elseif (get_row_layout() == 'apply_now_section') : ?>
<!-- Questions start-->
<section class="questions_sec">
    <?php get_template_part('template-parts/sections/apply_now'); ?>
</section>
<!-- Section 08 Apply Now End -->										
<?php get_footer(); // Load the footer template
        endif;
    endwhile;
endif;
?>
