import { useReducer } from "react";

let initialData = 0;

const reducer = (state, action) => {
  //function outside component
  console.log(state);
  console.log(action);
  action.type == "Increment" ? state++ : state--;
  return state; // need to return
};

export const ReducererHook = () => {
  const [state, dispatch] = useReducer(reducer, initialData); // same look like useState
  return (
    <>
      <h1>{state}</h1>
      <button onClick={() => dispatch({ type: "Increment" })}>Inc</button>
      <button onClick={() => dispatch({ type: "Decrement" })}>Dec</button>
    </>
  );
};
