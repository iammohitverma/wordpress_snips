import axios from "axios";
import React, { useState } from "react";

const baseUrl = import.meta.env.VITE_API_URL;

function SignupForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    fName: "",
    lName: "",
    password: "",
    phone: "",
    address: "",
    dob: "",
  });

  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const adminUsername = "main_admin";
    const appPassword = "kP71 fReK jLjF gMgq 79lY d6e0";

    const authString = btoa(`${adminUsername}:${appPassword}`);

    try {
      await axios.post(
        `${baseUrl}/wp-json/wp/v2/users`,
        {
          username: formData.name,
          email: formData.email,
          first_name: formData.fName,
          last_name: formData.lName,
          password: formData.password,
          meta: {
            phone: formData.phone,
            address: formData.address,
            dob: formData.dob,
          },

          roles: ["administrator"], // optional
          // // <-- same ACF field name
          //  this will work if inside functions.php meta code enabled for this
          // acf: {
          //   phone: formData.phone,
          //   address: formData.address,
          //   dob: formData.dob,
          // }, // <-- acf data fields not working
          // roles: ["administrator"], // optional
        },
        {
          headers: {
            Authorization: `Basic ${authString}`,
          },
        }
      );

      // const userId = res.data.id;

      // // Step 2: Update ACF fields
      // let trying = await axios.post(
      //   `${baseUrl}/wp-json/acf/v3/users/${userId}`,
      //   {
      //     phone: formData.phone,
      //     address: formData.address,
      //     dob: formData.dob,
      //   },
      //   {
      //     headers: {
      //       Authorization: `Basic ${authString}`,
      //     },
      //   }
      // );
      // console.log(trying);

      setMessage("Signup successful! ✅  Please login your account.");
    } catch (err) {
      console.log(err);
      setMessage("Signup failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-5">
      <div className="container">
        <div className="row">
          <div className="col-8 mx-auto">
            <div className="p-5 bg-body-tertiary rounded-3">
              <h2 className="text-center mb-3">Signup</h2>
              <form onSubmit={handleSignup} autoComplete="on">
                <div className="mb-3">
                  <label>Username</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.name}
                    name="name"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>Email</label>
                  <input
                    type="email"
                    className="form-control"
                    value={formData.email}
                    name="email"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>First Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.fName}
                    name="fName"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>Last Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.lName}
                    name="lName"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={formData.password}
                    name="password"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>Phone</label>
                  <input
                    type="phone"
                    className="form-control"
                    value={formData.phone}
                    name="phone"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                <div className="mb-3">
                  <label>Address</label>
                  <textarea
                    className="form-control"
                    name="address"
                    value={formData.address}
                    onChange={(e) => handleChange(e)}
                  ></textarea>
                </div>
                <div className="mb-3">
                  <label>DOB</label>
                  <input
                    type="dob"
                    className="form-control"
                    value={formData.dob}
                    name="dob"
                    onChange={(e) => handleChange(e)}
                  />
                </div>
                {loading && <p>Loading...</p>}
                {message && <p>{message}</p>}
                <button type="submit" className="btn btn-primary">
                  Signup
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default SignupForm; // <-- Export name v change kar ditta
