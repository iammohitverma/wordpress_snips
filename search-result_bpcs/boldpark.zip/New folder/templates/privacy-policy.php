<?php
/*
Template Name: Privacy policy
*/
get_header(); // Load the header template
?>
<section class="privacy_policy banner_main">
    <div class="container">
        <div class="the_content">
            <?php
            the_content();
            ?>
        </div>
    </div>
</section>
<?php
get_footer(); // Load the footer template 
?>