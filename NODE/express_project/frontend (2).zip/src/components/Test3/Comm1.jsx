import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Comm1 = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [cureTime, setCureTime] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleToggle = () => setIsEnabled(!isEnabled);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF9F0] to-[#F7E9D7] flex justify-center items-start py-16 px-4">
      <div className="w-full max-w-3xl bg-white rounded-lg shadow-md border border-gray-200 p-8">
        {/* Header panel with logo and step info */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-2">
            {/* Logo flame icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6 text-orange-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 3c0 2.993-3 5-3 8a3 3 0 006 0c0-3-3-5-3-8z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 12c0-1.105-1-2-1-2s1 2 1 4a1 1 0 102 0c0-1.333-2-2-2-2z"
              />
            </svg>
            <span className="font-semibold text-gray-900 text-lg">
              Candle Burn-Test Log
            </span>
          </div>

          <div className="text-sm text-gray-500 select-none">
            Step 2 of 4
            <span className="inline-flex ml-3 space-x-1">
              <span className="w-3 h-3 rounded-full bg-orange-400"></span>
              <span className="w-3 h-3 rounded-full bg-orange-400"></span>
              <span className="w-3 h-3 rounded-full bg-gray-300"></span>
              <span className="w-3 h-3 rounded-full bg-gray-300"></span>
            </span>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
          <h1 className="text-2xl font-bold text-center">Congratulations!</h1>
          <p className="mt-4 text-center">
            Congratulations, you have made your candle. Before you progress to the next section,
            allow your candle to cure...
          </p>
          <div className="mt-6 p-4 border border-gray-300 rounded-lg">
            <h2 className="text-lg font-semibold">SMS Reminder</h2>
            <p className="mt-2">
              Do you want an SMS Reminder when it's time to burn your candle? Input how many days
              you want your candle to cure and your phone number and we will remind you when it's time to burn.
            </p>

            <div className="flex items-center mt-4">
              <input
                type="checkbox"
                id="smsReminder"
                checked={isEnabled}
                onChange={handleToggle}
                className="mr-2"
              />
              <label htmlFor="smsReminder">Enable SMS reminder</label>
            </div>

            {isEnabled && (
              <div className="mt-4">
                <label htmlFor="cureTime" className="block mb-1">
                  Cure time (days):
                </label>
                <select
                  id="cureTime"
                  value={cureTime}
                  onChange={(e) => setCureTime(e.target.value)}
                  className="block w-full p-2 border border-gray-300 rounded-lg"
                >
                  <option value="" disabled>Select days</option>
                  <option value="7">e.g., 7</option>
                  <option value="14">14</option>
                  <option value="30">30</option>
                </select>

                <label htmlFor="phoneNumber" className="block mt-4 mb-1">
                  Phone number:
                </label>
                <input
                  type="tel"
                  id="phoneNumber"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+1 (555) 123-4567"
                  className="block w-full p-2 border border-gray-300 rounded-lg"
                />
              </div>
            )}
          </div>

          <div className="flex justify-between m-6">
            <Link to={"/home/test-2"} className="bg-red-500 text-white px-4 py-2 rounded-lg">Back</Link>
            <Link to={"/home/test-4"} className="bg-green-500 text-white px-4 py-2 rounded-lg">Next</Link>

          </div>

        </div>
      </div>
    </div>
  );
};

export default Comm1;
