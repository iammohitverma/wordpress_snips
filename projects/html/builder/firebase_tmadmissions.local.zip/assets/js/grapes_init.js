$(window).on("load", function () {
  const form = document.querySelector(".popup_tm form");
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const username = form.querySelector("#username").value;
    const password = form.querySelector("#password").value;

    try {
      const res = await fetch("/builder_testing/admin_login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        alert("Login successful!");
        // Hide popup or redirect to admin page
        document.querySelector(".popup_tm").classList.remove("active");
        // Optionally redirect
        window.location.href = "/builder_testing/admin_dashboard";
      } else {
        alert(data.message || "Login failed");
      }
    } catch (err) {
      alert("Login error: " + err.message);
    }
  });

  // builderCode
  if ($("body").find("#gjs").length == 1) {
    builderCode();
    $("body").addClass("builder_enabled");
  }

  // builderCode function here
  function builderCode() {
    const cssStyles = [
      "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css",
      "https://unpkg.com/splitting/dist/splitting.css",
      "https://unpkg.com/splitting/dist/splitting-cells.css",
      "https://unpkg.com/aos@next/dist/aos.css",
      "./assets/fonts/heebo/stylesheet.css",
      "./assets/fonts/roboto/stylesheet.css",
      "./assets/css/custom_style.css",
      "./assets/css/grapes_init.css",
    ];
    const jsScripts = [
      "https://code.jquery.com/jquery-3.7.1.min.js",
      "https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js",
      "https://unpkg.com/splitting/dist/splitting.min.js",
      "https://unpkg.com/aos@next/dist/aos.js",
      "./assets/js/custom_script.js",
    ];

    // const editor = grapesjs.init({
    //   container: "#gjs",
    //   fromElement: true, // This loads the existing HTML as editable components
    //   width: "100%",
    //   height: "100vh",
    //   storageManager: {
    //     id: "gjsdata-", // Prefix for localStorage keys
    //     type: "local", // Save to localStorage
    //     autosave: false, // Auto-save on changes
    //     autoload: false, // Load saved data on init
    //     stepsBeforeSave: 1, // Save after every change
    //   },
    //   plugins: ["gjs-blocks-basic"],
    //   pluginsOpts: {
    //     "gjs-blocks-basic": {},
    //   },
    //   canvas: {
    //     styles: cssStyles,
    //     scripts: jsScripts,
    //   },
    //   // Disable telemetry to avoid the 400 error
    //   telemetry: false,
    // });

    // [******** 🔥 Initialize firebase on loading 🔥 *******]
    const firebaseConfig = {
      apiKey: "AIzaSyBnGSpyRgLPDE8mFxZqIHSKBuMBqbdtQL8",
      authDomain: "techmind-admissions.firebaseapp.com",
      databaseURL: "https://techmind-admissions-default-rtdb.firebaseio.com",
      projectId: "techmind-admissions",
      storageBucket: "techmind-admissions.firebasestorage.app",
      messagingSenderId: "543261559477",
      appId: "1:543261559477:web:7b3065735fc3ecaa4d0cfc",
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    const db = firebase.database();
    console.log(db);

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // Get data from firebase realtime database 📥
    const userRef = firebase.database().ref("projectData/");
    userRef.once("value").then((snapshot) => {
      var data = snapshot.val();
      if (data) {
        debugger;
        const { html, css } = data;
        const style = document.createElement("style");
        style.innerHTML = css;
        document.head.appendChild(style);

        const backendContainer = document.getElementById("gjs");
        backendContainer.innerHTML = html;
      }

      const editor = grapesjs.init({
        container: "#gjs",
        width: "100%",
        height: "100vh",
        fromElement: false,
        plugins: ["gjs-blocks-basic"],
        canvas: {
          styles: cssStyles,
          scripts: jsScripts,
        },
        telemetry: false,
      });

      // Wait until editor is fully ready

      // Disable AOS inside the builder's iframe canvas after it's loaded and target iframe's element
      editor.on("load", () => {
        editor.setComponents(data.html);
        editor.setStyle(data.css);
        const iframe = document.querySelector("#gjs iframe");
        //   console.log(iframe);

        if (!iframe) return;

        const iframeWindow = iframe.contentWindow;
        if (iframeWindow && iframeWindow.AOS) {
          iframeWindow.AOS.init({
            disable: true,
          });
        }

        const iframeDoc =
          iframe.contentDocument || iframe.contentWindow.document;

        // Example: select the <header> inside the iframe
        const header = iframeDoc.querySelector("header");

        if (header) {
          // Do something with the header
          // header.style.backgroundColor = "red"; // Example: change background
          // console.log("Header found inside iframe:", header);
        } else {
          // console.log("No <header> found inside iframe.");
        }
      });

      // Add Save Template button ✅
      editor.Panels.addButton("options", [
        //   {
        //     id: "save-template",
        //     className: "fa fa-save",
        //     command: "save-template",
        //     attributes: { title: "Save Template" },
        //   },
        {
          id: "save-template",
          label: "Save", // 👈 This shows the text
          command: "save-template",
          attributes: { title: "Save Template" },
          // Optional: you can style it further using className
          className: "save-template-button", // Your custom class if needed
        },
      ]);

      // Save Template command
      editor.Commands.add("save-template", {
        run(editor, sender) {
          sender && sender.set("active", false);

          const html = editor.getHtml();
          const css = editor.getCss();
          const template = { html, css };

          // Show loader
          const loader = document.querySelector(".state_loader");
          if (loader) loader.classList.add("show");

          // Save to Firebase realtime database 💾
          firebase
            .database()
            .ref("projectData/")
            .set({
              html: html,
              css: css,
            })
            .then(() => {
              if (loader) loader.classList.remove("show");
            })
            .catch((error) => {
              console.error("Error saving data:", error);
            });
        },
      });

      // Logout button ✅
      editor.Panels.addButton("options", [
        {
          id: "logout-template",
          label: "Logout", // 👈 This shows the text
          command: "logout-template",
          attributes: { title: "Logout Template" },
          // Optional: you can style it further using className
          className: "logout-template-button", // Your custom class if needed
        },
      ]);

      // Logout button command
      editor.Commands.add("logout-template", {
        run(editor, sender) {
          sender && sender.set("active", false);

          // Call PHP logout script
          fetch("/builder_testing/logout")
            .then(() => {
              // Redirect to login page after logout
              window.location.href = "/builder_testing/login";
            })
            .catch((err) => {
              console.error(err);
              alert("Logout failed!");
            });
        },
      });
    });
  }
});
