<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package janusjustco-theme
 */

// get_header();
if (is_single(115941)) {
	get_header('tbo'); // Loads header-tbo.php
} else {
	get_header(); // Loads default header.php
}
?>

<div class="container-fluid p-0" id="single-post">
	<div class="">
		<?php the_content(); /*
while ( have_posts() ) :
the_post();
get_template_part( 'template-parts/single/single', get_post_type() );
endwhile; // End of the loop.*/
		?>
	</div>
</div>
<?php //get_footer(); ?>
<?php
if (is_single(115941)) {
	get_footer('tbo'); // Loads header-tbo.php
} else {
	get_footer(); // Loads default header.php
}
?>