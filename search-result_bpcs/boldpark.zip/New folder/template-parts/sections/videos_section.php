<?php
/**
 * Template part for displaying Video Section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

 $video_image = get_sub_field('image');
 $video_url = get_sub_field('video');
 if($video_url){
?>
    <div class="video_main">
        <?php if(empty($video_url)){ ?>
            <img src="<?php echo $video_image['url'];?>" alt="video-thumbnail" />
        <?php } ?>
        <?php echo $video_url;?>
    </div>
    <?php } ?>
