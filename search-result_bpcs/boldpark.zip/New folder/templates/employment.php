<?php 
/*
Template Name: About/Employment
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('employment_page_section') ): 
     while( have_rows('employment_page_section') ): the_row(); 
        //Banner Section.
        if( get_row_layout() == 'banner_section' ):
        $page_title = $wp_query->post->post_title; ?>
<section class="app_process_banner employment_banner bg_light_blue">
    <div class="banner_main">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="banner_left">
                        <div class="breadcrumbs">
                            <ul>
                                <li>
                                    <a href="javascript:void(0)" class="">About</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    
                </div>
                <div class="col-lg-2">
                    <div class="banner_links">
                    <?php get_template_part( 'template-parts/sections/banner_links' ); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php /* get_template_part( 'template-parts/sections/banner_inner_pages' ); */ ?>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php  
        elseif( get_row_layout() == 'about_section' ):
            $about_heading = get_sub_field('main_heading');
            $about_desc = get_sub_field('description');
       ?>
<!-- section 02 jobs start-->
<section class="jobs bg_light_blue">
    <div class="container">
        <div class="head">
            <h2><?php echo$about_heading; ?></h2>
            <p><?php echo$about_desc; ?>
            </p>
        </div>
        <!-- Loops Items -->
        <?php
        // Programs section  layout.
        elseif( get_row_layout() == 'jobs_section' ): 
            if( have_rows('jobs') ):
                while ( have_rows('jobs') ) : the_row(); 
                $job_title = get_sub_field('job_title');
                $job_description = get_sub_field('job_description');
                $job_contact = get_sub_field('contact_section');
        ?>
        <div class="inner mt-3 mt-sm-4 mt-lg-5">
            <h3><?php echo$job_title; ?></h3>
            <div class="row justify-content-between">
                <div class="col-md-4">
                    <div class="wrapper">
                        <p><?php echo$job_description; ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="wrapper right">
                    <?php echo$job_contact; ?>
						<?php if( have_rows('job_links') ): ?>
                        <div class="extra_buttons">
                        <?php while( have_rows('job_links') ): the_row(); 
                            $job_link = get_sub_field('job_link');
                            if($job_link){
                                $link_target = $job_link['target'] ? $job_link['target'] : '_self';
                                ?>
                                <a href="<?php echo $job_link['url']; ?>" class="cmn_btn" target="<?php echo $link_target; ?>"><?php echo $job_link['title']; ?></a>
                                <?php
                            }
                            ?>
                        <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php  
                endwhile; 
                endif; 
            ?>  
    </div>
</section>
<!-- section 02 jobs end-->


<?php endif; ?>
    <?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>
