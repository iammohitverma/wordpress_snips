<?php
/**
 * Template part for displaying Single Testimonial
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
$message_content = get_sub_field('message_content');
$author_name = get_sub_field('author_name');
$message_image = get_sub_field('message_image');

?>
<div class="container">
    <div class="row align-items-center">
		<div class="col-12 col-md-6 col-lg-6">
			<div class="lft">
				<img src="<?php echo $message_image['url'];?>">
			</div>
		</div>
        <div class="col-12 col-md-6 col-lg-6 ">
            <div class="inner ps-md-3">
                <p class="desc">
                    <?php echo$message_content; ?>
                </p>
                <p class="userName">
                    <?php echo$author_name; ?>
                    <!-- <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/heart.png" alt=""> -->
                </p>
            </div>
        </div>
    </div>
</div>