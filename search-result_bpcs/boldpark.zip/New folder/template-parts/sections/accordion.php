<?php
/**
 * Template part for displaying Accordion Section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
    
?>
<div class="row">
            <div class="col-12">
            <?php
                    // check if the nested repeater field has rows of data
                    if( have_rows('accordions') ):
                ?>
                <div class="accordion">
                <?php while ( have_rows('accordions') ) : the_row(); 
                      $accordion_heading = get_sub_field('accordion_heading'); 
                      $left_description = get_sub_field('accordion_left_description');
                      $right_description = get_sub_field('accordion_right_description');
                ?>
                    <div class="accordion-item">
                        <div class="accordion-item-header">
                            <?php echo $accordion_heading ;?>
                        </div><!-- /.accordion-item-header -->
                        <div class="accordion-item-body" style="max-height: 0px;">
                            <div class="accordion-item-body-content">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="left_content_accord">
                                        <?php echo $left_description ;?>
                                            <div class="shape_img">
                                                <a href="#" class="arrow_btn">
                                                    Watch the video
                                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                                                    </svg>
                                                </a>
                                            </div> 
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="right_content_accord">
                                        <?php echo $right_description ;?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- /.accordion-item-body -->
                    </div><!-- /.accordion-item -->
                    <?php endwhile; ?>
                </div>
                <?php
                    endif;
                ?>
            </div>
        </div>
        
        