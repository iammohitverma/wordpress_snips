$(document).ready(function () {


    var timer;
    var iqScore;
    var int, aa;

    $('input[type=radio][name=proteinLens]').change(function () {
        if (this.value == 'true') {
            var val = $('.fStopTimer');
            var score = val.html(); /* score */
            $(".apFigure img").addClass("d-none");
            $("#figureF0-7").removeClass("d-none");

            iqScore = 20
            $('.game-score').html("Your Score is " + "<b>" + iqScore + "</b>");
            $('#staticBackdropScore').modal({
                backdrop: 'static',
                keyboard: false
            })

            $("#runProgress").css("width", "100%");
            $("#runProgress").css("border-width", "2px");

            aa = document.querySelectorAll(".protienRadio");
            aa.forEach(element => {
                element.setAttribute("disabled", "disabled");
            });


        } else {
            $('#staticBackdropError').modal({
                backdrop: 'static',
                keyboard: true
            })
            if (this.value == 'f1_2') {
                $(".apFigure img").addClass("d-none");
                $("#figureF1-2").removeClass("d-none");
            } else if (this.value == 'f2_7') {
                $(".apFigure img").addClass("d-none");
                $("#figureF2-7").removeClass("d-none");
            } else if (this.value == 'f0_8') {
                $(".apFigure img").addClass("d-none");
                $("#figureF0-8").removeClass("d-none");
            } else if (this.value == 'f0_85') {
                $(".apFigure img").addClass("d-none");
                $("#figureF0-85").removeClass("d-none");
            }
        }
    });

    $("#playnextGame").click(function () {
        window.location.href = '#';
        // Check browser support
        if (typeof (Storage) !== "undefined") {
            // Store
            //sessionStorage.setItem("gameId", "game-5");
            //console.log(sessionStorage.getItem("gameId"));
        }
    });



});


$(window).on("load", function () {
    $('#staticBackdrop').modal({
        backdrop: 'static',
        keyboard: false
    })
});
