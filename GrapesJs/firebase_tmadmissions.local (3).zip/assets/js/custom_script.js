$(window).on("load", function () {
  let firebase = window.firebase;

  let frontend = document.getElementById("frontend");

  if (frontend) {
    firebase
      .database()
      .ref("publicTemplate")
      .once("value")
      .then((snapshot) => {
        const data = snapshot.val();
        if (data?.html && data?.css) {
          frontend.innerHTML = data.html;
          document
            .querySelector("head")
            .insertAdjacentHTML("beforeend", `<style>${data.css}</style>`);

          setTimeout(() => {
            $("body").addClass("loaded");
            $("body").removeClass("overflow-hidden");
            $(".preloader").addClass("hide");
            $(".preloader").removeClass("show");
            scriptInit();
          }, 3000);
        }
      });
  }

  function scriptInit() {
    var currentPage = window.location.href;
    $("body").addClass(currentPage);
    $(".page_type").val(currentPage);

    // set initial variables
    let header = $("header");
    let topbar = $("header .topbar");

    $("body").css("--headerHeight", header.outerHeight() + "px");
    $("body").css("--topbarHeight", -topbar.outerHeight() + "px");

    // sticky header
    $(window).on("scroll", function () {
      if ($(this).scrollTop() > topbar.outerHeight()) {
        header.addClass("sticky");
      } else {
        header.removeClass("sticky");
      }
    });

    // toggle menu
    $(".toggle-menu").click(function (e) {
      $(this).toggleClass("active");
      header.toggleClass("active");
      header.find("nav").slideToggle();
    });

    // banner text effect

    if ($("body").find("#gjs").length == 0) {
      if (window.innerWidth > 768) {
        Splitting();
      }
    }

    // courses cards hover effect
    if ($("body").find("#gjs").length == 0) {
      if (window.innerWidth > 768) {
        $(".course_wrap").tilt({
          maxTilt: 15,
          glare: true,
          maxGlare: 0.3,
        });
      }
    }

    // Aos animations
    AOS.init({
      disable: "mobile", // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
      startEvent: "DOMContentLoaded",
      initClassName: "aos-init",
      animatedClassName: "aos-animate",
      useClassNames: false,
      disableMutationObserver: false,
      debounceDelay: 50,
      throttleDelay: 99,
      offset: 250,
      delay: 30,
      duration: 1800,
      easing: "ease-out-back",
      once: true,
      mirror: false,
      anchorPlacement: "top-bottom",
      disable: function () {
        return /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
          navigator.userAgent
        );
      },
    });

    // select courses when user click on course boxes
    $(document).on("click", "[data-course]", function () {
      let course = $(this).attr("data-course");

      // Set value and trigger change event
      $("#select_programme").val(course).trigger("change");

      // Smooth scroll to apply_now section
      $("html, body").animate(
        {
          scrollTop: $("#apply_now").offset().top,
        },
        600
      );
    });

    // Load JSON file
    fetch("./assets/js/cities.json")
      .then((response) => response.json())
      .then((data) => {
        citiesData = data;
        populateStates();
      })
      .catch((error) => console.error("Error loading cities data:", error));

    // DOM elements
    const stateSelects = document.querySelectorAll(".select_state");
    const distSelects = document.querySelectorAll(".select_dist");
    const citySelects = document.querySelectorAll(".select_city");

    // Populate states
    function populateStates() {
      const states = Object.keys(citiesData).sort();

      stateSelects.forEach((stateSelect, index) => {
        stateSelect.innerHTML = '<option value="">Choose your state</option>';
        states.forEach((state) => {
          const option = document.createElement("option");
          option.value = state;
          option.textContent = state;
          stateSelect.appendChild(option);
        });

        // Add change event
        $(stateSelect).on("change", function () {
          populateDistricts(this, distSelects[index]);
          citySelects[index].innerHTML =
            '<option value="">Choose your city</option>'; // reset city when state changes
        });

        // Optionally trigger change
        $(stateSelect).trigger("change");
      });
    }

    // Populate districts
    function populateDistricts(stateSelect, distSelect) {
      const selectedState = stateSelect.value;
      distSelect.innerHTML = '<option value="">Choose your district</option>';

      if (selectedState && citiesData[selectedState]) {
        const districtsObj = citiesData[selectedState][0].districts;
        const districts = Object.keys(districtsObj).sort();
        districts.forEach((distName) => {
          const option = document.createElement("option");
          option.value = distName;
          option.textContent = distName;
          distSelect.appendChild(option);
        });

        $(distSelect).on("change", function () {
          populateCities(stateSelect, this, citySelects[0]);
        });
      }
    }

    // Populate cities
    function populateCities(stateSelect, distSelect, citySelect) {
      const selectedState = stateSelect.value;
      const selectedDistrict = distSelect.value;

      citySelect.innerHTML = '<option value="">Choose your city</option>';

      if (
        selectedState &&
        selectedDistrict &&
        citiesData[selectedState] &&
        citiesData[selectedState][0].districts[selectedDistrict]
      ) {
        const cities =
          citiesData[selectedState][0].districts[
            selectedDistrict
          ].cities.sort();
        cities.forEach((cityName) => {
          const option = document.createElement("option");
          option.value = cityName;
          option.textContent = cityName;
          citySelect.appendChild(option);
        });
      }
    }
    // Specialization field start
    let specializationOptions = {
      MBA: [
        "Human Resource Management",
        "Finance",
        "Marketing",
        "Operations Management",
        "Business Analytics",
        "Digital Marketing",
        "Data Science",
        "Information Technology",
        "International Business",
        "Dual Specialization",
      ],
      MCA: [
        "Machine Learning & AI",
        "Data Science",
        "Cybersecurity",
        "Full Stack Web Development",
        "AR/VR (Game Development)",
      ],
    };

    $(".select_specialization_parent").hide();

    $("#select_programme").on("change", function () {
      let selected_prog = $(this).val();

      let options = specializationOptions[selected_prog];

      if (options && options.length > 0) {
        let select = $("#select_specialization");
        select.empty();
        select.append('<option value="">	Select your area of interest</option>'); // Optional default

        options.forEach(function (spec) {
          select.append('<option value="' + spec + '">' + spec + "</option>");
        });

        $(".select_specialization_parent").show();
      } else {
        $(".select_specialization_parent").hide();
        $("#select_specialization").empty();
      }
    });

    // Specialization field end

    // Form validation script start by mohit
    // Select all forms and add on submit function for all forms
    let allForms = document.querySelectorAll("form");
    allForms.forEach((element) => {
      element.addEventListener("submit", validationFun);
    });

    // SetError msg function
    function setError(event, currentForm, element, errMsg) {
      currentForm.scrollIntoView({
        behavior: "smooth",
      });
      let errorWrap = document.createElement("SPAN");
      errorWrap.classList.add("errorBox");
      element.parentElement.appendChild(errorWrap);
      errorWrap.innerText = errMsg;
      event.preventDefault();
    }

    // check all fields
    function checkAllFields(event, element, currentForm) {
      let currInputVal = element.value;
      let currInputClass = element.getAttribute("class");
      if (currInputVal == "") {
        setError(event, currentForm, element, "This field is required");
      } else if (currInputClass.includes("email")) {
        if (
          currInputVal.indexOf("@") <= 0 ||
          (currInputVal.charAt(currInputVal.length - 4) != "." &&
            currInputVal.charAt(currInputVal.length - 3) != ".")
        ) {
          setError(event, currentForm, element, "Please fill Valid Email");
        }
      } else if (currInputClass.includes("phone")) {
        if (
          !isNaN(currInputVal) ||
          /^\(\d{3}\)\s*\d{3}(?:-|\s*)\d{4}$/.test(currInputVal) == true ||
          /^\d{3}(?:-|\s*)\d{3}(?:-|\s*)\d{4}$/.test(currInputVal) == true
        ) {
          let hiddenNumber = currInputVal;
          var str = hiddenNumber;
          var res = str.replace(/\D/g, "");
          if (res.length < 7 || res.length > 15) {
            setError(
              event,
              currentForm,
              element,
              "Please enter valid Contact Number"
            );
          }
        } else {
          setError(
            event,
            currentForm,
            element,
            "Please enter valid Contact Number"
          );
        }
      } else if (currInputClass.includes("check-radio-wrap")) {
        let getAllCheckedInput = element.querySelectorAll("input:checked");
        if (getAllCheckedInput.length == 0) {
          setError(
            event,
            currentForm,
            element.children[0],
            "This field is required"
          );
          element.classList.add("errorCheckRadio");
        } else {
          element.classList.remove("errorCheckRadio");
        }
      }
    }

    function removeAllErrors(currentForm) {
      // first remove old errorBox from current Form
      let allErrorBox = currentForm.querySelectorAll(".errorBox");
      allErrorBox.forEach((element) => {
        element.remove();
      });
    }

    function validationFun(event) {
      let allErrorBoxCheck;
      let currentForm = event.target;
      let allRequiredFields = currentForm.querySelectorAll(".required_field");

      // first remove old errorBox from current Form
      removeAllErrors(currentForm);

      allRequiredFields.forEach((element) => {
        checkAllFields(event, element, currentForm);
      });

      // get allErrorBox length after foreach loop
      allErrorBoxCheck = currentForm.querySelectorAll(".errorBox");

      // form submit using ajax inside this
      function formSubmitFun(event) {
        if (event.target.id == "admission_form") {
          // form fields:-
          $(".cmn_btn").prop("disabled", true);
          $(".loader").show();
          let name = event.target.name.value;
          let email = event.target.email.value;
          let country_code = event.target.country_code.value;
          let phone = event.target.phone_no.value;
          let state = event.target.select_state.value;
          let city = event.target.select_city.value;
          let programme = event.target.select_programme.value;
          let specialization = event.target.select_specialization.value;
          let checkbox = event.target.checkbox_field.value;
          // utm hidden fields:-
          let utm_source = event.target.utm_source.value;
          let utm_medium = event.target.utm_medium.value;
          let utm_campaignid = event.target.utm_campaignid.value;
          let utm_adgroupid = event.target.utm_adgroupid.value;
          let utm_creativeid = event.target.utm_creativeid.value;
          let utm_matchtype = event.target.utm_matchtype.value;
          let utm_device = event.target.utm_device.value;
          let utm_network = event.target.utm_network.value;
          let utm_keyword = event.target.utm_keyword.value;
          let utm_keywordid = event.target.utm_keywordid.value;
          let utm_campaign = event.target.utm_campaign.value;
          let gad_source = event.target.gad_source.value;
          let gbraid = event.target.gbraid.value;
          let gclid = event.target.gclid.value;
          let pageType = event.target.page_type.value;
          var formData = {
            name: name,
            email: email,
            country_code: country_code,
            phone: phone,
            state: state,
            city: city,
            programme: programme,
            specialization: specialization,
            checkbox: checkbox,
            utm_source: utm_source,
            utm_medium: utm_medium,
            utm_campaignid: utm_campaignid,
            utm_adgroupid: utm_adgroupid,
            utm_creativeid: utm_creativeid,
            utm_matchtype: utm_matchtype,
            utm_device: utm_device,
            utm_network: utm_network,
            utm_keyword: utm_keyword,
            utm_keywordid: utm_keywordid,
            utm_campaign: utm_campaign,
            gad_source: gad_source,
            gbraid: gbraid,
            gclid: gclid,
            pageType: pageType,
          };
          $.ajax({
            url: "landing-page-submissions.php",
            method: "POST",
            data: formData,
            dataType: "json",
            success: function (response) {
              $(".loader").hide();
              $(".cmn_btn").prop("disabled", false);
              $("#admission_form")[0].reset();
              if (response.success === true) {
                $(".success_msg").show();
                $(".error_msg").hide();
              } else {
                $(".success_msg").hide();
                $(".error_msg").show();
              }
            },
            error: function (xhr, status, error) {
              console.error(error);
            },
          });
        }
      }

      // check all fields before submit
      function fieldCheckFun(event) {
        event.preventDefault();
        if (allErrorBoxCheck.length == 0) {
          formSubmitFun(event);
        }
      }
      fieldCheckFun(event);
    }

    // Form urm parameters script start by mohit
    jQuery("#admission_form").submit(function (e) {
      const urlParams = new URLSearchParams(window.location.search);
      const keys = [
        "utm_source",
        "utm_medium",
        "utm_campaignid",
        "utm_adgroupid",
        "utm_creativeid",
        "utm_matchtype",
        "utm_device",
        "utm_network",
        "utm_keyword",
        "utm_keywordid",
        "utm_campaign",
        "gad_source",
        "gbraid",
        "gclid",
      ];

      keys.forEach((key) => {
        if (urlParams.has(key)) {
          const fields = e.target.querySelectorAll(`[name="${key}"]`);
          fields.forEach((field) => {
            field.value = urlParams.get(key);
          });
        }
      });
    });

    // Form urm parameters script end by mohit
  }
});
