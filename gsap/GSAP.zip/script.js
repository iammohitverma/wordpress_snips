document.addEventListener("DOMContentLoaded", (event) => {
  gsap.to(".box1", {
    x: "500",
    duration: 3,
    repeat: "-1",
    yoyo: true,
    ease: "elastic",
    rotation: 360,
  });
  gsap.from(".box2", {
    x: "500",
    duration: 3,
    repeat: "-1",
    yoyo: true,
    ease: "power1.inOut",
    rotation: 360,
  });

  //   fromTo
  gsap.fromTo(
    ".box3",
    {
      x: 0,
      rotation: 0,
      borderRadius: "0%",
    },
    {
      x: "500",
      rotation: 360,
      borderRadius: "100%",
      duration: 3,
      repeat: "-1",
      yoyo: true,
      ease: "bounce.out",
    }
  );

  //   using timeline
  var timeline = gsap.timeline({
    repeat: "-1",
    repeatDelay: 0,
    yoyo: true,
    ease: "elastic",
  });
  timeline.to(".box4", {
    x: "350",
    rotation: 0,
    borderRadius: "20px",
    duration: 1,
  });
  timeline.to(".box4", {
    x: "500",
    rotation: 360,
    borderRadius: "100%",
    duration: 1,
  });
  document.querySelector(".timelineBtns .play").onclick = () => {
    timeline.play();
  };
  document.querySelector(".timelineBtns .pause").onclick = () => {
    timeline.pause();
  };

  //   Stagger for multiple items
  gsap.from(".box_wrap .box", {
    y: "400",
    duration: 1.5,
    opacity: 0,
    repeat: "-1",
    yoyo: true,
    ease: "bounce",
    rotation: 360,
    stagger: 1,
  });

  //ScrollTrigger
  var t3 = gsap.timeline({
    scrollTrigger: {
      scroller: "body",
      trigger: ".scrollTrigger",
      pin: ".scrollTrigger",
      pinSpacing: true,
      scrub: 0.5,
    },
  });

  gsap.utils.toArray(".scrollTrigger .box").forEach((box, index) => {
    t3.from(box, {
      x: `+=${500 * (index + 1)}`, // Move each box differently based on its index
      opacity: 0,
    });
  });

  //   Text Animation
  //   gsap.from(".dark p", {
  //     y: "100",
  //     opacity: 0,
  //     duration: 1.5,
  //     ease: "ease",
  //     stagger: 0.2,
  //   });

  // Text animate with ScrollTrigger
  var t4 = gsap.timeline({
    scrollTrigger: {
      scroller: "body",
      trigger: ".dark",
      //   pin: ".dark",
      //   pinSpacing: true,
      //   scrub: 0.5,
      //   markers: true,
      start: "-50%",
    },
  });

  gsap.utils.toArray(".dark p").forEach((item, index) => {
    t4.from(item, {
      y: "100",
      opacity: 0,
      duration: 0.75,
      ease: "ease",
    });
  });

  //Split Text for characters
  let split = SplitText.create(".split", { type: "words, chars" });

  // now animate the characters in a staggered fashion
  gsap.from(split.chars, {
    duration: 1,
    y: 100, // animate from 100px below
    autoAlpha: 0, // fade in from opacity: 0 and visibility: hidden
    stagger: 0.1, // 0.05 seconds between each
  });

  //Split Text for lines
  let split_subheading = SplitText.create(".split_subheading", {
    type: "lines",
  });

  // now animate the characters in a staggered fashion
  gsap.from(split_subheading.lines, {
    duration: 1,
    y: 200, // animate from 100px below
    autoAlpha: 0, // fade in from opacity: 0 and visibility: hidden
    stagger: 0.05, // 0.05 seconds between each
    // Stagger each line’s animation by 0.1s
    ease: "power4.out",
  });

  //   //Split Text for words
  //   SplitText.create(".split", {
  //     type: "words",
  //     onSplit(self) {
  //       // runs every time it splits
  //       gsap.from(self.words, {
  //         duration: 1,
  //         y: 100,
  //         autoAlpha: 0,
  //         stagger: 0.5,
  //       });
  //     },
  //   });

  //   //Split Text for random positioned words
  //   let split = SplitText.create(".split", { type: "words" });
  //   gsap.from(split.words, {
  //     x: "random(-100, 100)",
  //     y: "random(-100, 100)",
  //     stagger: 1,
  //     onComplete: () => split.revert(), // <-- restores original innerHTML
  //   });

  /******************************/
  //   Glass effect section react
  /******************************/
  //   const isMobile = useMediaQuery({ maxWidth: 767 });
  //   const startValue = isMobile ? "top 50%" : "center 60%";
  //   const endValue = isMobile ? "120% top" : "bottom top";

  //   let tl = gsap.timeline({
  //     scrollTrigger: {
  //       trigger: "video",
  //       start: startValue,
  //       end: endValue,
  //       scrub: true,
  //       pin: true,
  //     },
  //   });

  //   videoRef.current.onloadedmetadata = () => {
  //     tl.to(videoRef.current, {
  //       currentTime: videoRef.current.duration,
  //     });
  //   };

  // Assuming you have access to GSAP and ScrollTrigger libraries
  // And videoRef will be the reference to the video element

  /*********************************/
  //   Glass effect section pure js
  /*********************************/
  // Check for mobile screen size
  const isMobile = window.matchMedia("(max-width: 767px)").matches;

  // Define the start and end values based on mobile or desktop
  const startValue = isMobile ? "top 50%" : "center 60%";
  const endValue = isMobile ? "120% top" : "bottom top";

  // GSAP timeline
  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: "video", // Trigger the animation on the video element
      start: startValue, // Start value
      end: endValue, // End value
      scrub: true, // Scrubbing for smooth animation based on scroll
      pin: true, // Pin the element during scroll
    },
  });

  // Handle the video playback based on loaded metadata
  const videoElement = document.querySelector("video");
  videoElement.onloadedmetadata = () => {
    tl.to(videoElement, {
      currentTime: videoElement.duration,
    });
  };
});
