<?php
/**
 * Template part for displaying Question Section (Grid)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>
