<?php 
/*
Template Name: About/Our People
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('our_people_page_section') ): ?>
<?php while( have_rows('our_people_page_section') ): the_row(); ?>
<?php 
        //Banner Section.
        if( get_row_layout() == 'banner_section' ): ?>
<!--section class="specialist_program our_campus_banner">
    <div class="banner_main">
        <?php  get_template_part( 'template-parts/sections/banner_inner_pages' ); ?>
    </div>
</section-->

<section class="our_difference_newbanner cmn_new_banner bg_camp">
    <div class="container-fluid px-0">
        <?php get_template_part('template-parts/sections/banner_inner_pages_new'); ?>
    </div>
</section>
<!-- Common banner secion inner pages  -->

<!-- 02 Section about difference Start-->
	<?php  elseif( get_row_layout() == 'our_teacher_section' ): 
		$section_heading = get_sub_field("section_heading");
		?>
<section class="our_people_tabs_section our_teachers pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="inner">
                    <h2 class="hdng main-heading"><?php echo $section_heading; ?></h2>
                </div>
            </div>
            <div class="col-12">
                <div class="inner">
                    <ul class="tabs_item">
                        <!-- <li>
                            <a href="javascript:void(0);" class="tab_item active tab_fun_tm" data-catId="0">
                                Our Leadership
                            </a>
                        </li> -->

                        <?php // display all categories for tabbing functionality
                        $args = array(
                            'child_of'                 => 0,
                            'parent'                   => '',
                            'order'                    => 'ASC',
                            'orderby'   => 'order_clause',   
                            'meta_query' => array(
                                'order_clause' => array(
                                    'type'=> 'NUMERIC',
                                    'key' => 'leadership_order'
                                )
                            ),
                            'hide_empty'               => 1,
                            'hierarchical'             => 1,
                            'taxonomy'                 => 'people-category',
                            'pad_counts'               => false
                        );
                        $categories = get_categories($args);
                        $cat_no = 1;
                        foreach ($categories as $category) {
                            
                            $url = get_term_link($category);
                        ?>

                        <li>
                            <a href="javascript:void(0);"
                                class="tab_item <?php if($cat_no == 1){?>active<?php } ?> tab_fun_tm"
                                data-catId="<?php echo $category->term_id; ?>"
                                data-catName="<?php echo $category->name; ?>">
                                <?php echo $category->name; ?>
                            </a>
                        </li>

                        <?php 
                        $cat_no++;
                        } ?>

                    </ul>


                    <hr class="cmn_hr">
                </div>
            </div>
            <div class="col-12">
                <div class="people_list">
                    <ul>

                        <?php
                        $args = array(
                            'post_type' => 'our-people',
                            'post_status' => 'publish',
                            'posts_per_page' => 15,
                            'tax_query' => array(
                            array(
                                'taxonomy' => 'people-category',  
                                'field' => 'slug',        
                                'terms' => 'leadership',   
                            ),
                        ),
                        );
                        
                        $arr_posts = new WP_Query( $args );
                        if ( $arr_posts->have_posts() ) :
                        while ( $arr_posts->have_posts() ) :
                        $arr_posts->the_post();
                    ?>


                        <li>
                            <figure>
                                <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                <!-- <span class="read_more_popup">
                                    Read More
                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z"
                                            fill="#1E1E1E"></path>
                                    </svg>
                                </span> -->
                                <?php
                                    // Get the current post content
                                    $post_content = get_the_content();

                                    // Check if the post content is empty
                                    if (empty($post_content)) {
                                        // If post content is empty, display static content
                                        echo "";
                                    } else {
                                        // If post content is not empty, display the post content
                                        ?>
                                    <span class="read_more_popup">
                                    Read More
                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z"
                                            fill="#1E1E1E"></path>
                                    </svg>
                                </span>
                                    <?php
                                    }
                                    ?>

                            </figure>
                            <div class="teacher_desc">
                                <h5 class="tchr_name"><?php the_title(); ?></h5>
                                <h6 class="tchr_post"><?php the_field('position'); ?></h6>
                            </div>

                            <!-- This code is just for appending in popup -->
                            <div class="modalBody" style="display:none!important;opacity:0!important;">
                                <p><?php the_field('position'); ?></p>
                                <h3><?php the_title(); ?></h3>
                                <div class="about_peple row">
                                    <div class="col-md-3">
                                        <div class="wrapper test">
                                            <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                            <?php //if( get_field('qualification') ): ?>
                                          <!--  <p><b>Qualification:</b><?php// the_field('qualification'); ?></p>-->
                                            <?php// endif; ?>

                                            <?php if( get_field('bpos') ): ?>
                                            <p><b>AT BPCS SINCE:</b><?php the_field('bpos'); ?></p>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="people_blog">
                                            <p>
                                                <?php the_content(); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- This code is just for appending in popup -->

                        </li>

                        <?php 
                        endwhile;
                        endif; 
                        wp_reset_postdata();
                    ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 02 Section about difference end-->
<?php
    // two_columns_section layout.
        elseif( get_row_layout() == 'two_columns_section' ): 
            $two_columns_heading = get_sub_field('column_heading');
            $two_columns_desc = get_sub_field('column_description');
            $two_columns_img = get_sub_field('image');
            $two_columns_button = get_sub_field('button');
            $two_columns_button_url = $two_columns_button['url'];
            $two_columns_button_title = $two_columns_button['title'];
    ?>
<!-- 03 Section employment start-->
<section class="join_us employment_section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-5 mt-4 mt-md-0 d-flex align-items-center">
                <div class="inner">
                    <h4 class="hdng">
                        <?php echo $two_columns_heading; ?>
                    </h4>
                    <p>
                        <?php echo $two_columns_desc; ?>
                    </p>
                    <a href="<?php echo esc_url( $two_columns_button_url ); ?>" class="cmn_btn">
                        <?php echo esc_html( $two_columns_button_title ); ?>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-7">
                <div class="inner">
                    <img src="<?php echo $two_columns_img['url'];?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 03 Section employment end-->
<?php
    // join_us layout.
        elseif( get_row_layout() == 'join_us_section' ): 
    ?>
<!-- 04 Section employment start-->
<section class="join_us">
    <?php get_template_part( 'template-parts/sections/join_us' ); ?>
</section>
<!-- 04 Section employment end-->
<?php
    // apply_now layout.
        elseif( get_row_layout() == 'apply_now_section' ): 
    ?>
<!-- 05 Section Questions start-->
<section class="questions_sec">
    <?php get_template_part( 'template-parts/sections/apply_now' ); ?>
</section>
<!-- 05 Section Questions end-->
<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>


<!-- /*** popup  */ -->
<div class="loading_wrapper" style="display:none;">
    <div class="inner">
        <div class="lds-default">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>

<section class="popupWrapper">
    <div class="people_popup">
        <div class="cross">
            <svg width="33" height="25" viewBox="0 0 33 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                <line x1="4.37339" y1="24.2079" x2="27.7079" y2="0.873338" stroke="#1E1E1E" stroke-width="1.3" />
                <line x1="5.29263" y1="0.8729" x2="28.6272" y2="24.2074" stroke="#1E1E1E" stroke-width="1.3" />
            </svg>
        </div>

        <!--- moday body start --->
        <div id="appendCntnt">
            <div class="modayBody">
                <p>PEDAGOGISTA</p>
                <h3>Nicole Hunter</h3>
                <div class="about_peple row">
                    <div class="col-md-3">
                        <div class="wrapper">
                            <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" alt="">
                            <p>QUALIFICATIONS: <br> Bachelor of Science</br> Graduate Diplomas in Education
                                </br>(Science and Early Childhood)</br> Masters of Education
                            </p>
                            <p>AT BPCS SINCE:
                                2004</p>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="people_blog">
                            <p>Nicole fervently believes that quality early life relationships, experiences and
                                education are critical in providing a solid foundation for healthy life patterns and
                                continuous learning. Nicole has both contributed
                                to and experienced the growth of Bold Park Community School as a parent, teacher and
                                board member; first joining the community in 2001, when the school was a one-room
                                primary school! She became part of the Early
                                Childhood teaching team in 2004.
                                <br> From 2008 until 2015 Nicole was Early Childhood Co-Team Leader with the
                                responsibility of expanding the outdoor learning program and National Quality Standards.
                                In 2016 Nicole was appointed to the role of Pedagogista.
                                This role sees her working, in collaboration, with the teaching teams and leadership to
                                align the principles, practices and philosophy of Bold Park with current educational
                                research and translate these into the
                                daily experience of students and families. <br> To this role, Nicole draws not only her
                                many years of experience in the Bold Park context, but also her teaching experience in a
                                breadth of contexts including high
                                school science and early years learning. Nicole is grateful to have had the opportunity
                                to travel internationally to visit educational contexts of Reggio Emilia and has
                                recently completed her Master’s of Education
                                in Teaching and Learning.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--- moday body start --->
    </div>
</section>