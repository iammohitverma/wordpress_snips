function afterPageLoad() {
  // Parallax Banner
  let parallaxInstance = null;

  function handleResponsiveBehavior() {
    const totalWidth = document.documentElement.clientWidth;

    if (totalWidth >= 992) {
      const scene = document.getElementById("scene");
      if (scene && !parallaxInstance) {
        parallaxInstance = new Parallax(scene);
      }
    } else {
      if (parallaxInstance) {
        parallaxInstance.disable(); // Disable Parallax behavior on small screens
        parallaxInstance = null;
      }
    }
  }
  handleResponsiveBehavior();
  window.addEventListener("resize", handleResponsiveBehavior);

  //   Header
  let header = document.querySelector("header");
  let body = document.querySelector("body");
  let menu_toggle = document.querySelectorAll(".menu_toggle");
  function openMenu(e) {
    menu_toggle.forEach((button) => {
      button.classList.toggle("active");
    });
    header.classList.toggle("active");
    body.classList.toggle("vh-100");
    body.classList.toggle("overflow-hidden");
  }
  menu_toggle.forEach((button) => {
    button.addEventListener("click", openMenu);
  });

  document.addEventListener("click", (e) => {
    if (
      !e.target.classList.contains("slide_navigation") &&
      !e.target.classList.contains("menu_toggle")
    ) {
      menu_toggle.forEach((button) => {
        button.classList.remove("active");
        header.classList.remove("active");
        body.classList.remove("vh-100");
        body.classList.remove("overflow-hidden");
      });
    }
  });
}
window.addEventListener("load", afterPageLoad);
