<div class="owl-carousel wrap_slider tm_image_slider">
  <?php 
    $page_id = get_the_ID();
  $images = acf_photo_gallery('slider_image',$page_id); 
      foreach($images as $image):
    ?>
    <div class="items">
        <img src="<?php echo $image['full_image_url']; ?>" alt="">
    </div>
    <?php endforeach; ?>
</div>