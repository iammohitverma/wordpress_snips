import React, { useState } from "react";
import { useTest } from '../../context/TestContext';
import { Link } from "react-router-dom";

export default function Comm1() {
    const { testData, setTestData } = useTest();

    const handleChange = (e) => {
        const { name, value } = e.target;

        setTestData((prev) => {
            const updatedData = { ...prev, [name]: value };
            console.log('Updated Test Data:', updatedData);

            return updatedData;
        });
    };

    return (
        <div className="min-h-screen bg-gradient-to-b from-[#FFF9F0] to-[#F7E9D7] flex justify-center items-start py-16 px-4">
            <div className="w-full max-w-3xl bg-white rounded-lg shadow-md border border-gray-200 p-8">
                {/* Header panel with logo and step info */}
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center space-x-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 3c0 2.993-3 5-3 8a3 3 0 006 0c0-3-3-5-3-8z" />
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 12c0-1.105-1-2-1-2s1 2 1 4a1 1 0 102 0c0-1.333-2-2-2-2z" />
                        </svg>
                        <span className="font-semibold text-gray-900 text-lg">Candle Performance Log</span>
                    </div>
                    <div className="text-sm text-gray-500 select-none">
                        Step 3 of 4
                        <span className="inline-flex ml-3 space-x-1">
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-orange-400"></span>
                            <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                        </span>
                    </div>
                </div>

                {/* Form content */}
                <div>
                    <h2 className="font-semibold text-gray-900 mb-6 text-xl">Performance Details</h2>

                    {/* Input field: Cold Fragrance Throw Rating */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Cold Fragrance Throw Rating (1-10):</span>
                        <input
                            type="number"
                            name="ColdFragrance"
                            value={testData.ColdFragrance || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 8"
                        />
                    </label>

                    {/* Input field: Visible Frosting */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Visible Frosting (Y/N):</span>
                        <select
                            name="VisibleFrosting"
                            value={testData.VisibleFrosting || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                        >
                            <option value="No">No</option>
                            <option value="Yes">Yes</option>
                        </select>
                    </label>

                    <h3 className="font-semibold text-gray-900 mb-4">Candle Burn After 1 Hour</h3>

                    {/* Input field: Percentage Melted to Edge */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Percentage Melted to Edge:</span>
                        <input
                            type="text"
                            name="PercentageMeltedtoEdge"
                            value={testData.PercentageMeltedtoEdge || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 80%"
                        />
                    </label>

                    {/* Input field: Depth of Melt Pool */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Depth of Melt Pool (cm):</span>
                        <input
                            type="number"
                            name="DepthofMeltPool"
                            value={testData.DepthofMeltPool || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 1.5"
                        />
                    </label>

                    {/* Input field: Amount of Smoking */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Amount of Smoking (None/Light/Heavy):</span>
                        <select
                            name="AmountofSmoking"
                            value={testData.AmountofSmoking || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                        >
                            <option value="None">None</option>
                            <option value="Light">Light</option>
                            <option value="Heavy">Heavy</option>
                        </select>
                    </label>

                    {/* Input field: Notes */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Notes:</span>
                        <textarea
                            name="Notes"
                            value={testData.Notes || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="Additional notes..."
                        />
                    </label>


              
                    {/* Disabled Image Upload Section */}
                    <span className="text-gray-700 text-sm font-medium mb-1 block">Upload Image:</span>
                    <div className="border border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center justify-center bg-gray-50 text-gray-500 w-full max-w-md mx-auto cursor-not-allowed">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-8 w-8 text-gray-400 mb-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth="2"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M3 7v10a4 4 0 004 4h10a4 4 0 004-4V7a4 4 0 00-4-4H7a4 4 0 00-4 4z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"
                            />
                        </svg>
                        <p>Photo uploads available with Premium</p>
                        <button
                            disabled
                            className="mt-1 text-orange-500 text-sm font-medium cursor-not-allowed"
                        >
                            Upgrade to Premium
                        </button>
                    </div>



                     <h3 className="font-semibold text-gray-900 mb-4">Candle Burn After 2 Hours</h3>

                    {/* Input field: Percentage Melted to Edge */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Percentage Melted to Edge:</span>
                        <input
                            type="text"
                            name="PercentageMeltedtoEdge2"
                            value={testData.PercentageMeltedtoEdge2 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 80%"
                        />
                    </label>

                    {/* Input field: Depth of Melt Pool */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Depth of Melt Pool (cm):</span>
                        <input
                            type="number"
                            name="DepthofMeltPool2"
                            value={testData.DepthofMeltPool2 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 1.5"
                        />
                    </label>

                    {/* Input field: Amount of Smoking */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Amount of Smoking (None/Light/Heavy):</span>
                        <select
                            name="AmountofSmoking2"
                            value={testData.AmountofSmoking2 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                        >
                            <option value="None">None</option>
                            <option value="Light">Light</option>
                            <option value="Heavy">Heavy</option>
                        </select>
                    </label>

                    {/* Input field: Notes */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Notes:</span>
                        <textarea
                            name="Notes2"
                            value={testData.Notes2 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="Additional notes..."
                        />
                    </label>

                    {/* Disabled Image Upload Section */}
                    <span className="text-gray-700 text-sm font-medium mb-1 block">Upload Image:</span>
                    <div className="border border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center justify-center bg-gray-50 text-gray-500 w-full max-w-md mx-auto cursor-not-allowed">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-8 w-8 text-gray-400 mb-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth="2"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M3 7v10a4 4 0 004 4h10a4 4 0 004-4V7a4 4 0 00-4-4H7a4 4 0 00-4 4z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"
                            />
                        </svg>
                        <p>Photo uploads available with Premium</p>
                        <button
                            disabled
                            className="mt-1 text-orange-500 text-sm font-medium cursor-not-allowed"
                        >
                            Upgrade to Premium
                        </button>
                    </div>

                

                      <h3 className="font-semibold text-gray-900 mb-4">Candle Burn After 3 Hours</h3>

                    {/* Input field: Percentage Melted to Edge */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Percentage Melted to Edge:</span>
                        <input
                            type="text"
                            name="PercentageMeltedtoEdge3"
                            value={testData.PercentageMeltedtoEdge3 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 80%"
                        />
                    </label>

                    {/* Input field: Depth of Melt Pool */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Depth of Melt Pool (cm):</span>
                        <input
                            type="number"
                            name="DepthofMeltPool3"
                            value={testData.DepthofMeltPool3 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 1.5"
                        />
                    </label>

                    {/* Input field: Amount of Smoking */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Amount of Smoking (None/Light/Heavy):</span>
                        <select
                            name="AmountofSmoking3"
                            value={testData.AmountofSmoking3 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                        >
                            <option value="None">None</option>
                            <option value="Light">Light</option>
                            <option value="Heavy">Heavy</option>
                        </select>
                    </label>

                    {/* Input field: Notes */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Notes:</span>
                        <textarea
                            name="Notes3"
                            value={testData.Notes3 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="Additional notes..."
                        />
                    </label>

                  
                    {/* Disabled Image Upload Section */}
                    <span className="text-gray-700 text-sm font-medium mb-1 block">Upload Image:</span>
                    <div className="border border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center justify-center bg-gray-50 text-gray-500 w-full max-w-md mx-auto cursor-not-allowed">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-8 w-8 text-gray-400 mb-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth="2"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M3 7v10a4 4 0 004 4h10a4 4 0 004-4V7a4 4 0 00-4-4H7a4 4 0 00-4 4z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"
                            />
                        </svg>
                        <p>Photo uploads available with Premium</p>
                        <button
                            disabled
                            className="mt-1 text-orange-500 text-sm font-medium cursor-not-allowed"
                        >
                            Upgrade to Premium
                        </button>
                    </div>

                  

                      <h3 className="font-semibold text-gray-900 mb-4">Candle Burn After 4 Hours</h3>

                    {/* Input field: Percentage Melted to Edge */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Percentage Melted to Edge:</span>
                        <input
                            type="text"
                            name="PercentageMeltedtoEdge4"
                            value={testData.PercentageMeltedtoEdge4 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 80%"
                        />
                    </label>

                    {/* Input field: Depth of Melt Pool */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Depth of Melt Pool (cm):</span>
                        <input
                            type="number"
                            name="DepthofMeltPool4"
                            value={testData.DepthofMeltPool4 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="e.g., 1.5"
                        />
                    </label>

                    {/* Input field: Amount of Smoking */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Amount of Smoking (None/Light/Heavy):</span>
                        <select
                            name="AmountofSmoking4"
                            value={testData.AmountofSmoking4 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                        >
                            <option value="None">None</option>
                            <option value="Light">Light</option>
                            <option value="Heavy">Heavy</option>
                        </select>
                    </label>

                    {/* Input field: Notes */}
                    <label className="block mb-4">
                        <span className="text-gray-700 text-sm font-medium mb-1 block">Notes:</span>
                        <textarea
                            name="Notes4"
                            value={testData.Notes4 || ''} onChange={handleChange}
                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-shadow hover:shadow-md hover:border-blue-500"
                            placeholder="Additional notes..."
                        />
                    </label>

                
                    {/* Disabled Image Upload Section */}
                    <span className="text-gray-700 text-sm font-medium mb-1 block">Upload Image:</span>
                    <div className="border border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center justify-center bg-gray-50 text-gray-500 w-full max-w-md mx-auto cursor-not-allowed">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-8 w-8 text-gray-400 mb-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth="2"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M3 7v10a4 4 0 004 4h10a4 4 0 004-4V7a4 4 0 00-4-4H7a4 4 0 00-4 4z"
                            />
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"
                            />
                        </svg>
                        <p>Photo uploads available with Premium</p>
                        <button
                            disabled
                            className="mt-1 text-orange-500 text-sm font-medium cursor-not-allowed"
                        >
                            Upgrade to Premium
                        </button>
                    </div>

                  
                    

                    {/* Navigation buttons */}
                    <div className="mt-8 border-t border-gray-200 pt-6 text-gray-400 italic text-center">
                        <div className="flex justify-between items-center mt-4">
                            <Link to={"/home/test-3"} className="bg-red-500 text-white px-4 py-2 rounded-lg">Back</Link>
                            <Link to={"/home/test-5"} className="bg-green-500 text-white px-4 py-2 rounded-lg">Next</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
