import React from 'react';
import axiosinstance from "../../api/axiosinstance";
import { useEffect, useState } from "react";
import DataDisplay from './DataDisplay';
const Comm1 = () => {

  const [datatest, setDatatest] = useState([]);
  const userEmail = localStorage.getItem('email');
  const [logcount, setlogcount] = useState(null)

  useEffect(() => {
    if (userEmail) {
      axiosinstance.get(`/api/test/get-tests/${userEmail}`)
        .then(res => {
          setDatatest(res.data);
          console.log(res.data);
          setlogcount(res.data.length)
        })
        .catch(err => {
          console.error('Error fetching test data:', err);
        });
    }
  }, [userEmail]);



  return (
    <div className="min-h-screen flex flex-col px-24  bg-gradient-to-r from-yellow-100 to-pink-100  p-5">
      <h1 className="text-3xl font-bold mb-2">My Burn Test Logs</h1>
      <p className="text-gray-700 mb-6">Manage and view your candle burn test history</p>

      <div className="border w-full flex items-center justify-between p-4 rounded shadow-md mb-6">
        <h2 className="font-semibold text-lg">
          Unlock Premium Features
        </h2>
        <p className="text-gray-600 text-sm">
          Upgrade to Premium for unlimited tests, photo uploads, SMS reminders, and detailed PDF reports.
        </p>
        <button className="mt-2 bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 transition duration-300">
          Upgrade Now
        </button>
      </div>
      <div className="mt-5">
        <p className="text-gray-600">Tests Used: {logcount} / 1</p>
      </div>


      <div className=" p-6 rounded shadow-md">
        {datatest && datatest.length > 0 ? (
          <div>
            <DataDisplay datatest={datatest} />
          </div>

        ) : (
          <div>
            <p className="text-gray-600 text-lg">No burn tests yet</p>
            <p className="text-gray-500 text-sm mt-2">
              Start by creating your first burn test to track your candle performance.
            </p>
          </div>
        )}



      </div>


    </div>
  );
}

export default Comm1;
