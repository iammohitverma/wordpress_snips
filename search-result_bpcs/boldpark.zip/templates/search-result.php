<?php
    /*
Template Name: Search Result
*/

get_header(); // Load the header template

?>


<?php include get_template_directory() . "/search-results.php"; ?>



<?php
    get_footer(); // Load the footer template 
?>