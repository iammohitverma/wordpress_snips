<?php
/* Template Name: Past Events */ 

get_header();
?>


<section class="upcoming_events py_100 mb_events">
    <div class="container">
        <div class="sec_heading text-center">
            <h2>Past Events</h2>
        </div>
        <div class="row">


        <?php
        $today = date('Ymd'); // format depending on how you store the date

            // The Query.
            $args = array(
                'post_type' => 'events',
                'order'    => 'DSC',
                'posts_per_page' => -1,
                'meta_key' => 'event_end_date',
                'meta_value' => $today,
                'meta_compare' => '<=',
                'orderby' => 'meta_value',
                'order' => 'ASC',
            );
            
            $the_query = new WP_Query( $args );

            // The Loop.
            if ( $the_query->have_posts() ) {
                while ( $the_query->have_posts() ) {
                    $the_query->the_post(); 
                    $event_title = get_the_title();
                    $event_url = get_the_permalink();
                    $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
                    $event_end_date = get_field('event_end_date');
                    ?>
                    
                    <div class="col-md-6 col-lg-4">
                        <div class="event_card">
                            <div class="img_box cover">
                                <img src="<?php echo $featured_img_url;?>" alt="<?php echo $event_url;?>" class="cover">
                            </div>
                            <div class="event_details cover flex_center">
                                <h3><?php echo $event_title;?></h3>
                                <p> Event Ends on <?php echo $event_end_date;?></p>
                            </div>
                            <a href="<?php echo $event_url;?>" class="cover event_link"></a>
                        </div>
                    </div>

                    <?php
                }
            } else {
                esc_html_e( 'Sorry, no posts matched your criteria.' );
            }
            // Restore original Post Data.
            wp_reset_postdata();
        ?>


        </div>
    </div>
</section>






<?php get_footer();?>