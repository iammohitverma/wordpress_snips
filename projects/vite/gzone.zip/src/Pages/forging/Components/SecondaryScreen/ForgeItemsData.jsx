const ForgeItemsData = {
    main_hand: {
        items: [
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" }
        ]
    },
    off_hand: {
        items: [
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
        ]
    },
    armor: {
        items: [
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
            { itemImage: "/forge_item.jpg" },
        ]
    },
}
export default ForgeItemsData;