Run following command
`npm install`
`node main.js`