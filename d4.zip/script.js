$(".owl-carousel").owlCarousel({
  loop: false,
  margin: 0,
  nav: false,
  dots: false,
  mouseDrag: true,
  touchDrag: true,
  autoplay: false,
  stagePadding: 100,
  nav: false,
  dots: false,
  smartSpeed: 600,
  responsive: {
    0: {
      items: 1,
      stagePadding: 30,
    },
    768: {
      items: 2,
      stagePadding: 50,
    },
    992: {
      items: 3,
      stagePadding: 60,
    },
    1200: {
      items: 3,
      stagePadding: 60,
    },
  },
});
