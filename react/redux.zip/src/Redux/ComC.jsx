import { useContext } from "react";
import { MyFirstName } from "./MyProvider";
const ComC = () => {
  const data = useContext(MyFirstName);
  const viewContext = () => {
    console.log(data);
  };
  return (
    <>
      <button onClick={() => viewContext()}>Click me</button>
    </>
  );
};
export default ComC;
