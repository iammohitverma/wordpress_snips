<?php 
/*
Template Name: Enrolment/Fees & Policies
*/
get_header(); // Load the header template
?>

<?php if( have_rows('fees_and_policies_section') ): ?>
    <?php while( have_rows('fees_and_policies_section') ): the_row(); 

if( get_row_layout() == 'banner_section' ): 
$banner_intro = get_sub_field("banner_intro");
?>
<!-- Common banner secion inner pages  -->
<section class="our_difference_newbanner bg_grey cmn_new_banner">
        <?php get_template_part( 'template-parts/sections/banner_inner_pages_new' );  ?>
</section>
<!-- Common banner secion inner pages  -->

<?php if($banner_intro){ ?>
<section class="program_intro pt_extra">
    <dic class="container_fluid">
        <dic class="container">
            <div class="text_wrapper">
                <p>
					<?php echo $banner_intro; ?>
                </p>
            </div>
        </dic>
    </dic>
</section>

<?php  } ?>

<?php elseif( get_row_layout() == 'accordion_section' ):
$accord_heading = get_sub_field('accordion_heading');    
?>
<section class="accordian_section accordian_wrapper pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!--h2 class="hdng"><--?php echo $accord_heading; ?></h2-->
                <?php
                    if( have_rows('accordions') ):
                ?>
                <div class="accordion">
                    <?php while ( have_rows('accordions') ) : the_row(); ?>
                    <div class="accordion-item">
                        <?php 
                        $accordion_heading = get_sub_field('accordion_heading');
                        $accordion_type = get_sub_field('type_of_content');
                        $accordion_download = get_sub_field('download_button');
                        $left_description = get_sub_field('accordion_left_description');
                        $right_description = get_sub_field('accordion_right_description');
                        ?>
                        <div class="accordion-item-header <?php if($accordion_type == "link") { echo "link_btn_wrapper"; }?>">
                            <?php echo $accordion_heading ;
                            
                            if($accordion_type == "link" && $accordion_download != "") { ?>
                            <a href="<?php echo $accordion_download['url'];?>" class="cmn_btn" download>Download</a>
                            <?php } ?>
                        </div><!-- /.accordion-item-header -->

                        <div class="accordion-item-body" style="max-height: 0px;">
                        <?php if($accordion_type == "description" && ($left_description != "" || $right_description != "")) { ?>
                            <div class="accordion-item-body-content">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="left_content_accord">
                                             <?php echo $left_description ;?>
                                            <div class="shape_img">
                                                <a href="#" class="arrow_btn">
                                                    Watch the video
                                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="right_content_accord">
                                            <?php echo $right_description ;?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        <?php } ?>
                        </div><!-- /.accordion-item-body -->
                    </div><!-- /.accordion-item -->
                    <?php endwhile; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php elseif( get_row_layout() == 'question_section' ): ?>
<!-- Questions start-->
<section class="questions_sec without_animation fees_page">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->

<?php 
endif;
endwhile;
endif;

get_footer(); // Load the footer template ?>
