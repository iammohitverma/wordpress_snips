<?php
/**
 * Template part for displaying Shapes Section on Home & Enrolment Page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
?>

<?php 
$html = '';
$page_id = $wp_query->post->ID;
$banner_menu = get_sub_field('select_menu');
$menu = wp_get_nav_menu_object($banner_menu);
if ($menu) {
    $menu_id = $menu->term_id;
    $menu_items = wp_get_nav_menu_items($menu_id);
    // echo "<pre>"; print_r($menu_items); echo "</pre>";
    $child_menu_items = array_filter($menu_items, function ($item) {
        return $item->menu_item_parent != '0';
    });
    if (!empty($child_menu_items)) {
        $html .='<ul>';
        foreach ($child_menu_items as $key=>$item) {
            if($item->object_id == $page_id){
                $status_cls = "active";
            }else{
                $status_cls = "";
            }

            if($item->classes[0] != ""){
                $menu_cls = $item->classes[0];
            }else{
                $menu_cls = "";
            }
            $target = ($item->target == '_blank') ? '_blank' : '_self';
            $html .='<li class="'.$key.' '.$menu_cls.'"><a href="' . $item->url . '" class="'.$status_cls.'" target='.$target.'>' . $item->title . '</a></li>';
        }
        $html .='</ul>';

        echo $html;
    } else {
       
    }
} else {
}
?>