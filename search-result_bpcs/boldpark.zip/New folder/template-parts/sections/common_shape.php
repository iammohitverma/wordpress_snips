<?php
/**
 * Template part for displaying Shapes Section on Home & Enrolment Page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

$shape_heading = get_sub_field('section_heading');
?>
<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-12">
            <div class="inner">
                <h2 class="hdng">
                    <?php echo $shape_heading; ?>
                </h2>
                <hr class="cmn_hr">
            </div>
        </div>  
        <?php if( have_rows('shape_content') ): 
        while ( have_rows('shape_content') ) : the_row();
        
        $heading = get_sub_field('heading');
        $description = get_sub_field('description');
        $link = get_sub_field('button');
        ?>
        <div class="col-12 col-sm-10 col-md-7 col-xl-4 shape">
            <div class="inner">
                <h4 class="hdng">
                    <?php echo $heading ;?>
                </h4>
                <p><?php echo $description ;?></p>
               <?php if( $link ):  ?>
                <a href="<?php echo $link['url'];?>" class="cmn_btn"><?php echo $link['title'];?></a>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; 
        endif; ?>
    </div>
</div>