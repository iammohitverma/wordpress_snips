import React from 'react'
import Comm1 from '../components/Signup/Comm1'

const Signup = () => {
  return (
    <div>
      <Comm1 />
    </div>
  )
}

export default Signup
