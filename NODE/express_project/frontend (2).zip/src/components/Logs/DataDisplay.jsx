import React from "react";

const DataDisplay = ({ datatest }) => {
  return (
    <div className="min-h-screen w-full  p-6">
      <h1 className="text-4xl font-extrabold text-center text-black mb-10 tracking-wide">
        Candle Data Overview
      </h1>
      <div className=" mx-auto grid   gap-8">
        {datatest.map((item, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-lg p-6  transform transition duration-300 cursor-pointer border border-transparent hover:border-purple-400"
            tabIndex={0}
            aria-label={`Details for ${item.Fragrance}`}
          >
            <h2 className="text-xl font-semibold  mb-4 border-b border-purple-300 pb-2 truncate">
              {item.Fragrance}
            </h2>
            <dl className="space-y-2 text-gray-700">
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Wick</dt>
                <dd className="truncate">{item.Wick}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Volume</dt>
                <dd className="truncate">{item.Volume}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Fragrance Supplier</dt>
                <dd className="truncate">{item.FragranceSupplier}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Use Dye Color</dt>
                <dd>{item.UseDyeColor}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Use Dye Stabilizer</dt>
                <dd>{item.UseDyeStabilizer}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Wax Melting Temp</dt>
                <dd>{item.WaxMeltingTemperature}°C</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Blending Temp</dt>
                <dd>{item.BlendingTemperature}°C</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Pouring Temp</dt>
                <dd>{item.PouringTemperature}°C</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Cooling Time</dt>
                <dd>{item.CoolingTime} minutes</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Container Type</dt>
                <dd>{item.ContainerType}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Container Supplier</dt>
                <dd>{item.ContainerSuppllier}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Container Size</dt>
                <dd>{item.ContainerSize}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Cold Fragrance %</dt>
                <dd>{item.ColdFragrance}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Visible Frosting</dt>
                <dd>{item.VisibleFrosting}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">% Melted to Edge (1)</dt>
                <dd>{item.PercentageMeltedtoEdge}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Depth of Melt Pool (1)</dt>
                <dd>{item.DepthofMeltPool1}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Amount of Smoking (1)</dt>
                <dd>{item.AmountofSmoking}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Notes (1)</dt>
                <dd>{item.Notes}</dd>
              </div>
              {/* Display second set */}
              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-purple-200">
                <dt className="font-medium">% Melted to Edge (2)</dt>
                <dd>{item.PercentageMeltedtoEdge2}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Depth of Melt Pool (2)</dt>
                <dd>{item.DepthofMeltPool2}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Amount of Smoking (2)</dt>
                <dd>{item.AmountofSmoking2}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Notes (2)</dt>
                <dd>{item.Notes2}</dd>
              </div>
              {/* Third set */}
              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-purple-200">
                <dt className="font-medium">% Melted to Edge (3)</dt>
                <dd>{item.PercentageMeltedtoEdge3}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Depth of Melt Pool (3)</dt>
                <dd>{item.DepthofMeltPool3}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Amount of Smoking (3)</dt>
                <dd>{item.AmountofSmoking3}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Notes (3)</dt>
                <dd>{item.Notes3}</dd>
              </div>
              {/* Fourth set */}
              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-purple-200">
                <dt className="font-medium">% Melted to Edge (4)</dt>
                <dd>{item.PercentageMeltedtoEdge4}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Depth of Melt Pool (4)</dt>
                <dd>{item.DepthofMeltPool4}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Amount of Smoking (4)</dt>
                <dd>{item.AmountofSmoking4}</dd>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <dt className="font-medium">Notes (4)</dt>
                <dd>{item.Notes4}</dd>
              </div>
            </dl>
            <div className="mt-6 pt-4 border-t border-purple-300 text-sm text-gray-500 italic">
              {item.MainNote}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DataDisplay;

