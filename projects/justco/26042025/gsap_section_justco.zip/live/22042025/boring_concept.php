<section class="boring_concept" style="background-color: #182f92">
   <div class="start_container">
      <div class="slide_row">
         <div class="slide text_wrap">
            <h3 class="hdng_58">
               the boring <br /><span class="pt_serif">concept</span>
            </h3>
            <p>
               just so you know, our offices cut differently. boring, butdamn
               good-looking. you’ll like us.
            </p>
         </div>
         <div class="slide special img_box">
            <img src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img.png" alt="Boring Concept" />
         </div>
         <div class="slide boxed_text">
            <div class="inner">
               <h4><i>01</i></h4>
               <h3>no hidden fees, no surprises —</h3>
               <p>
                  just straightforward pricing, so you know exactly what you’re
                  getting.
               </p>
            </div>
         </div>
         <div class="slide text_wrap">
            <h3 class="hdng_58">
               the boring <br /><span class="pt_serif">concept</span>
            </h3>
            <p>
               just so you know, our offices cut differently. boring, butdamn
               good-looking. you’ll like us.
            </p>
         </div>
         <div class="slide special img_box">
            <img src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img.png" alt="Boring Concept" />
         </div>
         <div class="slide boxed_text">
            <div class="inner">
               <h4><i>01</i></h4>
               <h3>no hidden fees, no surprises —</h3>
               <p>
                  just straightforward pricing, so you know exactly what you’re
                  getting.
               </p>
            </div>
         </div>
      </div>
   </div>
</section>