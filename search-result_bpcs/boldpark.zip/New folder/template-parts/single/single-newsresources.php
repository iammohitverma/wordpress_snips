<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>

<div class="single-post-head">
    <div class="container">
        <div class="inner">
            <div class="left">
                <a href="<?php echo get_site_url(); ?>/community">Community</a>
                <a href="<?php echo get_site_url(); ?>/news-resources">News & Resources</a>
                <a href="javascript:void(0);" class="active">Article: 
                    <!-- get current post title -->
                    <?php echo get_the_title();?>
                </a>
            </div>
            <div class="right">
                <a href="javascript:void(0);"><?php echo get_the_date( 'd-m-Y' );  ?></a>
                <ul>
                    <?php
                    // get all selected post's categories
                        global $post;
                        $categories = get_the_category($post->ID);
                        if ( ! empty( $categories ) ) {
                            foreach ( $categories as $cat ) {
                                echo '<li><a href="/category/' . $cat->slug . '">' . esc_html( $cat->name ) . '</a></li>';
                            }
                        }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <?php the_content(); ?>
	
</div><!-- #post-<?php the_ID(); ?> -->

<div class="single-post-navigate">
    <div class="inner">
        <div class="left">
            <div class="btn-wrap">
                <div class="simple-btn">
                    <?php previous_post_link( '%link', 'Previous' ); ?>
                </div>
                <div class="outline-btn">
                    <?php previous_post_link( '%link', 'Read more' ); ?>
                </div>
            </div>
            <p>
                <?php
                    $previous = get_previous_post();
                    if ( get_previous_post() ) { 
                        echo get_the_title($previous);
                    }
                ?>
            </p>
        </div>
        <div class="center">
            <figure>
                <img src="/wp-content/uploads/2023/05/post-navigation-shape.png" alt="shapes">
            </figure>
        </div>
        <div class="right">
            <div class="btn-wrap">
            <div class="simple-btn">
                    <?php next_post_link( '%link', 'Next' ); ?>
                </div>
                <div class="outline-btn">
                    <?php next_post_link( '%link', 'Read more' ); ?>
                </div>
            </div>
            <p>
                <?php
                    $next = get_next_post();
                    if ( get_next_post() ) { 
                      echo get_the_title($next);
                    }
                ?>
            </p>
        </div>
    </div>
</div>


