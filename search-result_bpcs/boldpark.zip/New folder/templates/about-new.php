<?php
/*
Template Name: About new Page
*/

get_header(); // Load the header template

?>
<!-- Section 01 Banner -->
<?php if (have_rows('about_page_section')) : ?>
<?php while (have_rows('about_page_section')) : the_row(); ?>
<?php
        //Banner Section.
        if (get_row_layout() == 'banner_section') :
        ?>

<section class="our_difference_newbanner cmn_new_banner bg_sb">
    <div class="container-fluid px-0">
        <div class="banner_main">
            <?php 
                $parent_pageId = wp_get_post_parent_id(get_the_ID());
                $parent_page = get_the_title($parent_pageId);
                $parent_page_url = get_the_permalink($parent_pageId);
                $page_title = $wp_query->post->post_title; 
            ?>
            <div class="container">
                <div class="breadcrumbs">
                    <ul>
                        <?php if($parent_pageId != 0){ ?>
                        <li>
                            <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                        </li>
                        <?php } ?>
                        <li>
                            <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                        </li>
                    </ul>
                </div>
            </div>
            <?php 
                $banner_heading = get_sub_field('banner_heading');
                $banner_desc = get_sub_field('banner_description');
                $banner_img = get_sub_field('banner_image');
            ?>
            <div class="banner_content_wrap">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                        <div class="left_main">

                            <div class="left_img">
                            <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                            <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                        <div class="banner_content_inner">
                            <div class="right_cont">
                                <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading;?></h2>
                                <p> <?php echo $banner_desc; ?></p>
                            </div>
                            <div class="banner_links">
                               <?php get_template_part( 'template-parts/sections/banner_links' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Section 01 Banner -->

<!-- Section 02 ouer mission -->

<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'our_mission_vision') :
        ?>
<section>
    <div class="container">
        <div class="our_mission_main">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mv_left">
                        <div class="m_heading">
                            <?php $sectionheading = get_sub_field('section_heading'); ?>
                            <h3 class="bg_hdng sec_title_90">
                                <?php echo $sectionheading; ?>
                            </h3>
                        </div>
                        <?php $image = get_sub_field('image');
                                    if (!empty($image)) : ?>
                        <div class="m_img">
                            <img src="<?php echo esc_url($image['url']); ?>" alt="welcome_hero" />
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 d-flex align-items-center">
                    <?php $missiondesc = get_sub_field('heading'); ?>
                    <div class="mv_right">
                        <?php $missionheading = get_sub_field('heading'); ?>
                        <?php $missionheadesc = get_sub_field('description'); ?>
                        <h6 class="hdng">
                            <?php echo $missionheading; ?>
                        </h6>
                        <p>
                            <?php echo $missionheadesc; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Section 02 ouer mission -->
<?php elseif (get_row_layout() == 'video_section') : ?>
<!-- Section 03 video -->
<section class="single-video-sec hide_temp">
    <?php get_template_part('template-parts/sections/videos_section'); ?>
</section>
<!-- Section 03 video -->

<!-- Section 04 Principal -->
<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'principal_message') :
        ?>
<section class="bg_grey principal_section scroll_margin_top" id="principal_welcome">
    <div class="container">
        <div class="principal_main">
            <div class="row">
                <div class="col-lg-4">
                    <div class="principal_left">
                        <?php

                                    $section_heading = get_sub_field('section_heading');
                                    $image = get_sub_field('principal_photo');
                                    if (!empty($image)) : ?>
                        <h3 class="common_heading sec_title_60">
                            <?php echo $section_heading; ?>
                        </h3>

                        <img src="<?php echo esc_url($image['url']); ?>" alt="principal" />
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-8">
                    <?php $message_desc = get_sub_field('message'); ?>
                    <div class="principal_right">

                        <?php echo $message_desc; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <img src="/wp-content/uploads/2023/05/princi_shape_01.png" class="s_left" alt="">
    <img src="/wp-content/uploads/2023/05/princi_shape_02.png" class="s_right" alt="">
    <img src="/wp-content/uploads/2023/05/princi_shape_03.png" class="s_middle" alt="">
</section>
<!-- Section 04 Principal -->

<!-- section 05 animated_links -->
<?php
        // Our Mission section  layout.
        elseif (get_row_layout() == 'animation_section') :
        ?>
<section class="animated_links greyYellow">
    <div class="container">
        <?php
                    // check if the nested repeater field has rows of data
                    if (have_rows('animations')) :
                    ?>
        <div class="row">
            <?php
                            while (have_rows('animations')) : the_row();
                                $animation_heading = get_sub_field('heading');
                                $link = get_sub_field('button');
                                if ($link) :
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];

                            ?>
            <div class="col-lg-12">
                <div class="tm-anim-wrap-v2 max_600 col-50">
                    <div class="box lightgrey">
                        <a class="btn fs60" href="<?php echo esc_url($link_url); ?>"
                            target="<?php echo esc_attr($link_target); ?>"><span><?php echo esc_html($link_title); ?></span><?php echo $animation_heading; ?></a>
                        <?php endif; ?>
                        <div class="shapes">
                            <span class="shape hexagon"></span>
                            <span class="shape square"></span>
                            <span class="shape rectangle"></span>
                            <span class="shape rectangle2"></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>

        </div>
        <?php
                    endif;
                    ?>
    </div>
</section>
<!-- section 05 animated_links -->


<!-- Section 06 Accordian -->
<?php
        // Welcome section  layout.
        elseif (get_row_layout() == 'accordion_section') :
        ?>
        <section class="accordian_wrapper new_about bg_grey scroll_margin_top" id="about_accordion">
            <div class="container">
                <?php
                    // check if the nested repeater field has rows of data
                    if (have_rows('accordions')) :
                    ?>
                    
                 <?php
                    $count  = 0;
                    while (have_rows('accordions')) : the_row();
                        $accordion_heading = get_sub_field('accordion_heading');
                        $accordion_content = get_sub_field('accordion_content');
                        $accordion_id = get_sub_field('accordion_id');
                ?>    
                <div class="row">
                    <div class="col-12">
                        <div class="accordion-item">
                            <div class="accordion-item-header <?php //$count++; if($count == 1) { echo ' active'; } ?>" id="<?php echo $accordion_id;?>">
                
                              <?php echo $accordion_heading; ?>                   
                            </div><!-- /.accordion-item-header -->
                            <div class="accordion-item-body">
                                <?php echo $accordion_content; ?>
                                
                            </div><!-- /.accordion-item-body -->
                        </div>
                    </div>
                </div>
                <?php endwhile; 
                
                 endif;?>

            </div>
    </div>
</section>
<!-- Section 06 Accordian -->
<?php elseif (get_row_layout() == 'testimonial_section') : ?>
<!-- 07 Section testimonials start-->
<section class="testimonials_grid bg_white">
    <?php get_template_part('template-parts/sections/grid_testimonial'); ?>
</section>
<!-- 07 Section testimonials end-->

<?php elseif (get_row_layout() == 'join_us_section') : ?>
<!-- section 08 join us  -->
<section class="join_us">
    <?php get_template_part('template-parts/sections/join_us'); ?>
</section>
<!-- section 08 join us  -->

<?php elseif (get_row_layout() == 'apply_now_section') : ?>
<!-- section 09 Questions start-->
<section class="questions_sec">
    <?php get_template_part('template-parts/sections/apply_now'); ?>
</section>
<?php elseif (get_row_layout() == 'image_grid') : ?>
<section class="image_gallary d-none">
    <?php get_template_part('template-parts/sections/image_gallary'); ?>
</section>
<!-- section 09 Questions end-->


<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template 
?>