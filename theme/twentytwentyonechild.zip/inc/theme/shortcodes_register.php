<?php
function growth_chart_fun($atts)
{
    $attributes = shortcode_atts(array(
        'limit' => 1
    ), $atts);

    ob_start();

    // include template with the arguments for PARENT THEME 👇
    // get_stylesheet_directory('/inc/shortcodes/growth_chart', null, array('attributes' => $attributes));

    // Pass attributes to the template for CHILD THEME 👇
    $template_path = locate_template('inc/shortcodes/growth_chart.php');

    if ($template_path) {
        // Makes $attributes available inside the included file
        $attributes = $attributes;
        include $template_path;
    } else {
        echo 'Growth chart template not found.';
    }


    return ob_get_clean();
}
add_shortcode('growth_chart', 'growth_chart_fun');

// Percentage Chart
function percentage_chart_fun($atts)
{
    $attributes = shortcode_atts(array(), $atts);

    ob_start();

    // include template with the arguments for PARENT THEME 👇
    // get_stylesheet_directory('/inc/shortcodes/percentage_chart', null, array('attributes' => $attributes));

    // Pass attributes to the template for CHILD THEME 👇
    $template_path = locate_template('inc/shortcodes/percentage_chart.php');

    if ($template_path) {
        // Makes $attributes available inside the included file
        $attributes = $attributes;
        include $template_path;
    } else {
        echo 'Growth chart template not found.';
    }


    return ob_get_clean();
}
add_shortcode('percentage_chart', 'percentage_chart_fun');