<?php 
$blocks = get_sub_field('blocks');
?>
<section class="faq_accordion_sec pb_100">
    <div class="container">
        <?php if($blocks): ?>
        <div class="accordion_wrap">
            <div class="accordion" id="accordionExample">
                <?php foreach($blocks as $index => $block): 
                    $question = $block['question'];
                    $answer = $block['answer'];
                    ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading-<?php echo $index; ?>">
                        <button class="accordion-button <?php if($index != 0){ echo 'collapsed'; } ?>" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse-<?php echo $index; ?>" aria-expanded="true" aria-controls="collapse-<?php echo $index; ?>">
                            <?php echo $question; ?>
                        </button>
                    </h2>
                    <div id="collapse-<?php echo $index; ?>" class="accordion-collapse collapse <?php if($index == 0){ echo 'show'; } ?>" aria-labelledby="heading-<?php echo $index ;?>"
                        data-bs-parent="#accordionExample">
                        <div class="accordion-body content_editor_default">
                        <?php echo $answer; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>