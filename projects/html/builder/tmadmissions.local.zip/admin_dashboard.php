<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header("Location: login");  // ya aapka login page ka URL
    exit;
}

// Agar yahan tak pahucha toh matlab login hai
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>
    2025 Admissions Open Now | Apply Online | Distance Learning
  </title>
  <link rel="icon" type="image/x-icon" href="./assets/images/favicon.ico" />

  <!-- bootstrap 5 -->
  <link rel="stylesheet" href="./assets/bootstrap-5.2.3-dist/css/bootstrap.min.css" />

  <!-- heebo font -->
  <link rel="stylesheet" href="./assets/fonts/heebo/stylesheet.css" />
  <!-- roboto font -->
  <link rel="stylesheet" href="./assets/fonts/roboto/stylesheet.css" />

  <!-- splitting -->
  <link rel="stylesheet" href="https://unpkg.com/splitting/dist/splitting.css" />
  <link rel="stylesheet" href="https://unpkg.com/splitting/dist/splitting-cells.css" />

  <!-- aos animation -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- Grapes css -->
  <link rel="stylesheet" href="https://unpkg.com/grapesjs/dist/css/grapes.min.css" />

  <!-- Font awesome css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <!-- custom style -->
  <link rel="stylesheet" href="./assets/css/custom_style.css" />
</head>

<body>

<div class="preloader">
  <img src="./assets/images/loader.gif" alt="">
</div>

  <div id="gjs">
    <!-- Header -->
    <header>
      <div class="topbar">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p>
                <span class="text">Call us for more information: </span>
                <a href="tel:+917973805497">+91 7973805497</a>
              </p>
            </div>
            <div class="col-md-6 right">
              <p>
                <span class="text">Visit us on: </span>
                <a href="https://www.facebook.com/techmindservices" target="_blank">
                  <img src="./assets/images/facebook.png" alt="facebook" />
                </a>
                <a href="https://www.instagram.com/techmindservices/" target="_blank">
                  <img src="./assets/images/instagram.png" alt="instagram" />
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="main">
        <div class="container">
          <div class="inner">
            <a href="/" class="logo">
              <img src="./assets/images/logo.png" alt="Techmind" />
            </a>
            <button class="toggle-menu"></button>
            <nav>
              <ul>
                <li>
                  <a href="#about">About Us</a>
                </li>
                <li>
                  <a href="#recognition">Recognition</a>
                </li>
                <li>
                  <a href="#courses">Courses offered</a>
                </li>
                <li>
                  <a href="#stay_connected">Stay connected</a>
                </li>
                <li>
                  <a href="#apply_now" class="tm_btn apply_now">Apply now <span class="layer"></span> <i
                      class="icon"><img src="./assets/images/chevron.png" alt="right arrow"></i> </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>

    <!-- Banner-->
    <section class="banner" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="700">
      <div class="section_inner">
        <div class="container">
          <div class="text_wrap">
            <h1 class="text-white fs_60" data-splitting>
              Start your learning <br />
            </h1>
            <h3 class="text_yellow fs_60 mb_20" data-splitting>journey from anywhere</span></h3>
            <p class="fs_24 mb_20" data-splitting>Build a Better Future from Wherever You Are</p>
            <a href="#apply_now" class="tm_btn apply_now">Apply now <i
                class="icon"><img src="./assets/images/chevron.png" alt="right arrow"></i> </a>
          </div>
        </div>
      </div>
    </section>

    <!-- About -->
    <section class="about_sec pt_80 pb_100" id="about" data-aos="fade-up">
      <div class="container">
        <div class="sec_heading text-center">
          <h2 class="fs_42">ABOUT US</h2>
          <p class="fs_20 mt_20">Empowering Learners Through Flexible Distance Education</p>
        </div>
        <div class="about_content">
          <div class="img_wrap" data-aos="fade-right">
            <img src="./assets/images/students.png" alt="students">
          </div>
          <div class="text_box">
            <div class="inner" data-aos="fade-left">
              <h3 class="fs_38 mb_20">Transform Your Life with Distance Education</h3>
              <p class="fs_18">Distance Education is a modern solution for those who seek quality
                education without the
                limitations of
                time or location. Designed for working professionals, homemakers, and students who need flexibility,
                distance learning allows you to study at your own pace — from the comfort of your home.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- UGC & Government Recognition -->
    <section class="recognition_sec pt_100 pb_100" id="recognition">
      <div class="container">
        <div class="sec_heading text-center" data-aos="fade-up">
          <h2 class="fs_42">UGC & GOVERNMENT RECOGNITION</h2>
        </div>
        <div class="recognition_content">
          <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
            <div class="col" data-aos="fade-up" data-aos-delay="0">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/nirf.png" alt="nirf">
                </div>
                <div class="text_box">
                  <p class="fs_18">Partner universities are ranked under the National Institutional Ranking Framework
                    (NIRF) — a
                    reliable benchmark of academic excellence in India.</p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="250">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/Times_Higher_Education_logo.svg.png" alt="Times_Higher_Education_logo">
                </div>
                <div class="text_box">
                  <p class="fs_18">Our associated institutions have been featured in Times Higher Education rankings,
                    demonstrating
                    their commitment to global academic standards and innovation.</p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="500">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/AICTE.png" alt="AICTE">
                </div>
                <div class="text_box">
                  <p class="fs_18">Technical programs like MBA and MCA are AICTE-approved, making them fully compliant
                    with national
                    educational regulations.</p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="750">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/naac.png" alt="naac">
                </div>
                <div class="text_box">
                  <p class="fs_18">Our partner universities are accredited with NAAC A++ Grade — the highest rating
                    awarded by the
                    National Assessment and Accreditation Council, a mark of academic excellence.</p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1000">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/UGC_India.png" alt="UGC_India">
                </div>
                <div class="text_box">
                  <p class="fs_18">The University Grants Commission (UGC) is the statutory body of the Government of
                    India
                    responsible
                    for coordinating, determining, and maintaining the standards of higher education.</p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1250">
              <div class="recognition_box text-center">
                <div class="img_wrap mb_20">
                  <img src="./assets/images/wes.png" alt="wes">
                </div>
                <div class="text_box">
                  <p class="fs_18">IT is a leading credential evaluation agency that assesses international education
                    qualifications for
                    their equivalence in countries like Canada and the US.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Courses Offered -->
    <section class="courses_sec pt_100 pb_100" id="courses">
      <div class="container">
        <div class="sec_heading text-center" data-aos="fade-up">
          <h3 class="fs_42">COURSES OFFERED</h3>
        </div>
        <div class="courses_content">
          <div class="row justify-content-center row-cols-1 row-cols-md-2 row-cols-lg-4">
            <div class="col" data-aos="fade-up" data-aos-delay="0">
              <div class="course_wrap text-center" data-course="BA">
                <div class="text_box">
                  <h4 class="fs_24">B.A</h4>
                  <p>Bachelor of Arts</p>
                  <p><small>Duration: 3 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="250">
              <div class="course_wrap text-center" data-course="MA">
                <div class="text_box">
                  <h4 class="fs_24">M.A</h4>
                  <p>Master of Arts</p>
                  <p><small>Duration: 2 Years</small></p>
                </div>
              </div>

            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="500">
              <div class="course_wrap text-center" data-course="B.Com">
                <div class="text_box">
                  <h4 class="fs_24">B.Com</h4>
                  <p>Bachelor of Commerce</p>
                  <p><small>Duration: 3 Years</small></p>
                </div>
              </div>


            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="750">
              <div class="course_wrap text-center" data-course="M.Com">
                <div class="text_box">
                  <h4 class="fs_24">M.Com</h4>
                  <p>Master of Commerce</p>
                  <p><small>Duration: 2 Years</small></p>
                </div>
              </div>

            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1000">
              <div class="course_wrap text-center" data-course="BCA">
                <div class="text_box">
                  <h4 class="fs_24">Bca</h4>
                  <p>Bachelor of Computer
                    Applications</p>
                  <p><small>Duration: 3 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1250">
              <div class="course_wrap text-center" data-course="MCA">
                <div class="text_box">
                  <h4 class="fs_24">Mca</h4>
                  <p>Master of Computer
                    Applications</p>
                  <p><small>Duration: 2 Years</small></p>
                </div>
              </div>

            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1500">
              <div class="course_wrap text-center" data-course="BBA">
                <div class="text_box">
                  <h4 class="fs_24">BBA</h4>
                  <p>Bachelor of Business
                    Administration</p>
                  <p><small>Duration: 3 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1750">

              <div class="course_wrap text-center" data-course="MBA">
                <div class="text_box">
                  <h4 class="fs_24">MBA</h4>
                  <p>Master of Business
                    Administration</p>
                  <p><small>Duration: 2 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="2000">
              <div class="course_wrap text-center" data-course="B.Sc (IT)">
                <div class="text_box">
                  <h4 class="fs_24">B.SC (IT)</h4>
                  <p> Bachelor of Science in Information Technology</p>
                  <p><small>Duration: 3 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="2250">
              <div class="course_wrap text-center" data-course="M.Sc (IT)">
                <div class="text_box">
                  <h4 class="fs_24">M.Sc (IT)</h4>
                  <p>Master of Science in Information Technology</p>
                  <p><small>Duration: 2 Years</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="2500">
              <div class="course_wrap text-center" data-course="DCA">
                <div class="text_box">
                  <h4 class="fs_24">DCA</h4>
                  <p>Diploma in Computer Applications</p>
                  <p><small>Duration: 1 Year</small></p>
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="2750">
              <div class="course_wrap text-center" data-course="DBA">
                <div class="text_box">
                  <h4 class="fs_24">DBA</h4>
                  <p>Diploma in Business Administration</p>
                  <p><small>Duration: 1 Year</small></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Apply now -->
    <section class="apply_now_sec pt_120 pb_120" id="apply_now" data-aos="fade-zoom-in" data-aos-duration="4000">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-xl-6">
            <div class="form_wrap" data-aos="fade-up">
              <h3 class="fs_42 text-white">START YOUR JOURNEY</h3>
              <!-- <h4 class="fs_24 text-white">APPLY NOW</h4> -->
              <form id="admission_form" name="admission_form" method="POST">
                <div class="row">
                  <div class="col-12">
                    <div class="input_wrap">
                      <label for="name">Your Full Name</label>
                      <input type="text" name="name" id="name" placeholder="Enter your full name"
                        class="required_field field_style form-control" />
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="input_wrap">
                      <label for="email">Email Address</label>
                      <input type="email" name="email" id="email" placeholder="Enter your email"
                        class="required_field email field_style form-control" />
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="input_wrap phone_field_parent">
                      <label for="phone_no">Mobile Number</label>
                      <!-- <span class="country_code">+91</span> -->
                      <div class="inner">
                        <div class="country_code_wrap select_wrapper">
                          <select name="country_code" id="country_code" class="country_code" disabled>
                            <option value="+91">+91</option>
                          </select>
                        </div>

                        <input type="tel" name="phone_no" id="phone_no" placeholder="10-digit mobile number"
                          class="required_field phone field_style form-control" />
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="input_wrap">
                      <label for="select_state">Select Your State</label>
                      <div class="select_wrapper">
                        <div class="select_wrapper">
                          <select name="select_state" class="required_field select_state field_style form-select">
                            <option value="">Choose your state</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="input_wrap">
                      <label for="select_dist">Select Your District</label>
                      <div class="select_wrap">
                        <div class="select_wrapper">
                          <select name="select_dist" class="required_field select_dist field_style form-select">
                            <option value="">Choose your district</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="input_wrap">
                      <label for="select_city">Select Your City</label>
                      <div class="select_wrap">
                        <div class="select_wrapper">
                          <select name="select_city" class="required_field select_city field_style form-select">
                            <option value="">Choose your city</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input_wrap">
                      <label for="select_programme">Choose a Programme</label>
                      <div class="select_wrapper">
                        <select name="select_programme" id="select_programme"
                          class="required_field field_style form-select">


                          <option value=""> Choose a programme to apply for</option>

                          <!-- Undergraduate Courses -->
                          <option value="BA">B.A (Bachelor of Arts)</option>
                          <option value="B.Com">B.Com (Bachelor of Commerce)</option>
                          <option value="BCA">BCA (Bachelor of Computer Applications)</option>
                          <option value="BBA">BBA (Bachelor of Business Administration)</option>
                          <option value="B.Sc (IT)">B.Sc (IT) (Bachelor of Science in Information Technology)</option>

                          <!-- Postgraduate Courses -->
                          <option value="MA">M.A (Master of Arts)</option>
                          <option value="M.Com">M.Com (Master of Commerce)</option>
                          <option value="MCA">MCA (Master of Computer Applications)</option>
                          <option value="MBA">MBA (Master of Business Administration)</option>
                          <option value="M.Sc (IT)">M.Sc (IT) (Master of Science in Information Technology)</option>

                          <!-- Diploma Courses -->
                          <option value="DCA">DCA (Diploma in Computer Applications)</option>
                          <option value="DBA">DBA (Diploma in Business Administration)</option>

                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input_wrap select_specialization_parent" style="display: none">
                      <label for="select_specialization">Choose a Specialization</label>
                      <div class="select_wrapper">
                        <select name="select_specialization" id="select_specialization" class="field_style form-select">
                          <option value=""> Select your area of interest</option>

                          <option value=" Select specialization">
                            Select specialization
                          </option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input_wrap check-radio-wrap required_field mb-0">
                      <label for="checkbox_field">
                        <input type="checkbox" name="checkbox_field" id="checkbox_field" />
                        I agree to receive information regarding my submitted application by signing up with Distance
                        education via Email, SMS and WhatsApp.*
                      </label>
                    </div>
                  </div>

                  <!-- capture utm_hidden_fields start-->

                  <div class="utm_hidden_fields input_wrap d-none">
                    <input type="hidden" name="utm_source" />

                    <input type="hidden" name="utm_medium" />

                    <input type="hidden" name="utm_campaignid" />

                    <input type="hidden" name="utm_adgroupid" />

                    <input type="hidden" name="utm_creativeid" />

                    <input type="hidden" name="utm_matchtype" />

                    <input type="hidden" name="utm_device" />

                    <input type="hidden" name="utm_network" />

                    <input type="hidden" name="utm_keyword" />

                    <input type="hidden" name="utm_keywordid" />

                    <input type="hidden" name="utm_campaign" />

                    <input type="hidden" name="gad_source" />

                    <input type="hidden" name="gbraid" />

                    <input type="hidden" name="gclid" />

                    <input type="hidden" name="page_type" value="" class="page_type" />
                  </div>

                  <!-- capture utm_hidden_fields end-->

                  <div class="col-12">
                    <!-- recaptcha -->
                    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                    <div class="g-recaptcha" data-sitekey="6LfgS1UrAAAAAIBQDJcTL7capvloHscKDpkjwKfd"></div>
                  </div>

                  <div class="col-12">
                    <div class="submit_wrap">
                      <input type="submit" value="APPLY NOW" class="cmn_btn tm_btn" />
                      <div class="loader" style="display: none"></div>
                    </div>
                  </div>

                  <div class="alert alert-success mt-4 success_msg" role="alert" style="display: none">Thank you! Your
                    details have been successfully submitted. We'll be in touch with you soon.</div>
                  <div class="alert alert-danger mt-4 error_msg" role="alert" style="display: none">Something went
                    wrong.
                    Please try again later.</div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Stay Connected -->
    <section class="stay_connected_sec pt_100 pb_100" id="stay_connected">
      <div class="container">
        <div class="sec_heading text-center" data-aos="fade-up">
          <h3 class="fs_42">STAY CONNECTED WITH US ON FACEBOOK!</h3>
        </div>
        <div class="stay_connected_content">
          <div class="row justify-content-center row-cols-1 row-cols-md-2 row-cols-lg-3">
            <div class="col" data-aos="fade-up" data-aos-delay="0">
              <div class="post_wrap text-center" data-course="BCA">
                <div class="img_wrap">
                  <img src="./assets/images/post1.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="250">
              <div class="post_wrap text-center" data-course="B.Com">
                <div class="img_wrap">
                  <img src="./assets/images/post2.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="500">
              <div class="post_wrap text-center" data-course="BBA">
                <div class="img_wrap">
                  <img src="./assets/images/post3.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="750">
              <div class="post_wrap text-center" data-course="BA">
                <div class="img_wrap">
                  <img src="./assets/images/post4.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1000">
              <div class="post_wrap text-center" data-course="BA">
                <div class="img_wrap">
                  <img src="./assets/images/post5.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="1250">
              <div class="post_wrap text-center" data-course="MBA">
                <div class="img_wrap">
                  <img src="./assets/images/post6.png" alt="Post" class="w-100">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- footer -->
    <footer>
      <div class="container">
        <div class="footer_content text-center">
          <a class="footer_logo mb_20" href="/">
            <img src="./assets/images/logo_white.png" alt="Techmind">
          </a>
          <p class="mb_20">To become a leading platform in distance learning by making education affordable, accessible,
            and adaptable
            to the needs of today’s learners.</p>
          <ul class="sci mb_20">
            <li>
              <a href="https://www.facebook.com/techmindservices" target="_blank">
                <img src="./assets/images/facebook.png" alt="facebook">
              </a>
            </li>
            <li>
              <a href="https://www.instagram.com/techmindservices/" target="_blank">
                <img src="./assets/images/instagram.png" alt="instagram">
              </a>
            </li>
            <li>
              <a href="tel:+917973805497">
                <img src="./assets/images/call.png" alt="call">
              </a>
            </li>
          </ul>
          <p class="mb_20">Copyrights © 2025 Techmind Services. Designed and Developed by <a
              href="https://techmind.co.in/" target="_blank">Techmind
              Softwares</a>.</p>
        </div>
      </div>
    </footer>
  </div>


  <!-- jQuery 3.7.1 -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

  <!-- tilt js -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js"></script>

  <!-- split text script -->
  <script src="https://unpkg.com/splitting/dist/splitting.min.js"></script>

  <!-- aos script -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

  <!-- grapes js -->
  <script src="https://unpkg.com/grapesjs"></script>
  <!-- grapes js blocks -->
  <script src="https://unpkg.com/grapesjs-blocks-basic"></script>

  <!-- custom script -->
  <script src="./assets/js/custom_script.js"></script>

  <!-- grapes js builder init js -->
  <script src="./assets/js/grapes_init.js"></script>

</body>

</html>