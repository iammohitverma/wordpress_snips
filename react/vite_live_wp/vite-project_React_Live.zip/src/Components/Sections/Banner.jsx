import React from "react";

function Banner({ data }) {
  const sectionData = data || {};
  const bg = "/placeholder_1080_675.jpg";
  const {
    banner_image = bg,
    heading = "Default Heading",
    description = "Default Description",
  } = sectionData;

  return (
    <>
      <section
        className="banner"
        style={{
          backgroundImage: `url(${banner_image.url ? banner_image.url : bg})`,
        }}
      >
        <div className="container my-5">
          <div className="p-5 text-center bg-body-tertiary rounded-3">
            <h1 className="text-body-emphasis mb-4">{heading}</h1>
            <p className="col-lg-8 mx-auto fs-5 mb-0  text-muted">
              {description}
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
export default Banner;
