<?php
get_header();
?>


<section class="py_100 mb_events">
    <div class="container">
        <div class="sec_heading text-center">
            <h2><?php echo the_title();?></h2>
            <h3>Event Images</h3>
        </div>
        <div class="gallery_wrap" id="gallary_container">
            <?php
            $gallery = get_field('events_images');
            if( $gallery ): 
                foreach( $gallery as $image ): ?>
                    <a href="<?php echo esc_url($image['url']); ?>" class="gallery_image"
                        data-src="<?php echo esc_url($image['url']); ?>" data-sub-html="<?php echo esc_attr($image['caption']); ?>">
                        <img src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="cover">
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php get_footer();?>