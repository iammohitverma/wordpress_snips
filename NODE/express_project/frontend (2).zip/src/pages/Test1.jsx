import React, { useEffect, useState } from 'react'
import Comm1 from '../components/Test1/Comm1'
import { AiOutlineFire } from "react-icons/ai";
import { Link, useNavigate } from 'react-router-dom';
import axiosinstance from '../api/axiosinstance';

const Test1 = () => {
    const IconUser = ({ className }) => (
        <svg
            className={className}
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            viewBox="0 0 24 24"
        >
            <circle cx="12" cy="7" r="4" />
            <path d="M5.5 21a8.38 8.38 0 0 1 13 0" />
        </svg>
    );
    const IconLogout = ({ className }) => (
        <svg
            className={className}
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            viewBox="0 0 24 24"
        >
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
        </svg>
    );

    const IconUpgrade = ({ className }) => (
        <svg
            className={className}
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            viewBox="0 0 24 24"
        >
            <path d="M12 19v-6m0 0V5m0 8H9m3 0h3" />
        </svg>
    );

    const [tests, setTests] = useState({
        inProgress: 0,
        readyToBurn: 0,
        completed: 0,
        totalQuota: 1,
        usedQuota: 0,
    });
    const [user, setUser] = useState({});
    const email = localStorage.getItem('email');
    const navigate = useNavigate();

    useEffect(() => {
        if (!email) {
            navigate('/');
            return;
        }

        const fetchUser = async () => {
            try {
                const res = await axiosinstance.get('/api/auth/me', {
                    params: { email }
                });
                setUser(res.data);
                console.log(res.data)
            } catch (err) {
                console.error(err.response?.data?.message);
                navigate('/');
            }
        };

        fetchUser();
    }, [email, navigate]);

    const LogOutHandler = async (e) => {
        e.preventDefault();
        localStorage.removeItem('email');
        navigate('/');
    }

    return (
        <div>
            <header className="bg-white border-b border-amber-300 shadow-sm sticky top-0 z-50">
                <nav className="container mx-auto px-4 flex items-center justify-between h-16">
                    <div className="flex flex-col items-center space-x-2">
                        <div className="flex items-center text-amber-800">
                            {/* Flame icon with gradient */}
                            <AiOutlineFire />
                            <span className="font-extrabold text-lg select-none ml-1">
                                Candle Burn-Test Log
                            </span>
                        </div>
                        <span className="text-xs text-amber-600 select-none font-light">
                            Professional candle testing made simple
                        </span>
                    </div>

                    <div className="flex items-center space-x-4 text-xs">
                        <div className="hidden md:flex items-center space-x-2 bg-amber-100 border border-amber-300 rounded-full py-1 px-3 cursor-default select-none">
                            <span className="uppercase text-amber-600 font-semibold tracking-wider">
                                Free
                            </span>
                        </div>
                        <button
                            type="button"
                            aria-label="Upgrade Account"
                            className="flex items-center space-x-1 bg-amber-700 hover:bg-amber-800 transition-colors rounded-full py-1 px-3 text-white font-medium"
                        >
                            <IconUpgrade className="w-4 h-4" />
                            <span>Upgrade</span>
                        </button>
                        <div className="hidden md:flex items-center text-amber-800 font-semibold">
                            <span>
                                {tests.usedQuota}/{tests.totalQuota} tests
                            </span>
                        </div>
                        <button
                            type="button"
                            aria-label="User Profile"
                            className="flex items-center space-x-1 text-amber-700 hover:text-amber-900 transition-colors"
                        >
                            <IconUser className="w-5 h-5" />
                            <span className="hidden md:inline-block">{user.name}</span>
                        </button>
                        <button
                            type="button"
                            onClick={LogOutHandler}
                            aria-label="Logout"
                            className="text-amber-600 hover:text-amber-800 transition-colors"
                            title="Logout"
                        >
                            <IconLogout className="w-5 h-5" />
                        </button>
                    </div>
                </nav>

                <div className="bg-white border-t border-amber-300 shadow-sm">
                    <nav className="container mx-auto px-4 flex text-sm font-semibold text-amber-800 leading-none select-none overflow-x-auto">
                        <Link to={"/home"} className="px-4 py-3 border-b-4 border-transparent hover:border-amber-400 whitespace-nowrap">
                            Dashboard
                        </Link>
                        <Link to={"/logs"} className="px-4 py-3 border-b-4 border-transparent hover:border-amber-400 whitespace-nowrap">
                            My Logs
                        </Link>
                        <Link to={"/upgrade"} className="px-4 py-3 border-b-4 border-transparent hover:border-amber-400 whitespace-nowrap">
                            Upgrade
                        </Link>
                    </nav>
                </div>
            </header>
            <Comm1 />
        </div>
    )
}

export default Test1
