import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function About() {
  const {
    data: acfData,
    isLoading,
    isError,
    error,
  } = useFetchAcfData(22, "about");

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <HelmetConfig
        title={"About Page - My Website"}
        description={"This is the About page of my website."}
      />

      {acfData &&
        acfData.map((block, index) => {
          switch (block.acf_fc_layout) {
            case "banner":
              return <Banner key={index} data={block} />;
            default:
              return null;
          }
        })}
    </>
  );
}
export default About;
