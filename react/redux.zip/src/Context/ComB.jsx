import ComC from "./ComC";
function ComB() {
  return <ComC />;
}
export default ComB;
