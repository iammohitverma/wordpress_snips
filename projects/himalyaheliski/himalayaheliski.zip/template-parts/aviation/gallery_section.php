<section class="common_gallery pb_100">
    <div class="container">
        <div class="gallery_wrap" id="gallary_container">
            <?php
            $gallery = get_sub_field('gallery');
            if( $gallery ): 
                foreach( $gallery as $image ): ?>
                    <a href="<?php echo esc_url($image['url']); ?>" class="img_card"
                        data-src="<?php echo esc_url($image['url']); ?>" data-sub-html="<?php echo esc_attr($image['alt']); ?>">
                        <img src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
