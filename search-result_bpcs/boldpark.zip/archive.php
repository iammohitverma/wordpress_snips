
<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package boldpark-theme
 */

get_header();
?>

<div class="" id="single-post">
	<h4 style="text-align:center">Archive Post Page</h4>
	<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/archive/archive', get_post_type() );
		endwhile; // End of the loop.
	?>
</div>
<?php get_footer();?>