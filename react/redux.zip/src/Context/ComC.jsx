import { useContext } from "react";
import { MyContext } from "./MyContext";
const ComC = () => {
  const data = useContext(MyContext);
  const viewContext = () => {
    console.log(data);
  };
  return (
    <>
      <button onClick={() => viewContext()}>Click me</button>
    </>
  );
};
export default ComC;
