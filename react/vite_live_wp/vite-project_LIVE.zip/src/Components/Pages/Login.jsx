import HelmetConfig from "../Config/HelmetConfig";
import Banner from "../Sections/Banner";
import LoginForm from "../Sections/LoginForm";
import useFetchAcfData from "../../Hooks/useFetchAcfData";
import Loader from "../Sections/Loader";

function Login({ setIsLogin, setLoggedInUserName }) {
  const {
    data: acfData,
    isLoading,
    isError,
    error,
  } = useFetchAcfData(180, "login");

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <HelmetConfig
        title={"Login Page - My Website"}
        description={"This is the Login page of my website."}
      />

      {acfData &&
        acfData.map((block, index) => {
          switch (block.acf_fc_layout) {
            case "banner":
              return <Banner key={index} data={block} />;
            case "login_form":
              return (
                <LoginForm
                  key={index}
                  data={block}
                  setIsLogin={setIsLogin}
                  setLoggedInUserName={setLoggedInUserName}
                />
              );
            default:
              return null;
          }
        })}
    </>
  );
}
export default Login;
