import "./App.css";
import { SignatureTemplate } from "./Components/SignatureTemplate";

function App() {
  return (
    <div className="App">
      <SignatureTemplate />
    </div>
  );
}

export default App;
