<?php 
/*
Template Name: Our Difference new
*/
get_header(); // Load the header template

global $wp_query;
if( have_rows('our_difference_sections') ):
    while ( have_rows('our_difference_sections') ) : the_row();

    if( get_row_layout() == 'banner_section' ):
?>
<!-- Common banner secion inner pages  -->
<section class="our_difference_section bg_grey">
    <div class="banner_main">
        <?php  get_template_part( 'template-parts/sections/banner_inner_pages' ); ?>
    </div>
</section>
<!-- Common banner secion inner pages  -->

<!-- 02 Section about difference Start-->
<?php elseif( get_row_layout() == 'video_section' ):

$section_heading = get_sub_field('section_heading');
$heading = get_sub_field('heading');
$description = get_sub_field('description');
?>
<section class="about_oD pt_extra">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner">
                    <h2 class="hdng">
                        <?php echo $section_heading; ?>
                    </h2>
                    <h3 class="sub_hdng">
                        <?php echo $heading;?>
                    </h3>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner editor">
                    <p>
                        <?php echo $description; ?>
                    </p>
                </div>
            </div>  
        </div>
    </div>
</section>

<!-- 02 Section about difference end-->

<!-- Section 03 Video Section -->
<section class="single-video-sec">
<?php  get_template_part( 'template-parts/sections/videos_section' );  ?>
</section>
<!-- Section 03 Video Section -->

<?php elseif( get_row_layout() == 'accordion_section' ):
    $acc_section_heading = get_sub_field('section_heading');
?>
<!-- Section 04 Accordian -->
<section class="accordian_wrapper bg_grey">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="hdng">
                    <?php echo $acc_section_heading; ?>
                </h3>
                <div class="cmn_hr"></div>
            </div>
        </div>
        <?php get_template_part( 'template-parts/sections/accordion' ); ?>
    </div>
</section>
<!-- Section 04 Accordian -->
<?php elseif( get_row_layout() == 'our_difference_section' ):
    $diff_section_heading = get_sub_field('section_heading');
?>
<!-- Section 05 hover expand items -->
<section class="ourDifferenceItems">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="hdng">
                    <?php echo $diff_section_heading; ?>
                </h3>
            </div>
        </div>
    </div>
    <div class="items">
    <?php if( have_rows('blocks') ): ?>
        <ul>
            <?php while( have_rows('blocks') ) : the_row(); 
            $blocks_heading = get_sub_field('blocks_heading');
            $blocks_link = get_sub_field('blocks_link');
            ?>
            <li>
                <div>
                    <h4 class="itemHdng">
                        <?php echo $blocks_heading; ?>
                    </h4>
                    <a href="<?php echo $blocks_link['url']; ?>" class="arrow_btn">
                    <?php echo $blocks_link['title']; ?>
                        <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                        </svg>
                    </a>
                </div>
            </li>
            <?php endwhile; ?>
        </ul>
        <?php endif; ?>
    </div>
</section>
<!-- Section 05 hover expand items -->
<?php elseif( get_row_layout() == 'join_us_section' ):
?>
<section class="join_us">
<?php get_template_part( 'template-parts/sections/join_us' ); ?>
</section>

<?php elseif( get_row_layout() == 'apply_now_section' ): ?>
<!-- Questions start-->
<section class="questions_sec">
<?php get_template_part( 'template-parts/sections/apply_now' ); ?>
</section>
<!-- Questions end-->

<?php get_footer(); // Load the footer template
endif;
endwhile;
endif;
?>