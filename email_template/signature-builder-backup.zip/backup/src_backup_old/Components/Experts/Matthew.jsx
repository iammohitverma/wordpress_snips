export const Matthew = () => {
  return (
    <>
      <table width="600" align="start" cellSpacing="0" cellPadding="0">
        <tbody>
          <tr>
            <td
              style={{
                backgroundImage:
                  "url('https://apps.okmg.com/client_signatures/cpa-signature/static/images/email_shape_600_400_2.png')",
                backgroundRepeat: "no-repeat",
                backgroundPosition: "left 90%",
                backgroundSize: "cover",
                width: "100%",
              }}
            >
              <table width="100%" align="start" cellSpacing="0" cellPadding="0">
                <tbody>
                  <tr>
                    <td>
                      <table
                        align="start"
                        width="600"
                        style={{
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "400px",
                                verticalAlign: "top",
                                padding: "50px 30px",
                              }}
                            >
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "22px",
                                  fontWeight: "600",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "1px",
                                }}
                              >
                                Matthew Hughes
                              </p>
                              <div
                                style={{
                                  marginBottom: "7px",
                                }}
                              ></div>
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                  marginBottom: "3px",
                                }}
                              >
                                Managing Director &
                              </p>
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                }}
                              >
                                Senior Buyer's Agent
                              </p>
                            </td>
                            <td
                              style={{
                                width: "200px",
                                textAlign: "right",
                                padding: "20px 30px",
                              }}
                            >
                              <img
                                src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/matthew_100.png"
                                alt=""
                                style={{
                                  width: "120px",
                                  height: "120px",
                                }}
                              />
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "300px",
                                verticalAlign: "top",
                                padding: "10px 0 0 30px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td>
                                      <p>
                                        <a
                                          href="tel: 0437 777 377"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/mobile.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          0437 777 377
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="tel: 08 9323 0000"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            textTransform: "uppercase",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/telephone.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          08 9323 0000
                                        </a>
                                      </p>

                                      <p>
                                        <a
                                          href="mailto: matthew@cpadvisory.com.au"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                            wordBreak: "break-all",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/email.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          matthew@cpadvisory.com.au
                                        </a>
                                      </p>
                                      <p>
                                        <a
                                          href="https://cpadvisory.com.au/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "600",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            marginBottom: "3px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            paddingTop: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/globe.png"
                                            alt=""
                                            style={{
                                              width: "27px",
                                              height: "17px",
                                              objectFit: "contain",
                                              marginRight: "5px",
                                            }}
                                          />
                                          cpadvisory.com.au
                                        </a>
                                      </p>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td
                              style={{
                                width: "300px",
                                textAlign: "right",
                                paddingRight: "30px",
                              }}
                            >
                              <a
                                href="https://www.cpadvisory.com.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  paddingTop: "0px",
                                }}
                              >
                                <img
                                  src="https://www.cpadvisory.com.au/tmp/images/capital_logo.jpg"
                                  alt=""
                                  style={{
                                    width: "160px",
                                  }}
                                />
                              </a>
                              <p
                                style={{
                                  fontFamily: "Rozha One, serif",
                                  fontSize: "15px",
                                  fontWeight: "400",
                                  color: "#ec6563",
                                  textTransform: "uppercase",
                                  letterSpacing: "1px",
                                  marginBottom: "3px",
                                  textDecoration: "none",
                                  display: "inline-block",
                                  borderTop: "20px solid #fff",
                                  lineHeight: 1.3,
                                }}
                              >
                                YOUR TRUSTED PARTNER <br /> IN PROPERTY
                              </p>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "200px",
                                // verticalAlign: "middle",
                                padding: "30px",
                                paddingRight: "0",
                                paddingTop: "20px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td>
                                      <p>
                                        <span
                                          style={{
                                            fontFamily: "Roboto, sans-serif",
                                            fontSize: "12px",
                                            fontWeight: "700",
                                            color: "#30526d",
                                            letterSpacing: "1px",
                                            textDecoration: "none",
                                            display: "inline-block",
                                            marginBottom: "3px",
                                            paddingBottom: "10px",
                                            borderBottom: "5px solid #fff",
                                          }}
                                        >
                                          Follow us
                                        </span>
                                        <a
                                          href="https://www.instagram.com/capitalpropertyadvisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginLeft: "5px",
                                            marginRight: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/instagram.png"
                                            alt=""
                                            style={{
                                              width: "40px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                        <a
                                          href="https://www.facebook.com/capitalpropertyadvisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginRight: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/facebook.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                        <a
                                          href="https://au.linkedin.com/company/capital-property-advisory/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          style={{
                                            display: "inline-block",
                                            marginRight: "5px",
                                          }}
                                        >
                                          <img
                                            src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/linkedin.png"
                                            alt=""
                                            style={{
                                              width: "30px",
                                              height: "20px",
                                              objectFit: "contain",
                                            }}
                                          />
                                        </a>
                                      </p>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td
                              style={{
                                width: "360px",
                                textAlign: "right",
                                verticalAlign: "middle",
                                padding: "30px",
                                paddingLeft: "0",
                                paddingTop: "20px",
                              }}
                            >
                              <a
                                href="http://rebaa.com.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/rebaa.jpg"
                                  alt=""
                                  style={{
                                    width: "70px",
                                    height: "30px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/pipa.jpg"
                                  alt=""
                                  style={{
                                    width: "70px",
                                    height: "30px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/qualified-property-investment-adviser-property-investment-adviser/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/qpia.jpg"
                                  alt=""
                                  style={{
                                    width: "70px",
                                    height: "30px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://members.reiwa.com.au/s/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/reiwa.jpg"
                                  alt=""
                                  style={{
                                    width: "70px",
                                    height: "30px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};
