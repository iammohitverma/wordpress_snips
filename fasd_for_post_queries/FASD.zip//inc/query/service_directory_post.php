<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/autoload.php';

$service_name = $_POST['service_name'];
$service_slug = sanitize_title( $_POST['service_name'] );
$contact_person = $_POST['contact_person'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$website_url = $_POST['website_url'];
$primary_address = $_POST['primary_address'];
$sec_address = $_POST['sec_address'];
$state = $_POST['state'];
$postcode = $_POST['postcode'];
$clinic_nature_other = $_POST['clinic_nature_other'];
$health_profession_other = $_POST['health_profession_other'];
$fasd_service = $_POST['fasd_service'];
$service_overview = $_POST['service_overview'];
$billing_structure = $_POST['billing_structure'];
$acceptance = $_POST['acceptance'];

/* Need to store in searlize form start */
$clinic_nature = $_POST['clinic_nature'];
$health_check = $_POST['health_check'];
$informed_services = $_POST['informed_services'];
$referrals_check = $_POST['referrals_check'];
$age_group = $_POST['age_group'];

$clinicData = explode(",", $clinic_nature);
$healthData = explode(",", $health_check);
$informedData = explode(",", $informed_services);
$referralsData = explode(",", $referrals_check);
$ageData = explode(",", $age_group);

$clinicRecords = maybe_serialize($clinicData);
$healthRecords = maybe_serialize($healthData);
$informRecords = serialize($informedData);
$referralRecords = serialize($referralsData);
$ageRecords = serialize($ageData);

/* Need to store in searlize form ends */

$post_data = array (
    'comment_status'    => 'closed',
    'ping_status'       => 'closed',
    'post_author'       => '1',
    'post_name'         => $service_slug,
    'post_title'        => $service_name,
    'post_status'       => 'pending',
    'post_type'         => 'servicedirectory', 
);
$args = array(
   'post_type' => 'servicedirectory',
   'meta_query' => array(
      array(
         'key' => 'email_address',
         'value' => $email,
         'compare' => '=',
      )
   )
);

$my_query = new WP_Query($args);

if ($my_query->have_posts()) {
echo"email exist";
}else{


$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = 'smtp.sendgrid.net';
$mail->SMTPAuth = true;
$mail->Username = 'apikey';
$mail->Password = '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';
$mail->SMTPSecure = "tls"; 
$mail->Port = 587; 
$mail->setfrom('deeksha.sharma@techmind.co.in', 'FASD');
$mail->addAddress($email);

  $mail->Subject = "New Service Added";

$mail->isHTML(true);
$mail->Body = 'Testing mail';
if (!$mail->send())
{
    echo 'Mailer Error: ' . $mail->ErrorInfo;
    echo 'error';
}


$post_ID = wp_insert_post( $post_data );

if ( ! is_wp_error( $post_ID ) ) {
    add_post_meta($post_ID, 'main_contact_person', $contact_person);
    add_post_meta($post_ID, 'email_address', $email);
    add_post_meta($post_ID, 'phone_number', $phone);
    add_post_meta($post_ID, 'website_url', $website_url);
    add_post_meta($post_ID, 'address', $primary_address);
    add_post_meta($post_ID, 'address_2', $sec_address);
    add_post_meta($post_ID, 'state', $state);
    add_post_meta($post_ID, 'postcode', $postcode);
    add_post_meta($post_ID, 'nature_of_clinic_other_please_specify', $clinic_nature_other);
    add_post_meta($post_ID, 'health_professionals_other_please_specify', $health_profession_other);
    add_post_meta($post_ID, 'fasd-informed_services_other_please_specify', $fasd_service);
    add_post_meta($post_ID, 'please_provide_a_short_overview_of_your_clinic_and_the_fasd-informed_services_that_you_provide', $service_overview);
    add_post_meta($post_ID, 'would_you_like_to_subscribe_to_our_mailing_list', $acceptance);
    add_post_meta($post_ID, 'what_is_your_billing_structure', $billing_structure);

    /* Need to store in searlize form start */

    global $wpdb;
  
 $sql = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) VALUES ";

// Array of records to insert
$records = array(
    array('what_is_the_nature_of_your_clinic_service_or_practice', $clinicRecords),
    array('which_health_professionals_are_available_at_your_clinic', $healthRecords),
    array('which_type_of_fasd-informed_services_do_you_provide', $informRecords),
    array('where_do_you_accept_referrals_from', $referralRecords),
    array('which_age_groups_do_you_work_with', $ageRecords)
);

// Loop through the records to build the query
foreach ($records as $record) {
    $meta_key = esc_sql($record[0]);
    $meta_value = esc_sql($record[1]);
    $sql .= "($post_ID, '$meta_key', '$meta_value'),";
}

// Remove the trailing comma
$sql = rtrim($sql, ',');

// Execute the query
print_r($sql);
$wpdb->query($sql);

}


}
?>