<?php 
/*
Template Name: Enrolment/Book a Tour
*/
get_header(); // Load the header template
?>

<?php if( have_rows('book_a__tour__page_section') ): ?>
    <?php while( have_rows('book_a__tour__page_section') ): the_row(); 

if( get_row_layout() == 'banner_section' ):

$book_banner_heading = get_sub_field('banner_heading');
$book_banner_subheading = get_sub_field('banner_subheading');
$book_banner_description = get_sub_field('banner_description');
$banner_img = get_sub_field('banner_image');
?>
<!-- Common banner secion inner pages  -->
<section class="our_difference_newbanner bg_grey">
    <div class="container-fluid px-0">
        <div class="banner_main">
            <div class="banner_content_wrap">
                <div class="row">
                        <div class="col-lg-5 col-md-6 col-sm-12 col-12">
                            <div class="left_main">
                                <div class="left_img"> 
                                <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-6 col-sm-12 col-12">
                            <div class="banner_content_inner">
                                <div class="right_cont">
                                    <h2 class="banner_mainheading sec_title_90"><?php echo $book_banner_heading;?></h2>
                                    <p>
                                    <?php echo $book_banner_subheading;?> 
                                    </p>
                                    <p>
                                        <?php echo $book_banner_description; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php 
elseif( get_row_layout() == 'two_column_sections' ):

$book_heading = get_sub_field('heading');
$book_banner_description = get_sub_field('description');
$book_banner_image = get_sub_field('image');
?>
<section class="join_us book_a_tour_about">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="inner pl-25">
                    <h4 class="hdng">
                        <?php echo $book_heading; ?>
                    </h4>
                    <?php echo $book_banner_description; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
endif;
endwhile;
endif;
get_footer(); // Load the footer template ?>
