const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const FormData = require('form-data');
const sharp = require('sharp');
require('dotenv').config();

const INPUT_DIR = './input';
const OUTPUT_DIR = './output';
const API_KEY = process.env.REMOVE_BG_API_KEY;

const OUTPUT_WIDTH = 500;
const OUTPUT_HEIGHT = 500;
const TOP_PADDING = 30; // keep this space on top
const BOTTOM_TOUCH = true; // aligns subject to touch bottom

if (!API_KEY) {
  console.error('❌ API key is missing. Add it to your .env file.');
  process.exit(1);
}

if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR);
}

async function removeBackground(imagePath) {
  const form = new FormData();
  form.append('image_file', fs.createReadStream(imagePath));
  form.append('size', 'auto');

  const res = await fetch('https://api.remove.bg/v1.0/removebg', {
    method: 'POST',
    headers: { 'X-Api-Key': API_KEY },
    body: form,
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(err);
  }

  return await res.buffer();
}

async function resizeAndAlign(imageBuffer) {
  const image = sharp(imageBuffer);
  const metadata = await image.metadata();

  // calculate scale to fit width OR bottom touching height (minus top padding)
  const scale = Math.min(
    OUTPUT_WIDTH / metadata.width,
    (OUTPUT_HEIGHT - TOP_PADDING) / metadata.height
  );

  const resized = await image
    .resize({
      width: Math.round(metadata.width * scale),
      height: Math.round(metadata.height * scale),
    })
    .toBuffer();

  const resizedMeta = await sharp(resized).metadata();

  const left = Math.floor((OUTPUT_WIDTH - resizedMeta.width) / 2);
  const top = OUTPUT_HEIGHT - resizedMeta.height; // bottom-aligned
  const finalTop = Math.max(top, TOP_PADDING); // ensure top padding stays

  return await sharp({
    create: {
      width: OUTPUT_WIDTH,
      height: OUTPUT_HEIGHT,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 }, // transparent background
    },
  })
    .composite([{ input: resized, left, top: finalTop }])
    .png()
    .toBuffer();
}

function formatFileName(originalName) {
  const baseName = path.parse(originalName).name;
  const sanitized = baseName.replace(/\s+/g, '-'); // replace spaces with hyphens
  return sanitized + '_sized.png';
}

(async () => {
  const files = fs.readdirSync(INPUT_DIR).filter(file =>
    /\.(jpe?g|png|webp)$/i.test(file)
  );

  if (files.length === 0) {
    console.log('⚠️ No images found in input folder.');
    return;
  }

  console.log(`🔄 Found ${files.length} images. Processing...`);

  for (const file of files) {
    const inputPath = path.join(INPUT_DIR, file);
    const outputName = formatFileName(file);
    const outputPath = path.join(OUTPUT_DIR, outputName);

    try {
      const noBgBuffer = await removeBackground(inputPath);
      const finalImage = await resizeAndAlign(noBgBuffer);
      fs.writeFileSync(outputPath, finalImage);
      console.log(`✅ ${file} → ${outputName}`);
    } catch (err) {
      console.error(`❌ Failed: ${file} — ${err.message}`);
    }
  }

  console.log('🎉 All done!');
})();
