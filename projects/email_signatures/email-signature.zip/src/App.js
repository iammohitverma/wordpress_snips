import "./App.css";
import { Signature } from "./Components/Signature";

function App() {
  return (
    <div className="App">
      <Signature />
    </div>
  );
}

export default App;
