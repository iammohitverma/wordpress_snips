import { ComB } from "./ComB";
export const ComA = ({ name, countUpdate }) => {
  return (
    <>
      <h2>ComA {name}</h2>
      <ComB name={name} countUpdate={countUpdate} />
    </>
  );
};
