import axios from "axios";
import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Loader from "./Loader";

const placeholder = "/placeholder_1080_675.jpg";

function BlogPosts({ data }) {
  console.log(data);

  const baseUrl = import.meta.env.VITE_API_URL;
  const sectionData = data || {}; // 👉 ਜੇ data null ਹੋਵੇ ਤਾਂ ਖਾਲੀ object assign
  const { posts } = sectionData; // 👉 data ਵਿੱਚੋਂ posts ਨਿਕਾਲ ਰਹੇ ਹਾਂ

  const [selectedPosts, setSelectedPosts] = useState([]); // 👉 selectedPosts ਲਈ state ਬਣਾਈ

  useEffect(() => {
    if (posts && posts.length) {
      const ids = posts.map((item) => item.ID); // 👉 posts ਵਿੱਚੋਂ ਸਾਰੇ IDs ਲੈ ਰਹੇ
      setSelectedPosts(ids); // 👉 selectedPosts state update ਕਰ ਰਹੇ
    }
  }, [posts]);

  // 👉 ਇੱਕ async function ਜੋ axios ਨਾਲ single post ਦਾ data ਲਿਆਉਂਦਾ
  const fetchPostData = async (id) => {
    const res = await axios.get(`${baseUrl}/wp-json/wp/v2/posts/${id}`);
    const post = res.data;

    // 👉 ਜੇ post ਵਿੱਚ featured_media ਹੋਵੇ ਤਾਂ ਉਸ ਦੀ image ਲਿਆਉਣ ਦੀ ਕੋਸ਼ਿਸ਼
    if (post.featured_media) {
      try {
        const imageRes = await axios.get(
          `${baseUrl}/wp-json/wp/v2/media/${post.featured_media}`
        );
        post.featured_image_url = imageRes.data.source_url; // 👉 image URL save
      } catch (imgErr) {
        console.warn(`Post image not fetched:`, imgErr);
        post.featured_image_url = null;
      }
    } else {
      post.featured_image_url = null;
    }

    return post;
  };

  // 👉 react-query ਨਾਲ posts fetch ਕਰ ਰਹੇ
  const {
    data: fetchedPosts, // 👉 fetch ਹੋਏ posts
    isLoading, // 👉 loading state
    isError, // 👉 error ਹੋਣ ਤੇ true
    error, // 👉 error object
  } = useQuery({
    queryKey: ["acfSelectedPosts", selectedPosts], // 👉 queryKey ਚ selectedPosts ਨਾਲ unique ਬਣਾਇਆ
    queryFn: async () => {
      if (!selectedPosts.length) return []; // 👉 ਜੇ ਕੋਈ selectedPosts ਨਹੀਂ, ਖਾਲੀ array return
      const postData = await Promise.all(
        selectedPosts.map((id) => fetchPostData(id)) // 👉 ਸਾਰੇ ids ਨੂੰ fetchPostData ਨਾਲ fetch
      );
      return postData; // 👉 final data return
    },
  });

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <section className="blog_posts">
      <div className="container">
        <div className="heading_wrap">
          <h3 className="text-body-emphasis">Posts</h3>
        </div>
        <div className="row">
          {fetchedPosts.length > 0 ? (
            fetchedPosts.map((item, key) => (
              <div className="col-lg-4" key={key}>
                <div className="blog_card">
                  <img
                    src={item.featured_image_url || placeholder}
                    className="card-img-top"
                    alt={item.title.rendered}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{item.title.rendered}</h5>
                    <p
                      className="card-text"
                      dangerouslySetInnerHTML={{
                        __html: item.excerpt.rendered,
                      }}
                    />
                    <NavLink
                      to={`/blog/${item.slug}`}
                      className="btn btn-primary"
                    >
                      Read More
                    </NavLink>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div>No posts selected.</div>
          )}
        </div>
      </div>
    </section>
  );
}

export default BlogPosts;
