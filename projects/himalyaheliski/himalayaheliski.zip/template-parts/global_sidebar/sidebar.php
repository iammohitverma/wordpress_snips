<div class="col-md-4">
    <div class="sidebar">
        <?php if( have_rows('portlets', 'option') ): ?>
            <?php while( have_rows('portlets', 'option') ): the_row(); 
                $image = get_sub_field('image');
                $heading = get_sub_field('heading');
                $content = get_sub_field('content');
                $button = get_sub_field('button');
                ?>
                <div class="widget_box">
                    <?php
                    if( $image ){ ?>
                        <div class="img_wrap">
                            <img
                                src="<?php echo $image['url'];?>"
                                alt="<?php echo $image['alt'];?>"
                            />
                        </div>
                    <?php } ?>
                    <div class="heading_wrap">
                        <h3 class="main_heading hr_70 fs_42"><?php echo $heading;?></h3>
                    </div>
                    <div class="content_editor_default">
                        <?php echo $content;?>
                    </div>
                    <?php 
                    if( $button ): 
                        $link_url = $button['url'];
                        $link_title = $button['title'];
                        $link_target = $button['target'] ? $button['target'] : '_self';
                        ?>
                        <a class="hl_btn" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</div>