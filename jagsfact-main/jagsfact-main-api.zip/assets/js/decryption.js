const encryptionMap = {
  A: "𐊀",
  B: "𐊁",
  C: "𐊂",
  D: "𐊃",
  E: "𐊄",
  F: "𐊅",
  G: "𐊆",
  H: "𐊇",
  I: "𐊈",
  J: "𐊉",
  K: "𐊊",
  L: "𐊋",
  M: "𐊌",
  N: "𐊍",
  O: "𐊎",
  P: "𐊏",
  Q: "𐊐",
  R: "𐊑",
  S: "𐊒",
  T: "𐊓",
  U: "𐊔",
  V: "𐊕",
  W: "𐊖",
  X: "𐊗",
  Y: "𐊘",
  Z: "𐊙",
  0: "⊙",
  1: "─",
  2: "╲",
  3: "╱",
  4: "∠",
  5: "╳",
  6: "◊",
  7: "═",
  8: "●",
  9: "↗",
};

const decryptionMap = Object.fromEntries(
  Object.entries(encryptionMap).map(([key, value]) => [value, key])
);

// Decrypt message
document.getElementById("decryptButton").addEventListener("click", () => {
  const encryptedMessage = document.getElementById("encryptedInput").value;
  let decryptedMessage = "";

  for (let char of encryptedMessage) {
    decryptedMessage += decryptionMap[char] || char;
  }

  document.getElementById("decryptedOutput").value = decryptedMessage;
});

// by mohit
const GITHUB_TOKEN = "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"; // Replace with actual token
const OWNER = "mohittechmind";
const REPO = "jagsfactapi";
const FILE_PATH = "encryptedData.json"; // File where encrypted data is stored
const DECRYPT_API_URL = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${FILE_PATH}`;

// Function to fetch encrypted text from GitHub
async function fetchEncryptedData(id) {
  try {
    let response = await fetch(DECRYPT_API_URL, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json",
      },
    });

    let fileData = await response.json();
    let existingContent = atob(fileData.content); // Decode from base64
    let data = JSON.parse(existingContent);

    return data[id] || null; // Return encrypted text if found
  } catch (error) {
    console.error("Error fetching encrypted data:", error);
    return null;
  }
}

// Get ID from URL
const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get("id");

if (id) {
  fetchEncryptedData(id).then((encryptedText) => {
    if (encryptedText) {
      const decodedText = decodeURIComponent(encryptedText);
      document.getElementById("encryptedInput").value = decodedText;
      document.getElementById("decryptButton").click();
      document.getElementById("decryptedOutput").classList.add("active");
      document
        .getElementById("decryptedOutput")
        .scrollIntoView({ behavior: "smooth" });

      setTimeout(() => {
        document.getElementById("decryptedOutput").classList.remove("active");
      }, 2500);
    } else {
      alert("Invalid or expired link.");
    }
  });
}
