<section class="top_intro_section pt_100 pb_100">
  <div class="container">
    <div class="row flex-md-row-reverse">
      <div class="col-md-8 flex-grow-1">
        <div class="right_content">
          <div class="heading_wrap">
            <h3 class="main_heading center hr_70 fs_42">
              <?php echo get_sub_field("heading");?>
            </h3>
          </div>
          <div class="content_editor_default">
            <?php echo get_sub_field("content");?>
          </div>
        </div>
      </div>
      
      <?php 
        $global_sidebar = get_sub_field("global_sidebar");
        if($global_sidebar == "show"){
            $template_part_path = get_stylesheet_directory() . '/template-parts/global_sidebar/sidebar.php';
                if (file_exists($template_part_path)) {
                    include($template_part_path);
            }
        } ?>
    </div>
  </div>
</section>