<?php

/**
 * The template for displaying front page
 *
 * (Home Page of Website)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package boldpark-theme
 */
get_header();
?>
<?php if( have_rows('home_page') ): ?>
    <?php while( have_rows('home_page') ): the_row(); ?>
<div class="" id="home-page">
    <!-- 01 Section Banner Start-->
   <?php 
        //Banner layout.
        if( get_row_layout() == 'banner_section' ): 
        $image = get_sub_field('desktop_banner_image');
        if( !empty( $image ) ): ?>
        <section class="home_banner" style="background-image: url(<?php echo esc_url($image['url']); ?>);">
        <?php endif; ?>
        <div class="container">
            <div class="row d-flex justify-content-end">
                <div class="col-12 col-sm-12 col-md-7 col-lg-7 col-xl-7">
                    <div class="inner hdng_section">
                        <?php
                            // check if the nested repeater field has rows of data
                            if( have_rows('banner_heading') ):
                                echo '<h1 class="banner_hdng">';
                                    // loop through the rows of data
                                    while ( have_rows('banner_heading') ) : the_row();

                                        $heading = get_sub_field('banner_heading_text');
                        ?>
                                        <span><?php echo $heading ;?></span>
                        <?php
                                    endwhile;

                                echo '</h1>';

                            endif;
                        ?>
                    </div>
                </div>
                <div class="col-12 col-sm-12">
                    <div class="inner shapes_btn">
                        <?php
                            // check if the nested repeater field has rows of data
                            if( have_rows('banner_button') ):
                        ?>
                        <ul>
                            <?php
                             while ( have_rows('banner_button') ) : the_row(); 
                                    $link = get_sub_field('button_');
                                    if( $link ): 
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    //$link_target = $link['target'] ? $link['target'] : '_self';
                             ?>
                            <li>
                                <a class="button" href="<?php echo esc_url( $link_url ); ?>"><?php echo esc_html( $link_title ); ?></a>
                                <?php endif; ?>  
                            </li>
                            <?php endwhile; ?>
                        </ul>
                        <?php
                            endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- 01 Section Banner Start-->

    <!-- 02 Section Banner Start-->
    <?php
    // Welcome section  layout.
        elseif( get_row_layout() == 'welcome_section' ): 
    ?>
    <section class="welcome_global bg_welcome bg_green">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6">
                    <div class="inner">
                    <?php $welcome_heading = get_sub_field('heading'); ?>
                        <h2 class="hdng">
                           <?php echo $welcome_heading ;?>
                        </h2>
                         <?php $welcome_image = get_sub_field('image'); ?>
                        <figure>
                            <img src="<?php echo esc_url($welcome_image['url']); ?>" alt="<?php echo esc_html($welcome_image['title']); ?>">
                        </figure>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <?php $welcome_desc = get_sub_field('description'); ?>
                    <div class="inner editor">
                        <?php echo $welcome_desc ;?>
                        <?php
                        $link = get_sub_field('button');
                        if( $link ): 
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                            $link_target = $link['target'] ? $link['target'] : '_self';
                            ?>
                            <a class="cmn_btn" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
                        <?php endif; ?>
                    </div>
                </div>  
            </div>
        </div>
    </section>
    <!-- 02 Section Banner Start-->
    <?php
    elseif (get_row_layout() == 'video_section') :
        ?>
            <!-- Section 02 Video Section -->
            <section class="single-video-sec">
                <?php get_template_part('template-parts/sections/videos_section'); ?>
            </section>
            <!-- Section 02 Video Section -->
    <!-- 03 Section Shapes Start-->
    <?php
    // Welcome section  layout.
        elseif( get_row_layout() == 'children_thrive_section' ): 
    ?>
    <section class="shapes_section">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-12">
                    <div class="inner">
                        <?php $children_heading = get_sub_field('section_heading'); ?>
                        <h2 class="hdng">
                            <?php echo $children_heading ;?>
                        </h2>
                        <hr class="cmn_hr">
                    </div>
                </div>  
               
                <?php
                    // check if the nested repeater field has rows of data
                    if( have_rows('shape_content') ):
                ?>
                <?php while ( have_rows('shape_content') ) : the_row();?>
                <div class="col-12 col-sm-10 col-md-7 col-xl-4 shape">
                    <div class="inner">
                        <?php $heading = get_sub_field('heading'); ?>
                            <h4 class="hdng">
                                <?php echo $heading ;?>
                            </h4>
                            <?php $description = get_sub_field('description'); ?>
                            <p>
                               <?php echo $description ;?>
                            </p>
                            <?php
                            $link = get_sub_field('button');
                            if( $link ): ?>
                                <a href="<?php echo $link['url'];?>" class="cmn_btn"><?php echo $link['title'];?></a>
                            <?php endif; ?>
                    </div>
                </div> 
                <?php 
                    endwhile;
                    endif; 
                ?>
            </div>
        </div>
    </section>
    <!-- 03 Section Shapes End-->

    <!-- 04 Section animated shapes start-->
    <?php
    // Welcome section  layout.
        elseif( get_row_layout() == 'program_section' ): 
    ?>
    <section class="animated_shape">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 d-flex align-items-center">
                    <div class="inner">
                        <?php $heading = get_sub_field('heading'); ?>
                            <h4 class="hdng">
                                <?php echo $heading ;?>
                            </h4>
                         <?php $description = get_sub_field('description'); ?>
                            <p>
                               <?php echo $description ;?>
                            </p>
                            <?php
                          $link = get_sub_field('button');
                          if( $link ): 
                              $link_url = $link['url'];
                              $link_text = $link['title']; // Add this line to retrieve the text
                          ?>
                              <a class="cmn_btn" href="<?php echo esc_url( $link_url ); ?>"><?php echo $link_text;  ?></a>
                          <?php endif; ?>
                          
                       
                    </div>
                </div>
                <div class="col-12 col-lg-6 d-flex align-items-center">
                    <div class="tm-anim-wrap-v1">
                        <div class="box-wrap">
                            <?php
                            // if( have_rows('shape_content') ):
                                    if( have_rows('shape_content') ): $i = 0;; 
                                    while ( have_rows('shape_content') ) : the_row(); $i++; ;
                                    $Subheading = get_sub_field('sub_heading');
                                    $heading = get_sub_field('heading');
                                    $description = get_sub_field('description');
                                    $button = get_sub_field('button');
                             ?>
                                
                            <div class="box" data-attr="box<?php echo $i; ?>">
                                <div class="inner">
                                    <div class="heading">
                                    <h4><?php echo $Subheading ;?></h4>
                                    <h3><?php echo $heading ;?></h3>
                                    </div>
                                    <div class="text">
                                    <p>
                                        <?php echo $description ;?>
                                    </p>
                                    <?php
                                    $link = get_sub_field('button');
                                    if( $link ): 
                                        $link_url = $link['url'];
                                        $link_text = $link['title'];
                                        ?>
                                        <a class="btn black outline" href="<?php echo esc_url( $link_url ); ?>"><?php echo $link_text; ?></a>
                                    <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                                
                            <?php endwhile; 
                                endif;      
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <!-- 04 Section animated shapes end-->

    <!-- 05 Section animated shapes start-->
      <?php
    // Welcome section  layout.
        elseif( get_row_layout() == 'wilderness_playgroup' ): 
    ?>
    <section class="wilderness_group">
        <div class="container">
            <div class="row">
                <div class="col-12">
                   <?php $sectionheading = get_sub_field('section_heading'); ?>
                        <h3 class="hdng">
                            <?php echo $sectionheading ;?>
                        </h3>
                </div>
                <div class="col-12 col-md-5 left">
                    <div class="inner">
                    <?php $heading = get_sub_field('heading'); ?>
                        <h4 class="hdng">

                            <?php echo $heading ;?>
                        </h4>
                        <?php $description = get_sub_field('description'); ?>
                        <p>
                            <?php echo $description ;?>
                        </p>
                        
                        <?php
                            $link = get_sub_field('button');
                            if( $link ): 
                                $link_url = $link['url'];
                                ?>
                                <a class="cmn_btn" href="<?php echo esc_url( $link_url ); ?>"><?php echo $link['title']; ?></a>
                        <?php endif; ?> 
                    </div>
                </div>
                <div class="col-12 col-md-7 mt-4 mt-md-0">
                    <?php $image = get_sub_field('image'); 
                         if( !empty( $image ) ): 
                    ?>
                    <figure>
                        <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_html($image['title']); ?>">
                    </figure>
                    <?php endif;      ?>
                </div>
            </div>
        </div>
    </section>
    <!-- 05 Section animated shapes end-->


    <!-- 06 Section testimonials start-->
    <?php
        // Testimonial section  layout.
        elseif( get_row_layout() == 'testimonials_grid_section' ): 
    ?>
    <section class="testimonials_grid bg_grey">
    <?php get_template_part( 'template-parts/sections/grid_testimonial' ); ?>
    </section>
    <!-- 06 Section testimonials end-->


    <!-- 07 Section events start-->
    <section class="events_resources hide_temp">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 d-flex align-items-center">
                    <div class="inner">
                        <h3 class="hdng">
                            Events & Resources
                        </h3>
                        <hr class="cmn_hr">
                    </div>
                </div>
                <div class="col-12 col-md-6 d-flex justify-content-md-end align-items-center mt-3 mt-md-0">
                    <div class="inner">
                        <a href="" class="cmn_btn">
                            More events and resources
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- 05 Section apply start-->
        <section class="slider_animation">
            <div class="inner">
                <div class="owl-carousel wrap_slider tm_image_slider">

                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="items">
                        <div class="card_main">
                            <div class="img_main">
                                <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/05/Pathway-Night-child.png" alt="Pathway-Night-child">
                            </div>
                            <div class="content_main">
                                <div class="top_cont">
                                    <p>DD-MM-YY</p>
                                    <h3 class="card_hdng">Upcoming Open Tour</h3>
                                </div>
                                <div class="content_mid">
                                    <p>
                                        Students are encouraged to find their voice and gather skills that allow them to
                                        effectively express their ideas, opinions and thoughts.
                                    </p>
                                </div>
                                <div class="cont_bottom">
                                    <p>contact <br>name.surname@boldpark.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!-- 05 Section apply end-->
    </section>
    <!-- 07 Section events end-->


    <!-- 08 Section testimonials start-->
     <?php
        // Testimonial section  layout.
        elseif( get_row_layout() == 'message_section' ): 
    ?>
    <section class="testimonials_single">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-12 col-md-8 col-lg-7 ">
                    <div class="inner ps-md-3">
                        <?php $message = get_sub_field('message_content'); ?>
                        <p class="desc">
                            <?php echo $message ;?>
                        </p>
                        <p class="userName">
                             -  <?php $messageauthor = get_sub_field('author_name'); 
                                    echo $messageauthor ;
                                ?>
                            <!-- <img src="/wp-content/uploads/2023/05/heart.png" alt="heart"> -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- 08 Section testimonials end-->


    <!-- 09 Section apply start-->
    <?php
        // Apply Now section  layout.
        elseif( get_row_layout() == 'apply_now_section' ): 
    ?>
    <section class="apply_now">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-5">
                    <div class="inner">
                        <?php $applyheading = get_sub_field('heading'); ?>
                        <h3 class="hdng">
                             <?php echo $applyheading ;?>
                        </h3>
                        <?php $applydesc = get_sub_field('description'); ?>
                        <p>
                            <?php echo $applydesc ;?>
                        </p>
                    </div>
                </div>
            
                <div class="col-12 col-lg-7">
                    <div class="inner">
                        <div class="tm-anim-wrap-v2 max_650">
                            <div class="box">
                                <?php
                                    $link = get_sub_field('apply_button');
                                    if( $link ): 
                                        $link_url = $link['url'];
                                        ?>
                                        <a class="btn" href="<?php echo esc_url( $link_url ); ?>"><?php echo $link['title']; ?></a>
                                <?php endif; ?> 
                                <div class="shapes">
                                <span class="shape hexagon"></span>
                                <span class="shape square"></span>
                                <span class="shape rectangle"></span>
                                <span class="shape rectangle2"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- 09 Section apply end-->
</div>
<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); ?>