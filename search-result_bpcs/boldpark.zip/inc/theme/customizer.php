<?php
    function boldpark_customize_register($wp_customize){
        // Sections 
        $wp_customize->add_section('topbar', array(
            'title'    => __('Topbar', ' boldpark'),
            'description' => '',
            'priority' => 10,
        ));   

        
        //  =============================
        //  =Text change              =
        //  =============================
        $wp_customize->add_setting('topbar_text', array(
            'default'           => 'Visit us / next open tour / application deadline',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
    
        $wp_customize->add_control( "topbar_text", array(
            'label'    => __('Topbar Text', 'boldpark'),
            'section'  => 'topbar',
            'settings' => 'topbar_text',
            'type' => 'textarea',        
        ));

        //  =============================
        //  = Radio Input               =
        //  =============================
        $wp_customize->add_setting('topbar_close_btn_hide_show', array(
            'default'        => 'yes',
            'capability'     => 'edit_theme_options',
            'type'           => 'theme_mod',
        ));
        
        $wp_customize->add_control('topbar_close_btn_hide_show', array(
            'label'      => __('Topbar Close Button', 'boldpark'),
            'section'    => 'topbar',
            'settings'   => 'topbar_close_btn_hide_show',
            'type'       => 'radio',
            'choices'    => array(
                'yes' => 'Show',
                'no' => 'Hide',
            ),
        ));

        // Panels for header content change
        $wp_customize->add_panel( 'header_content_panel', array( 
            'title'            => __( 'Header Content', ' boldpark' ),
            'description'      => __( '' ), 
            'priority'         => 10,   
        ) );
        // Section
        $wp_customize->add_section('header_content_btn', array(
            'title'    => __('Header Button', ' boldpark'),
            'description' => '',
            'priority' => 11,
            'panel' => "header_content_panel"
        ));   
        // header-button-book a tour text
        $wp_customize->add_setting('header_tour_button_text', array(
            'default'           => 'Enter text here..',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_tour_button_text_setting", array(
            'label'    => __('Button text', 'boldpark'),
            'section'  => 'header_content_btn',
            'settings' => 'header_tour_button_text',
            'type' => 'text',        
        ));
        // header-button-book a tour url
        $wp_customize->add_setting('header_tour_button_url', array(
            'default'           => '#',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_tour_button_url", array(
            'label'    => __('Button link', 'boldpark'),
            'section'  => 'header_content_btn',
            'settings' => 'header_tour_button_url',
            'type' => 'text',        
        ));
        // header mega menu content
        // Section
        $wp_customize->add_section('header_megamenu_content', array(
            'title'    => __('Mega Menu Content', ' boldpark'),
            'description' => '',
            'priority' => 11,
            'panel' => "header_content_panel"
        ));  
        // heading
        $wp_customize->add_setting('header_megamenu_content_heading', array(
            'default'           => 'Enter text here..',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_megamenu_content_heading", array(
            'label'    => __('Heading', 'boldpark'),
            'section'  => 'header_megamenu_content',
            'settings' => 'header_megamenu_content_heading',
            'type' => 'text',        
        ));
        // // para
        $wp_customize->add_setting('header_megamenu_content_para', array(
            'default'           => 'Enter text here..',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_megamenu_content_para", array(
            'label'    => __('Paragraph', 'boldpark'),
            'section'  => 'header_megamenu_content',
            'settings' => 'header_megamenu_content_para',
            'type' => 'textarea',        
        ));
        // button text
        $wp_customize->add_setting('header_megamenu_content_button_text', array(
            'default'           => 'Enter text here..',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_megamenu_content_button_text", array(
            'label'    => __('Button Text', 'boldpark'),
            'section'  => 'header_megamenu_content',
            'settings' => 'header_megamenu_content_button_text',
            'type' => 'text',        
        ));
        // button url
        $wp_customize->add_setting('header_megamenu_content_button_url', array(
            'default'           => '#',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',
            'type'           => 'theme_mod',  
        ));
        $wp_customize->add_control( "header_megamenu_content_button_url", array(
            'label'    => __('Button link', 'boldpark'),
            'section'  => 'header_megamenu_content',
            'settings' => 'header_megamenu_content_button_url',
            'type' => 'text',        
        ));
}
add_action('customize_register', 'boldpark_customize_register');



/**
 * Add our Customizer content
 */
function theme_customize_register($wp_customize)
{
    /*------ Customizer Section ------*/
    $wp_customize->add_section('footer_section', array(
        'title'    => 'Footer',
        'description' => 'Footer Customizer',
        'priority' => 120,
    ));

    /*------ Footer Logo ------*/
    $wp_customize->add_setting('footer_logo', array(
        'default'           => get_bloginfo('template_url') . '/images/logo.png',
        'capability'        => 'edit_theme_options',
        'type'           => 'option',

    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'image_upload_test', array(
        'label'    => 'Footer Logo',
        'section'  => 'footer_section',
        'settings' => 'footer_logo',
    )));

    /*------ book tour ------*/
    $wp_customize->add_setting('Book_tour', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('Book_tour', array(
        'label'   => 'Book Text',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ book tour ------*/
    $wp_customize->add_setting('Book_tourlink', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('Book_tourlink', array(
        'label'   => 'Book Link',
        'section' => 'footer_section',
        'type'    => 'url',
    ));

    /*------ our shop ------*/
    $wp_customize->add_setting('our_shop', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('our_shop', array(
        'label'   => 'Shop Text',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ our shop ------*/
    $wp_customize->add_setting('our_shoplink', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('our_shoplink', array(
        'label'   => 'Shop Link',
        'section' => 'footer_section',
        'type'    => 'url',
    ));

    /*------ login ------*/
    $wp_customize->add_setting('login', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('login', array(
        'label'   => 'Login Text',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ login ------*/
    $wp_customize->add_setting('loginlink', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('loginlink', array(
        'label'   => 'Login Link',
        'section' => 'footer_section',
        'type'    => 'url',
    ));

    /*------ Footer Info ------*/
    $wp_customize->add_setting('footer_Info', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('footer_Info', array(
        'label'   => 'Footer Info',
        'section' => 'footer_section',
        'type'    => 'textarea',
    ));


    /*------ Phone Number ------*/
    $wp_customize->add_setting('contact_one', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('contact_one', array(
        'label'   => 'First Phone Number',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ Phone Number ------*/
    $wp_customize->add_setting('contact_two', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('contact_two', array(
        'label'   => 'Second Phone Number',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ mail ------*/
    $wp_customize->add_setting('mail_fld', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('mail_fld', array(
        'label'   => 'Email',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ campus name ------*/
    $wp_customize->add_setting('first_campus', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('first_campus', array(
        'label'   => 'Campus Name',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ campus location ------*/
    $wp_customize->add_setting('first_campus_location', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('first_campus_location', array(
        'label'   => 'Campus Location',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ campus name ------*/
    $wp_customize->add_setting('second_campus', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('second_campus', array(
        'label'   => 'Campus Name',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ campus location ------*/
    $wp_customize->add_setting('second_campus_location', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('second_campus_location', array(
        'label'   => 'Campus Location',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ facebook ------*/
    $wp_customize->add_setting('fb_link', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('fb_link', array(
        'label'   => 'Facebook',
        'section' => 'footer_section',
        'type'    => 'text',
    ));

    /*------ instagram ------*/
    $wp_customize->add_setting('insta_link', array(
        'default'        => "#",
    ));

    $wp_customize->add_control('insta_link', array(
        'label'   => 'Facebook',
        'section' => 'footer_section',
        'type'    => 'text',
    ));
    /*------ okmg text ------*/
    $wp_customize->add_setting('okmg_website', array(
        'default'        => '#',
    ));

    $wp_customize->add_control('okmg_website', array(
        'label'   => 'Okmg Text',
        'section' => 'footer_section',
        'type'    => 'textarea',
    ));
    $topbar_texts = array(
        'footer_bottom_link_one' => __('Footer Bottom Link One', 'theme_text_domain'),
        'footer_bottom_link_two' => __('Footer Bottom Link Two', 'theme_text_domain'),
        'footer_copyright' => __('Copyright Text', 'theme_text_domain'),
    );
    
    foreach ($topbar_texts as $key => $label) {
        $setting_key = strtolower($key);
    
        // Add Setting
        $wp_customize->add_setting($setting_key, array(
            'default'           => '',
        ));
    
        // Add Control
        $wp_customize->add_control($setting_key, array(
            'label'    => $label,
            'section'  => 'footer_section',
            'settings' => $setting_key,
            'type'     => 'textarea',
        ));
    }

}
add_action('customize_register', 'theme_customize_register');