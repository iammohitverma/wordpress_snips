import { ComC } from "./ComC";
export const ComB = ({ name, countUpdate }) => {
  return (
    <>
      <p>Com B</p>
      <ComC name={name} countUpdate={countUpdate} />
    </>
  );
};
