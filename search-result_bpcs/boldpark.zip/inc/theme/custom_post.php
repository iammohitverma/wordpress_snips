<?php
/**
 * Custom Post Taxonomy
 */
if (!function_exists('register_people_taxonomy')) :
    function register_people_taxonomy()
    {
       register_post_type('our-people', 
       array(       
            'public' => true,       
            'labels' => array(            
            'name' => 'Our People',            
            'add_new_item' => 'Add New People',            
            'edit_item' => 'Edit People',            
            'all_items' => 'All People',            
            'singular_name' => 'People',), 
            'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'revisions','comments', 'author'),        
            'rewrite' => array('slug' => 'our-people'),        
            'has_archive' => true,        
            'menu_icon' => 'dashicons-admin-users',        
            'menu_position'       => 6,   

            )); 

            register_post_type('events', 
                   array(       
                        'public' => true,       
                        'labels' => array(            
                        'name' => 'Events',            
                        'add_new_item' => 'Add New Events',            
                        'edit_item' => 'Edit Events',            
                        'all_items' => 'All Events',            
                        'singular_name' => 'Events',), 
                        'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'revisions','comments', 'author'),        
                        'rewrite' => array('slug' => 'events'),        
                        'has_archive' => true,        
                        'menu_icon' => 'dashicons-star-filled',        
                        'menu_position'       => 4,   

            )); 

            
            register_taxonomy( 'people-category', 
            array( 'our-people' ),       
            array( 'labels' => array(
            'name' => 'People Category',
            'menu_name' => 'People Category',                
            'singular_name' => 'People Category',                
            'all_items' => 'All  People Category'),            
            'public' => true,
            'hierarchical' => true,            
            'show_ui' => true,            
            'rewrite' => array( 'slug' => 'people-category', 'hierarchical' => true, 'with_front' => false ),       
            )    );
            
            register_taxonomy( 'event-category', 
                        array( 'events' ),       
                        array( 'labels' => array(
                        'name' => 'Event Category',
                        'menu_name' => 'Event Category',                
                        'singular_name' => 'Event Category',                
                        'all_items' => 'All  Event Category'),            
                        'public' => true,
                        'hierarchical' => true,            
                        'show_ui' => true,            
                        'rewrite' => array( 'slug' => 'event-category', 'hierarchical' => true, 'with_front' => false ),       
                        )    );
    }
    add_action('init', 'register_people_taxonomy');
endif;
