import React from 'react'
import Comm1 from '../components/Login/Comm1'

const Login = () => {
  return (
    <div>
      <Comm1 />
    </div>
  )
}

export default Login
