    <?php
    /*
Template Name: Specialist Programs
*/

    get_header(); // Load the header template

    ?>

    <!-- Common banner secion inner pages  -->
    <?php if (have_rows('specialist_programs_sections')) :
        while (have_rows('specialist_programs_sections')) : the_row();

            if (get_row_layout() == 'banner_section') : ?>
                <section class="our_difference_newbanner cmn_new_banner bg_lightpnk">
                    <div class="container-fluid px-0">
                        <div class="banner_main">
                            <?php
                            $parent_pageId = wp_get_post_parent_id(get_the_ID());
                            $parent_page = get_the_title($parent_pageId);
                            $parent_page_url = get_the_permalink($parent_pageId);
                            $page_title = $wp_query->post->post_title;
                            ?>
                            <div class="container">
                                <div class="breadcrumbs">
                                    <ul>
                                        <?php if ($parent_pageId != 0) { ?>
                                            <li>
                                                <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                                            </li>
                                        <?php } ?>
                                        <li>
                                            <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <?php
                            $banner_heading = get_sub_field('banner_heading');
                            $banner_desc = get_sub_field('banner_description');
                            $banner_img = get_sub_field('banner_image');
                            ?>
                            <div class="banner_content_wrap">
                                <div class="row">
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                                        <div class="left_main">

                                            <div class="left_img">
                                                <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                                <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                                        <div class="banner_content_inner">
                                            <div class="right_cont">
                                                <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading; ?></h2>
                                                <p> <?php echo $banner_desc; ?></p>
                                            </div>
                                            <div class="banner_links">
                                                <?php get_template_part('template-parts/sections/banner_links'); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Common banner secion inner pages  -->

                <!-- intro section -->
                <?php
                $intro_text = get_sub_field('intro_text');
                if ($intro_text) {
                ?>
                    <section class="program_intro">
                        <div class="container-fluid">
                            <div class="container">
                                <div class="text_wrapper">
                                    <p><?php echo $intro_text; ?></p>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php } ?>

                <!-- Section 02 start-->
            <?php elseif (get_row_layout() == 'programs') : ?>
                <?php
                // check if the nested repeater field has rows of data
                if (have_rows('program')) :
                ?>
                    <div class="program_list_loop_wrapper">
                        <?php
                        $count  = 0;
                        while (have_rows('program')) : the_row();
                            $program_id = get_sub_field('program_id')
                        ?>
                            <section class="join_us programList <?php $count++;
                                                                if ($count == 1) {
                                                                    echo 'pt_extra';
                                                                } ?>" id="<?php echo $program_id; ?>">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-6 col-lg-7 my-2 my-md-0">
                                            <?php $image = get_sub_field('program_image');
                                            if (!empty($image)) : ?>
                                                <div class="inner pr-25">
                                                    <img src="<?php echo esc_url($image['url']); ?>" alt="">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 col-lg-5 mt-4 mt-md-0 d-flex align-items-center my-2 my-md-0">
                                            <div class="inner pl-25">
                                                <?php $program_heading = get_sub_field('program_heading'); ?>
                                                <?php $program_description = get_sub_field('program_description'); ?>
                                                <?php $full_width_desc = get_sub_field('full_width_desc'); ?>
                                                <h4 class="hdng">
                                                    <?php echo $program_heading; ?>
                                                </h4>
                                                <p>
                                                    <?php echo $program_description; ?>
                                                </p>
                                                <?php if (!$full_width_desc) { ?>
                                                    <?php
                                                    $link = get_sub_field('program_button');
                                                    if ($link) :
                                                        $link_url = $link['url'];
                                                        $link_title = $link['title'];
                                                    ?>
                                                        <a class="cmn_btn" href="<?php echo esc_url($link_url); ?>"><?php echo $link_title; ?></a>
                                                    <?php endif; ?>
                                                <?php  } ?>
                                            </div>
                                        </div>
                                        <?php if ($full_width_desc) { ?>
                                            <div class="col-12">
                                                <div class="inner pl-25 full_width_desc">
                                                    <?php if ($full_width_desc) { ?>
                                                        <p><?php echo $full_width_desc; ?></p>
                                                    <?php  } ?>
                                                    <?php
                                                    $link = get_sub_field('program_button');
                                                    if ($link) :
                                                        $link_url = $link['url'];
                                                        $link_title = $link['title'];
                                                    ?>
                                                        <a class="cmn_btn" href="<?php echo esc_url($link_url); ?>"><?php echo $link_title; ?></a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php  } ?>
                                    </div>
                                </div>
                            </section>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
                <!-- Section 02 end-->

            <?php
            elseif (get_row_layout() == 'testimonial_grid') :
            ?>
                <!-- 05 Section testimonials start-->
                <section class="testimonials_grid bg_drkgrey">
                    <?php get_template_part('template-parts/sections/grid_testimonial'); ?>
                </section>

                <!----------------  View Other program Section Start------------------------------>
            <?php
            elseif (get_row_layout() == 'shapes_section') :
                $shape_heading = get_sub_field('section_heading');
            ?>
                <section class="shapes_in">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="innershapes_main">
                                    <h3 class="hdng">
                                        <?php echo $shape_heading; ?>
                                    </h3>
                                    <div class="inner shapes_btn">
                                        <?php
                                        // check if the nested repeater field has rows of data
                                        if (have_rows('shapes')) :
                                        ?>
                                            <ul>
                                                <?php
                                                while (have_rows('shapes')) : the_row();
                                                    $link = get_sub_field('shape');
                                                    if ($link) :
                                                        $link_url = $link['url'];
                                                        $link_title = $link['title'];
                                                ?>
                                                        <li>
                                                            <a class="button" href="<?php echo esc_url($link_url); ?>"><?php echo esc_html($link_title); ?></a>
                                                        <?php endif; ?>
                                                        </li>
                                                    <?php endwhile; ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </section>
                <!----------------  View Other program Section End------------------------------>
                <!-- 05 Section testimonials end-->
            <?php
            elseif (get_row_layout() == 'join_us_section') :
            ?>
                <!-- 06 Section join us start-->
                <section class="join_us">
                    <?php get_template_part('template-parts/sections/join_us'); ?>
                </section>
                <!-- 06 Section join us end-->
                <!-- Section 08 Apply Now Start -->
            <?php elseif (get_row_layout() == 'apply_now_section') : ?>
                <!-- Questions start-->
                <section class="questions_sec">
                    <?php get_template_part('template-parts/sections/apply_now'); ?>
                </section>
                <!-- Section 08 Apply Now End -->
    <?php endif;
        endwhile;
    endif;
    get_footer(); // Load the footer template 
    ?>