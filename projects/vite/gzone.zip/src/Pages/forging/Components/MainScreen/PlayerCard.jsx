const PlayerCard = ({ cardImage, cryptoplan, playerclass, subclass }) => {
    return (
        <div className="player_card">
            <div className="card_inner">
                <div className="player_img">
                    <img src={cardImage} alt="Cryptoplan Avtar" />
                </div>
                <div className="player_details">
                    <h3 className="cryptoplan">CRYPTOPLAN <span className='textBlue'>{cryptoplan}</span></h3>
                    <h4 className="class">
                        <span className="left_align"> CLASS: </span>
                        <span className="textBlue">{playerclass}</span>
                    </h4>
                    <h4 className="sub_class">
                        <span className="left_align"> SUBCLASS: </span>
                        <span className="textBlue">{subclass}</span>
                    </h4>
                </div>
            </div>
        </div>
    )
}
export default PlayerCard;