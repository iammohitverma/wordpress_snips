const express = require("express");
const sharp = require("sharp");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const port = 3000;

// Set up multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save original files in 'uploads/'
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Save original image with timestamp
  },
});

const upload = multer({ storage: storage });

// Serve static files from the 'resized' folder
app.use("/resized", express.static(path.join(__dirname, "resized")));

// Serve static HTML page
app.use(express.static("public"));

// API to upload and resize multiple images
app.post("/resize", upload.array("images", 10), (req, res) => {
  const { width, height } = req.body;

  // Validate width (ensure it's a positive number)
  const widthNum = parseInt(width, 10);
  const heightNum = parseInt(height, 10);

  if (isNaN(widthNum) || widthNum <= 0) {
    return res.status(400).send("Invalid or missing width.");
  }

  // If height is not provided, calculate based on aspect ratio
  let calculatedHeight = heightNum;
  if (isNaN(calculatedHeight) || calculatedHeight <= 0) {
    // No valid height, calculate based on the aspect ratio
    sharp(req.files[0].path)
      .metadata()
      .then((metadata) => {
        const aspectRatio = metadata.width / metadata.height;
        calculatedHeight = Math.round(widthNum / aspectRatio);

        // Call the resize function once we have the calculated height
        resizeImages(widthNum, calculatedHeight, req.files, res);
      })
      .catch((err) => {
        console.error("Error getting metadata:", err);
        res.status(500).send("Error resizing images.");
      });
  } else {
    // Height provided, resize based on that
    resizeImages(widthNum, calculatedHeight, req.files, res);
  }
});

// Function to resize images
function resizeImages(width, height, files, res) {
  const outputPaths = [];

  files.forEach((file) => {
    const inputPath = file.path; // Path of the uploaded image
    const outputPath = `resized/resized_${file.filename}`; // Save resized images in 'resized' folder

    // Ensure the 'resized' folder exists or create it
    if (!fs.existsSync("resized")) {
      fs.mkdirSync("resized");
    }

    // Resize the image
    sharp(inputPath)
      .resize(width, height)
      .toFile(outputPath, (err, info) => {
        if (err) {
          console.error("Error resizing image:", err);
          return res.status(500).send("Error resizing images.");
        }

        outputPaths.push(outputPath); // Add the resized image path to the array

        // After processing all files
        if (outputPaths.length === files.length) {
          res.send({
            message: "Images resized successfully!",
            files: outputPaths.map((file) => `/resized/${file.split("/")[1]}`), // Return correct URL to access the resized images
          });
        }
      });
  });
}

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
