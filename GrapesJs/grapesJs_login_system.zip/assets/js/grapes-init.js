const cssStyles = [
  "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css",
  "./assets/css/custom-style.css",
];
const jsScripts = ["https://code.jquery.com/jquery-3.6.0.min.js"];
const editor = grapesjs.init({
  container: "#gjs",
  fromElement: true, // This loads the existing HTML as editable components
  width: "100%",
  height: "100vh",
  storageManager: {
    id: "gjsdata-", // Prefix for localStorage keys
    type: "local", // Save to localStorage
    autosave: false, // Auto-save on changes
    autoload: true, // Load saved data on init
    stepsBeforeSave: 1, // Save after every change
  },
  plugins: ["gjs-blocks-basic"],
  pluginsOpts: {
    "gjs-blocks-basic": {},
  },
  canvas: {
    styles: cssStyles,
    scripts: jsScripts,
  },
  // Disable telemetry to avoid the 400 error
  telemetry: false,
});

window.editor = editor;
