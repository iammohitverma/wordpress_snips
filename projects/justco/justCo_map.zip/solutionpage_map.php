<?php
// Set defaults.
if (!isset($attributes)) {
    $attributesData = "";
} else {
    $attributesData = $attributes;
}
$post_tabs_param = wp_parse_args(
    $args,
    $attributesData
);

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$current_url = explode("/", $actual_link);
$parentCatSlug = $current_url[3];

$childCatSlug = $current_url[4];

$citySlug = $post_tabs_param['city'];



$cusomFieldTest = $parentCatSlug;
if ($childCatSlug == 'en') {
    $cusomFieldTest .= '-en';
    // $centre =  'centre';
} else {
    // $centre = $childCatSlug;
}
$citySlug = strtoupper($citySlug);
if ($citySlug == 'SYDNEY') {
    $cusomFieldTest .= "-sd";
    // $centre = '';
}
if ($citySlug == 'MELBOURNE') {
    $cusomFieldTest .= "-ml";
    // $centre = '';
}
if ($citySlug == 'HSINCHU') {
    $cusomFieldTest .= "-hs";
    // $centre = '';
}
if ($citySlug == 'TAIPEI') {
    $cusomFieldTest .= "-tp";
    // $centre = '';
}
if ($citySlug == 'SG') {
    $cusomFieldTest = "sg";
}
$taxonomy = 'centre-district';

if ($citySlug == 'ALL') {
    $taxonomy = 'centre-slug';
    $cusomFieldTest = $parentCatSlug;
}




?>







<section class="latest_post_tabs_mv">

    <div class="map-wrapper">
        <div class="wrap-map">
            <div class="map">
                <div class="mapouter">
                    <div class="gmap_canvas">
                        <div id="map"></div>
                    </div>
                </div>
            </div>
            <div class="placeholderLoader">
                <div class="card_placeholders_mv">
                    <div class="row">
                        <div class="col-12">
                            <div class="placeholder_card map_loader"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    if ($citySlug != 'ALL') {

        $parentTermId = get_term_by('slug', $cusomFieldTest, $taxonomy);
        if ($parentTermId && !is_wp_error($parentTermId)) {
            $categories = get_terms($taxonomy, array('hide_empty' => false, 'child_of' => $parentTermId->term_id));
            $term_slug = isset($categories[0]->slug) ? $categories[0]->slug : array();
        } else {
            $term_slug = $cusomFieldTest;
        }

    } else {
        $term_slug = $cusomFieldTest;
    }
    $args = array(
        'post_type' => 'centre',
        'orderby' => 'ID',
        'post_status' => 'publish',
        'order' => 'DESC',
        'posts_per_page' => '-1', //initially 8 post showing 
        'hide_empty' => false,
        'tax_query' => array(
            array(
                'taxonomy' => $taxonomy,
                'field' => 'slug',
                'terms' => $term_slug
            )
        )
    );
    $result = new WP_Query($args);


    ?>
</section>
<?php

if ($result->have_posts()):
    while ($result->have_posts()):
        $result->the_post();

        $location = get_field('location', get_the_ID());

        $locationpost_ID = get_the_ID();

        $location_image = wp_get_attachment_image_src(get_post_thumbnail_id($locationpost_ID), 'single-post-thumbnail');
        $latitude_pins = get_field("latitude", $locationpost_ID);
        $longitude_pins = get_field("longitude", $locationpost_ID);

        $latitude_var = floatval($latitude_pins);
        $longitude_var = floatval($longitude_pins);
        $address = get_post_field('post_excerpt', $locationpost_ID);
        // $address = trim($location);

        // $url = "https://maps.google.com/maps/api/geocode/json?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&address=" . str_replace(" ", "+", $address) . "&sensor=false";


        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // $responseJson = curl_exec($ch);
        // curl_close($ch);

        // $response = json_decode($responseJson);

        // if ($response->status == 'OK') {

        if ($latitude_pins != "" && $longitude_pins != "") {
            $latitude = $latitude_var;
            $longitude = $longitude_var;
        } else {
            // $latitude = $response->results[0]->geometry->location->lat;
            // $longitude = $response->results[0]->geometry->location->lng;
            $latitude = '';
            $longitude = '';
        }

        $the_title = get_the_title();
        $positions[] = array(
            'name' => $the_title,
            'address' => $address,
            'image' => $location_image[0],
            'lat' => $latitude,
            'lng' => $longitude,
        );
        // }

        /* */

    endwhile;
endif;
wp_reset_postdata();

?>

<script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&callback=initMap&v=weekly"
    defer></script>
<script>
    var positions = <?php echo json_encode(isset($positions) ? $positions : array()); ?>;
    var hs_show_map = true;
    tabs_map(positions);
</script>