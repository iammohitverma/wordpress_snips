import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";

import Header from "./Components/Global/Header";
import Footer from "./Components/Global/Footer";

import Home from "./Components/Pages/Home";
import About from "./Components/Pages/About";
import Blog from "./Components/Pages/Blog";
import SinglePost from "./Components/Pages/SinglePost";
import Contact from "./Components/Pages/Contact";
import Login from "./Components/Pages/Login";
import Logout from "./Components/Pages/Logout";
import Signup from "./Components/Pages/Signup";
import Error from "./Components/Pages/Error";

import "./App.css";

function App() {
  const [isLogin, setIsLogin] = useState(localStorage.getItem("token"));
  const [loggedInUserName, setLoggedInUserName] = useState(
    localStorage.getItem("user_nicename")
  );

  return (
    <>
      <Header isLogin={isLogin} loggedInUserName={loggedInUserName} />

      <div className="wrapper">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<SinglePost />} />
          <Route path="/contact" element={<Contact />} />
          <Route
            path="/login"
            element={
              <Login
                setIsLogin={setIsLogin}
                setLoggedInUserName={setLoggedInUserName}
              />
            }
          />
          <Route path="/logout" element={<Logout setIsLogin={setIsLogin} />} />
          <Route path="/signup" element={<Signup isLogin={isLogin} />} />
          <Route path="*" element={<Error />} />
        </Routes>
      </div>

      <Footer />
    </>
  );
}
export default App;
