 <?php
/*
Template Name: Program/Wilderness Playgroup
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if (have_rows('wilderness_playgroup_page_section')) :
    while (have_rows('wilderness_playgroup_page_section')) : the_row();

        if (get_row_layout() == 'banner_section') : ?>
            <section class="our_difference_newbanner cmn_new_banner bg_lightpnk">
                <div class="container-fluid px-0">
                    <div class="banner_main">
                        <?php
                        $parent_pageId = wp_get_post_parent_id(get_the_ID());
                        $parent_page = get_the_title($parent_pageId);
                        $parent_page_url = get_the_permalink($parent_pageId);
                        $page_title = $wp_query->post->post_title;
                        ?>
                        <div class="container">
                            <div class="breadcrumbs">
                                <ul>
                                    <?php if ($parent_pageId != 0) { ?>
                                        <li>
                                            <a href="<?php echo $parent_page_url; ?>"><?php echo $parent_page; ?></a>
                                        </li>
                                    <?php } ?>
                                    <li>
                                        <a href="javascript:void(0)" class="active"><?php echo $page_title; ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <?php
                        $banner_heading = get_sub_field('banner_heading');
                        $banner_desc = get_sub_field('banner_description');
                        $banner_img = get_sub_field('banner_image');
                        ?>
                        <div class="banner_content_wrap">
                            <div class="row">
                                <div class="col-lg-5 col-md-5 col-sm-12 col-12">
                                    <div class="left_main">

                                        <div class="left_img">
                                        <?php /* src="<?php echo $banner_img['url']; ?>">*/ ?>
                                        <div class="clipPathBox" style="--clipImageBG: url(<?php echo $banner_img['url']; ?>)"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                                    <div class="banner_content_inner">
                                        <div class="right_cont">
                                            <h2 class="banner_mainheading sec_title_90"><?php echo $banner_heading; ?></h2>
                                            <p> <?php echo $banner_desc; ?></p>
                                        </div>
                                        <div class="banner_links">
                                            <?php get_template_part('template-parts/sections/banner_links'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Common banner secion inner pages  -->
        <?php
        elseif (get_row_layout() == 'why_this_program_section') :
        ?>
            <!-- Section 01 Inner program heading -->
            <section class="inner_program_hdng new hex">
                <div class="container">
                    <div class="row align-items-center">
                        <?php
                        $why_this_heading = get_sub_field('left_heading');
                        $why_this_section = get_sub_field('content');
                        $why_this_section_link = get_sub_field('link');
                        $why_this_section_image = get_sub_field('heading_image');
                        ?>
                        <div class="col-lg-4">
                            <div class="left">
                                <img src="<?php echo $why_this_section_image['url']; ?>" alt="">
                                <h2><?php echo $why_this_heading; ?></h2>
                               <?php if($why_this_section_link) {?>
                                    <a href="<?php echo $why_this_section_link['url']; ?>" class="arrow_btn">
                                        <?php echo $why_this_section_link['title']; ?>
                                        <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E" />
                                        </svg>

                                    </a>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="col-12 col-sm-10 col-md-8 col-lg-8">
                            <div class="inner">
                                <p><?php echo $why_this_section; ?></p>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Section 01 Inner program heading -->
        <?php
        elseif (get_row_layout() == 'video_section') :
        ?>
            <!-- Section 02 Video Section -->
            <section class="single-video-sec hide_temp">
                <?php get_template_part('template-parts/sections/videos_section'); ?>
            </section>
            <!-- Section 02 Video Section -->
        <?php
        // Programs section  layout.
        elseif (get_row_layout() == 'programs_section') :
        ?>
            <!-- Section 03 start-->
            <?php $page_title = sanitize_title_with_dashes(get_the_title()); ?>
            <div class="program_list_loop_wrapper inner_program_list w_pgrp newchng <?php echo $page_title; ?>">

                <?php if (have_rows('programs')) : ?>
                    <?php while (have_rows('programs')) : the_row();
                        $program_heading = get_sub_field('program_heading');
                        $program_image = get_sub_field('program_image');
                        $program_description = get_sub_field('program_description');
						$program_link = get_sub_field("program_link");
						$additional_description = get_sub_field("additional_description");
                    ?>
                        <section class="join_us programList">
                            <div class="container">
                                <div class="row flex-md-row-reverse flex-column">
                                    <div class="col-md-6 col-lg-6 my-2 my-md-0">
                                        <div class="inner pr-25">
                                            <img src="<?php echo $program_image['url']; ?>" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 d-flex align-items-center my-2 my-md-0">
                                        <div class="inner pl-25">
                                            <h4 class="hdng">
                                                <?php echo $program_heading; ?>
                                            </h4>
                                            <p>
                                                <?php echo $program_description; ?>
                                            </p>
                                        </div>
                                    </div>
									<?php if($additional_description){ ?>
									<div class="col-12 mt-md-4 mt-2 additional_text">
										 <div class="inner pl-25">
										<p class="w-100"><?php echo $additional_description; ?></p>
										<?php if($program_link){ 
										$link_target = $program_link['target'] ? $program_link['target'] : '_self';
											?>
										<a class="cmn_btn" href="<?php echo $program_link['url']; ?>" target="<?php echo $link_target; ?>"><?php echo $program_link['title']; ?></a>
										<?php  } ?>
									</div>
										</div>
									<?php } ?>
                                </div>
                            </div>
                        </section>
                <?php
                    endwhile;
                endif;
                ?>

            </div>
            <!-- Section 03 end-->
                <?php 
                    elseif (get_row_layout() == 'our_teachers_section') :
                        $teacher_section_heading = get_sub_field('section_heading');
                        $teachers_category = get_sub_field('teachers_category');
                ?>
            <!-- 04 Section our teachers start-->
            <section class="our_teachers">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="inner pl-25">
                                <h3 class="hdng">
                                <?php echo $teacher_section_heading; ?>
                                </h3>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="people_list">
                                <ul>
                                    <?php
                                    $args = array(
                                        'post_type' => 'our-people',
                                        'post_status' => 'publish',
                                        'posts_per_page' => 8,
                                        'people-category' => $teachers_category->slug, // category name

                                    );
                                    $arr_posts = new WP_Query($args);
                                    if ($arr_posts->have_posts()) :
                                        while ($arr_posts->have_posts()) :
                                            $arr_posts->the_post();
                                    ?>
                                            <li>
                                                <figure>
                                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                    <span class="read_more_popup">
                                                        Read More
                                                    </span>
                                                </figure>
                                                <div class="teacher_desc">
                                                    <h5 class="tchr_name"><?php the_title(); ?></h5>
                                                    <h6 class="tchr_post"><?php the_field('position'); ?></h6>
                                                </div>
                                                <!-- This code is just for appending in popup -->
                                                <div class="modalBody" style="display:none!important;opacity:0!important;">
                                                    <p><?php the_field('position'); ?></p>
                                                    <h3><?php the_title(); ?></h3>
                                                    <div class="about_peple row">
                                                        <div class="col-md-3">
                                                            <div class="wrapper">
                                                                <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                                <p>
                                                                    <?php the_field('qualification'); ?>
                                                                </p>
                                                                <span>
                                                                    <?php the_field('bpos'); ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-9">
                                                            <div class="people_blog">
                                                                <p>
                                                                    <?php the_content(); ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- This code is just for appending in popup -->
                                            </li>

                                    <?php
                                        endwhile;
                                    endif;
                                    wp_reset_postdata();
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- 04 Section our teachers end-->
            
            <?php
                elseif (get_row_layout() == 'register_section') :
            ?>
            <section class="term_session">
                <div class="container">
                    <?php
                        $register_heading = get_sub_field('heading');
                        $register_content = get_sub_field('content');
                        $register_button = get_sub_field('button');
                        $information_button = get_sub_field('information_button');
                        $prospectus = get_sub_field('prospectus');
                    ?>
                    <div class="row align-items-center">
                        <div class="col-lg-5">
                            <div class="term_lft">
                                <h2> <?php echo $register_heading; ?></h2>
                                <h6><?php echo $register_content; ?></h6>
                                <a href="<?php echo $register_button['url']; ?>" class="only_btn">
                                    <?php echo $register_button['title']; ?>
                                </a>
                                <div class="session_prospect">
                                    <div class="bottomlk">      
                                        <p>view playgroup information sheet       
                                                <a href="<?php echo $information_button['url']; ?>" class="arrow_btn">
                                                    <?php echo $information_button['title']; ?>
                                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p>or download the        
                                                <a href="<?php echo $prospectus['url']; ?>" class="arrow_btn">
                                                    <?php echo $prospectus['title']; ?>
                                                    <svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.0974 0.642781L9.57856 8.60869L8.33331 8.49943C8.55644 6.00427 8.93665 3.46203 9.23815 1.80861L9.13607 1.75361C8.07816 2.98061 6.334 4.82655 4.83337 6.34271L1.37641 9.83547L0.520659 8.98849L3.97762 5.49573C5.47825 3.97957 7.31543 2.2257 8.53147 1.1552L8.47542 1.05369C6.77432 1.37709 4.28226 1.75547 1.78033 2.01359L1.686 0.769387L9.63234 0.182466L10.0974 0.642781Z" fill="#1E1E1E"></path>
                                                    </svg>
                                                </a>
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="rght_img">
                                <img src="/wp-content/uploads/2023/09/MacBook-Pro-14_-43-1.png">
                            </div>
                        </div>
                    </div>
                </div>

            </section>



        <?php
        elseif (get_row_layout() == 'message_section') :
        ?>
            <!-- 06 Section testimonials start-->
            <section class="testimonials_single bg_drkgrey">
                <?php get_template_part('template-parts/sections/single_testimonial'); ?>
            </section>
            <!-- 06 Section testimonials end-->

            <!----------------  View Other program Section Start------------------------------>
        <?php
        elseif (get_row_layout() == 'shapes_section') :
         $shape_heading = get_sub_field('section_heading');
        ?>
            <section class="shapes_in">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="innershapes_main">
                                <h3 class="hdng">
                                    <?php echo $shape_heading; ?>
                                </h3>
                                <div class="inner shapes_btn">
                                    <?php
                                    // check if the nested repeater field has rows of data
                                    if (have_rows('shapes')) :
                                    ?>
                                        <ul>
                                            <?php
                                            while (have_rows('shapes')) : the_row();
                                                $link = get_sub_field('shape');
                                                if ($link) :
                                                    $link_url = $link['url'];
                                                    $link_title = $link['title'];
                                            ?>
                                                    <li>
                                                        <a class="button" href="<?php echo esc_url($link_url); ?>"><?php echo esc_html($link_title); ?></a>
                                                    <?php endif; ?>
                                                    </li>
                                                <?php endwhile; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
            <!----------------  View Other program Section End------------------------------>

        <?php
        elseif (get_row_layout() == 'join_us_section') :
        ?>
            <!-- 07 Section join us start-->
            <section class="join_us program_inner">
                <?php get_template_part('template-parts/sections/join_us'); ?>
            </section>
            <!-- 07 Section join us end-->
            <!-- Section 08 Apply Now Start -->
        <?php elseif (get_row_layout() == 'apply_now_section') : ?>
            <!-- Questions start-->
            <section class="questions_sec">
                <?php get_template_part('template-parts/sections/apply_now'); ?>
            </section>
            <!-- Section 08 Apply Now End -->
            <!-- Questions end-->

        <?php endif; ?>
    <?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template 
?>

<section class="popupWrapper">
    <div class="people_popup">
        <div class="cross">
            <svg width="33" height="25" viewBox="0 0 33 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                <line x1="4.37339" y1="24.2079" x2="27.7079" y2="0.873338" stroke="#1E1E1E" stroke-width="1.3" />
                <line x1="5.29263" y1="0.8729" x2="28.6272" y2="24.2074" stroke="#1E1E1E" stroke-width="1.3" />
            </svg>
        </div>

        <!--- moday body start --->
        <div id="appendCntnt">
            <div class="modayBody">
                <p>PEDAGOGISTA</p>
                <h3>Nicole Hunter</h3>
                <div class="about_peple row">
                    <div class="col-md-3">
                        <div class="wrapper">
                            <img src="/wp-content/uploads/2023/05/Nicole-hunter.png" alt="">
                            <p>QUALIFICATIONS: <br> Bachelor of ScienceGraduate Diplomas in Education (Science and Early
                                Childhood)Masters of Education
                            </p>
                            <span>AT BPCS SINCE:
                                2004</span>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="people_blog">
                            <p>Nicole fervently believes that quality early life relationships, experiences and
                                education are critical in providing a solid foundation for healthy life patterns and
                                continuous learning. Nicole has both contributed
                                to and experienced the growth of Bold Park Community School as a parent, teacher and
                                board member; first joining the community in 2001, when the school was a one-room
                                primary school! She became part of the Early
                                Childhood teaching team in 2004.
                                <br> From 2008 until 2015 Nicole was Early Childhood Co-Team Leader with the
                                responsibility of expanding the outdoor learning program and National Quality Standards.
                                In 2016 Nicole was appointed to the role of Pedagogista.
                                This role sees her working, in collaboration, with the teaching teams and leadership to
                                align the principles, practices and philosophy of Bold Park with current educational
                                research and translate these into the
                                daily experience of students and families. <br> To this role, Nicole draws not only her
                                many years of experience in the Bold Park context, but also her teaching experience in a
                                breadth of contexts including high
                                school science and early years learning. Nicole is grateful to have had the opportunity
                                to travel internationally to visit educational contexts of Reggio Emilia and has
                                recently completed her Master’s of Education
                                in Teaching and Learning.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--- moday body start --->
    </div>
</section> 