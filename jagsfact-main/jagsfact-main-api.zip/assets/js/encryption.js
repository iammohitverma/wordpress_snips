const encryptionMap = {
  A: "𐊀",
  B: "𐊁",
  C: "𐊂",
  D: "𐊃",
  E: "𐊄",
  F: "𐊅",
  G: "𐊆",
  H: "𐊇",
  I: "𐊈",
  J: "𐊉",
  K: "𐊊",
  L: "𐊋",
  M: "𐊌",
  N: "𐊍",
  O: "𐊎",
  P: "𐊏",
  Q: "𐊐",
  R: "𐊑",
  S: "𐊒",
  T: "𐊓",
  U: "𐊔",
  V: "𐊕",
  W: "𐊖",
  X: "𐊗",
  Y: "𐊘",
  Z: "𐊙",
  0: "⊙",
  1: "─",
  2: "╲",
  3: "╱",
  4: "∠",
  5: "╳",
  6: "◊",
  7: "═",
  8: "●",
  9: "↗",
};

const decryptionMap = Object.fromEntries(
  Object.entries(encryptionMap).map(([key, value]) => [value, key])
);

// Encrypt message
document.getElementById("encryptButton").addEventListener("click", () => {
  const inputMessage = document
    .getElementById("messageInput")
    .value.toUpperCase();
  let encryptedMessage = "";

  for (let char of inputMessage) {
    encryptedMessage += encryptionMap[char] || char;
  }

  document.getElementById("encryptedOutput").value = encryptedMessage;
  copyUrlBtn.style.display = "block";
});

// by mohit - Fixed & Optimized
const GITHUB_TOKEN = "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"; // Replace with your token
const OWNER = "testhardeep001";
const REPO = "jagsfactapi";
const FILE_PATH = "encryptedData.json"; // Store encrypted data here
const API_URL = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${FILE_PATH}`;

async function saveEncryptedData(encryptedText) {
  try {
    // Fetch existing file data
    let response = await fetch(API_URL, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json",
      },
    });

    let fileData = await response.json();
    let existingContent = "{}"; // Default JSON object
    let sha = null;

    if (response.ok) {
      existingContent = fileData.content ? atob(fileData.content) : "{}"; // Decode Base64
      sha = fileData.sha; // Get SHA if file exists
    } else if (response.status === 404) {
      console.log("File does not exist. Creating a new one.");
    } else {
      throw new Error(`GitHub API Error: ${fileData.message}`);
    }

    let data = {};
    try {
      data = JSON.parse(existingContent); // Parse JSON
      if (typeof data !== "object" || Array.isArray(data)) {
        data = {}; // Reset if it's not a valid object
      }
    } catch (e) {
      console.warn("Failed to parse JSON, initializing new object.");
      data = {};
    }

    // Generate unique ID and save encrypted data
    let id = Date.now().toString(36);
    data[id] = encryptedText;

    // Convert updated data to Base64
    let updatedContent = btoa(JSON.stringify(data, null, 2));

    let updateFile = {
      message: sha ? "Updated encrypted data" : "Created encrypted data file",
      content: updatedContent,
      sha: sha || undefined, // Only include SHA if updating
    };

    // Upload to GitHub
    let updateResponse = await fetch(API_URL, {
      method: "PUT",
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updateFile),
    });

    let updateResult = await updateResponse.json();
    if (!updateResponse.ok) {
      throw new Error(`GitHub API Update Error: ${updateResult.message}`);
    }

    console.log("Data saved successfully:", updateResult);
    return id;
  } catch (error) {
    console.error("Error saving encrypted data:", error);
  }
}

// Ensure the button exists before adding an event listener
const copyUrlBtn = document.getElementById("copyUrlBtn");
const copyField = document.getElementById("copyField");
const encryptedOutput = document.getElementById("encryptedOutput");

if (copyUrlBtn && copyField && encryptedOutput) {
  copyUrlBtn.addEventListener("click", async function () {
    let encryptedText = encodeURIComponent(encryptedOutput.value);
    let id = await saveEncryptedData(encryptedText); // Save to GitHub and get ID

    if (id) {
      copyField.value = `${window.location.origin}/decryption.html?id=${id}`; // Share only the ID
      copyField.select();
      document.execCommand("copy");
      alert("Copied!\nShare with your friend:\n\n" + copyField.value);
    }
  });
} else {
  console.error(
    "Error: One or more elements (copyUrlBtn, copyField, encryptedOutput) are missing."
  );
}
