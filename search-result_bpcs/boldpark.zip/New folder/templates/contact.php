<?php 
/*
Template Name: Contact Page
*/

get_header(); // Load the header template

?>

<!-- Common banner secion inner pages  -->
<?php if( have_rows('contact_page_section') ): 
    while( have_rows('contact_page_section') ): the_row(); 
    if( get_row_layout() == 'banner_section' ): 
    ?>
<!--section class="app_process_banner bg_grey">
    <div class="banner_main">
        <?php  get_template_part( 'template-parts/sections/banner_inner_pages' );  ?>
    </div>
</section-->
<!-- Common banner secion inner pages  -->

<section class="our_difference_newbanner cmn_new_banner bg_camp">
    <div class="container-fluid px-0">
         <?php get_template_part('template-parts/sections/banner_inner_pages_new'); ?>
    </div>
    <img src="https://bpcs.tmdemo.in/wp-content/uploads/2023/09/cont_shape.png" alt="" class="cont_shape">
</section>
<?php
    // Have a question section  layout.
       // elseif( get_row_layout() == 'have_a_question' ): 
        
    ?>
<!-- 01 Section about Start-->
<section class="about_oD our_campus_about pt_extra">
    <?php //get_template_part( 'template-parts/sections/question_without_animation' ); ?>
</section>
<!-- 01 Section about end-->
<?php
    // Contact Form section  layout.
        elseif( get_row_layout() == 'form_section' ): 
        $contactheading = get_sub_field('heading');
        $contactformshortcode = get_sub_field('contact_form_shortcode');
?>
<!-- 02 Section form Start-->
<section class="contact_form">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                        <?php echo $contactheading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>

        <div class="row">
            <div class="col-12">
                <div class="inner pl-25 pr-25 py-5 bg_grey mt-5">
                 <?php echo do_shortcode($contactformshortcode); ?> 
                </div>
            </div>
        </div>
    </div>
</section>
<!-- 02 Section form end-->
<?php
    // reach us section  layout.
        elseif( get_row_layout() == 'reach_us_section' ): 
         $reach_ussectionheading = get_sub_field('section_heading');
         $reach_usdescription = get_sub_field('description');
         $reach_usphone_number = get_sub_field('phone_number');
         $reach_usfax = get_sub_field('fax');
         
                            
?>
<!-- 03 Section about difference Start-->
<section class="contact_detail">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                        <?php echo$reach_ussectionheading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>

        <div class="row address">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <p class="left_desc">
                        <?php echo$reach_usdescription; ?>
                    </p>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <p class="right_desc">
                        
                        P: <a href="tel:<?php echo$reach_usphone_number; ?>"><?php echo$reach_usphone_number; ?></a>  | F: <?php echo$reach_usfax; ?> <br/>
                        <?php if( have_rows('emails') ):
                        $count = 0;
                            while (have_rows('emails')) {
                                        the_row();
                                        if (get_sub_field('email')) {
                                            $count++;
                                        }
                                    }
                                    
                            $totalemail = 0;
                          ?>
                        E: 
                        <?php while ( have_rows('emails') ) : the_row(); 
                                    $reach_usemails = get_sub_field('email');
                                    if( $reach_usemails ): ?>
                                    <a href="mailto:<?php echo $reach_usemails;?>"><?php echo $reach_usemails;?></a>
                                    <?php if(($count-1)>$totalemail){echo" or ";} 
                                    endif; 
                                    $totalemail++;
                          endwhile; 
                            endif;
                        ?>
                          <br/> 
                             <?php if( have_rows('social_links') ):
                                $count = 0;
                                    while (have_rows('social_links')) {
                                            the_row();
                                            if (get_sub_field('social_link')) {
                                                $count++;
                                            }
                                        }
                                    
                            $totallink = 0;
                            ?>                          
                        stay connected on social media:
                         <?php while ( have_rows('social_links') ) : the_row(); 
                                    $social_link = get_sub_field('social_link');
                                    $social_label = get_sub_field('label');
                                    if( $social_link ): ?>
                                    <a href="<?php echo $social_link;?>"><?php echo $social_label;?></a>
                                    <?php if(($count-1)>$totallink){echo" | ";} 
                                    endif; 
                                    $totallink++;
                          endwhile; 
                            endif;
                        ?>
                    </p>
                </div>
            </div>  
        </div>
    </div>
</section>
<!-- 03 Section about difference end-->
<?php
    // reach us section  layout.
        elseif( get_row_layout() == 'location_section' ): 
         $locationsectionheading = get_sub_field('section_heading');                            
?>
<!-- 04 Section about difference Start-->
<section class="ourCampusList campusGrid pb-0 maps_section bg_grey">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 d-flex align-items-center">
                <div class="inner pl-25">
                    <h2 class="hdng">
                        <?php echo$locationsectionheading; ?>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 d-flex align-items-center mt-4 mt-md-0">
                <div class="inner">
                    <hr class="cmn_hr width_half">
                </div>
            </div>  
        </div>
        <div class="row mt-md-5 mt-2">
              <?php if( have_rows('locations') ): 
                while ( have_rows('locations') ) : the_row(); 
                                    $location_map_iframe = get_sub_field('map_iframe');
                                    $location_map_heading = get_sub_field('map_heading');
                                    $location_map_address = get_sub_field('map_address');
                      ?>
            <div class="col-12 col-md-6">
                <div class="row bottom">
                    <div class="col-12">
                    <?php  if( $location_map_iframe ): 
                          echo $location_map_iframe;
                    endif; 
                    if( $location_map_heading ): ?>
                        <h4 class="hdng pl-25">
                            <?php echo$location_map_heading; ?>
                        </h4>
                       <?php endif; 
                    if( $location_map_address ): ?>
                        <p class="pl-25">
                            <?php echo$location_map_address; ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php 
            endwhile; 
                 endif; ?>
        </div>
    </div>
</section>
<!-- 04 Section about difference end-->
<?php
elseif( get_row_layout() == 'question_section' ): 
?>
<!-- Questions start-->
<section class="questions_sec without_animation community">
<?php get_template_part( 'template-parts/sections/single_question' ); ?>
</section>
<!-- Questions end-->
<?php endif; ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); // Load the footer template ?>
