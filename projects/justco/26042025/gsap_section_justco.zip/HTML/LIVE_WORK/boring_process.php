<section class="boring_process">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-lg-6">
            <div class="left">
               <div class="boxed_style_text">
                  <div class="inner">
                     <div class="hdng_58">
                        <div>the</div>
                        <div>boring</div>
                        <div class="pt_serif">process</div>
                     </div>
                     <p>
                        we keep it easy. <br />
                        life’s tough, <br />
                        getting a boring office isn’t.
                     </p>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="right">
               <div class="list_wrap">
                  <ul>
                     <li>select your team size</li>
                     <li>choose your preferred location and office</li>
                     <li>add-ons for the office? or not. you do you.</li>
                     <li>pay and get onboarded. simple.</li>
                  </ul>
               </div>
               <div class="btn_wrap">
                  <a href="#" class="tbo_btn" style="--arrowImg: url('https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/top-right-arrow.svg')">customise</a>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>