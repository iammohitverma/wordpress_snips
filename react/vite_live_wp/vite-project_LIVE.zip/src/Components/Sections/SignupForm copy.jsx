import axios from "axios";
import React, { useState } from "react";

const baseUrl = import.meta.env.VITE_API_URL;

function SignupForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [fName, setFName] = useState("");
  const [lName, setLName] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const adminUsername = "admin";
    const appPassword = "jT9v 7kzH zzSD qcac hCO4 EUWU";

    const authString = btoa(`${adminUsername}:${appPassword}`);
    console.log(authString);

    try {
      await axios.post(
        `${baseUrl}/wp-json/wp/v2/users`,
        {
          username: name,
          email: email,
          first_name: fName,
          last_name: lName,
          password: password,
          roles: ["administrator"], // optional
          // roles: ["administrator"],
        },
        {
          headers: {
            Authorization: `Basic ${authString}`,
          },
        }
      );

      setMessage("Signup successful! ✅  Please login your account.");
    } catch (err) {
      console.log(err);
      setMessage("Signup failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-5">
      <div className="container">
        <div className="row">
          <div className="col-8 mx-auto">
            <div className="p-5 bg-body-tertiary rounded-3">
              <h2 className="text-center mb-3">Signup</h2>
              <form onSubmit={handleSignup} autoComplete="on">
                <div className="mb-3">
                  <label>Username</label>
                  <input
                    type="text"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label>Email</label>
                  <input
                    type="email"
                    className="form-control"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label>First Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={fName}
                    onChange={(e) => setFName(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label>Last Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={lName}
                    onChange={(e) => setLName(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label>Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                {loading && <p>Loading...</p>}
                {message && <p>{message}</p>}
                <button type="submit" className="btn btn-primary">
                  Signup
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default SignupForm; // <-- Export name v change kar ditta
