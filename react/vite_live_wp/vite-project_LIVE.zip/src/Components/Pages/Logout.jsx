import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

function Logout({ setIsLogin }) {
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.clear(); //  token clear
    setIsLogin(false); //  update parent state
    navigate("/login"); //  safely navigate after clearing
  }, []); // → sirf component mount te chalda

  return <p>Logging out...</p>; // optional UI
}

export default Logout;
