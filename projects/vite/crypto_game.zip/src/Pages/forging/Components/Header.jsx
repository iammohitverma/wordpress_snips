import React from "react";
import { NavLink } from 'react-router-dom';


function Header() {
    return (
        <>
            <div className='header_mv'>
                <div className='container_mv'>
                    <nav>
                        <ul>
                            <li>
                                <NavLink to="/">Main</NavLink>
                            </li>
                            <li>
                                <NavLink to="/Secondary">Secondary</NavLink>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </>
    )
}
export default Header;