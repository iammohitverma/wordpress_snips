//Header
let body = document.querySelector("body");
let site_header = document.querySelector(".site_header");
headerHeight = site_header.offsetHeight;
body.style.setProperty("--headerHeight", headerHeight + "px");

// sticky
const scrollFn = (e) => {
  if (window.scrollY > 10) {
    site_header.classList.add("sticky");
  } else {
    site_header.classList.remove("sticky");
  }
};
document.addEventListener("scroll", scrollFn);

// header toggle
let toggleMenuBtn = site_header.querySelector(".toggle_menu");

// toggle nav menu
toggleMenuBtn.onclick = (e) => {
  e.target.classList.toggle("active");
  site_header.classList.toggle("active");
  // body.classList.toggle("overflow-hidden");
  // body.classList.toggle("vh-100");
};

document.addEventListener("click", (e) => {
  if (
    !e.target.classList.contains("side_navigation") &&
    !e.target.classList.contains("toggle_menu")
  ) {
    toggleMenuBtn.classList.remove("active");
    site_header.classList.remove("active");
    // body.classList.remove("overflow-hidden");
    // body.classList.remove("vh-100");
  }
});

// Home Page Slider
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 1,
  effect: "fade",
  navigation: {
    nextEl: ".swiper_button_next",
    prevEl: ".swiper_button_prev",
  },
  loop: true,
  autoplay: {
    delay: 1500,
  },
  speed: 1500,
});

// initLightGallery
// function initLightGallery(options) {
//   const galleryItems = document.querySelectorAll(" .img_box");
//   galleryItems.forEach((item) => {
//     lightGallery(item, options);
//   });
// }

// function afterWindowLoad(event) {
//   initLightGallery({
//     selector: "a.img_card",
//     speed: 500,
//     mode: "lg-fade",
//     getCaptionFromTitleOrAlt: false,
//     download: false,
//     zoom: false,
//   });
// }
// window.addEventListener("load", afterWindowLoad);

function initLightGallery() {
  lightGallery(document.getElementById("gallary_container"));
}
function afterWindowLoad() {
  initLightGallery({
    speed: 500,
    mode: "lg-fade",
    zoom: true,
  });

  // team members
  const teamImagePopup = {
    selector: "a.img_card",
    speed: 500,
    mode: "lg-fade",
    download: false,
    zoom: false,
  };
  const teamItems = document.querySelectorAll(".team_section .img_box");
  teamItems.forEach((item) => {
    lightGallery(item, teamImagePopup);
  });
}
window.addEventListener("load", afterWindowLoad);
