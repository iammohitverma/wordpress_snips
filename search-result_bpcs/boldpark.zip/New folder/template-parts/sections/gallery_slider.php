<?php
/**
 * Template part for displaying Gallery Slider Section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

?>
<div class="inner">
        <div class="owl-carousel wrap_slider tm_image_slider">
            <?php $images = get_sub_field('gallery'); 
             if( $images ): 
                foreach($images as $image):?>
            <div class="items">
                <img src="<?php echo$image['url']; ?>" alt="">
            </div>
            <?php endforeach; 
            endif; ?>
        </div>
    </div>