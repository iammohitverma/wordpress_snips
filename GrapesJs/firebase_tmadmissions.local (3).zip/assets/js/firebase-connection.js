// [******** 🔥 Initialize firebase on loading 🔥 *******]
const firebaseConfig = {
  apiKey: "AIzaSyBnGSpyRgLPDE8mFxZqIHSKBuMBqbdtQL8",
  authDomain: "techmind-admissions.firebaseapp.com",
  databaseURL: "https://techmind-admissions-default-rtdb.firebaseio.com",
  projectId: "techmind-admissions",
  storageBucket: "techmind-admissions.firebasestorage.app",
  messagingSenderId: "543261559477",
  appId: "1:543261559477:web:7b3065735fc3ecaa4d0cfc",
};

// Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// const db = firebase.database();

firebase.initializeApp(firebaseConfig);
const firebaseAuth = firebase.auth();
const firebaseDB = firebase.database();

window.firebase = firebase;
window.firebaseAuth = firebaseAuth;
window.firebaseDB = firebaseDB;
