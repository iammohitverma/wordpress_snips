<section class="boring_concept" style="background-color: #182f92">
      <div class="start_container">
        <div class="slide_row">
          <div class="slide">
            <div class="heading_area slide_mw_400">
              <h3>the boring <br /><span class="pt_serif">concept</span></h3>
              <p>
                just so you know, our offices cut differently. boring, butdamn
                good-looking. you’ll like us.
              </p>
            </div>
          </div>
          <div class="slide">
            <div class="img_box slide_mw_400 slide_mt_250 slide_mr_150">
              <img
                src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img.png"
                alt="Boring Concept"
              />
            </div>
          </div>
          <div class="slide">
            <div class="boxed_text v_1 slide_mw_400 slide_mt_50 slide_mr_150">
              <div class="inner">
                <h4><i>01</i></h4>
                <h3>no hidden fees, no surprises —</h3>
                <p>
                  just straightforward pricing, so you know exactly what you’re
                  getting.
                </p>
              </div>
            </div>
          </div>
          <div class="slide">
            <div class="img_box slide_mw_800 slide_mt_50 slide_mr_150">
              <img
                src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img2.png"
                alt="Boring Concept"
              />
            </div>
          </div>
          <div class="slide">
            <div class="boxed_text v_2 slide_mw_400 slide_mt_100 slide_mr_20">
              <div class="inner">
                <h4><i>02</i></h4>
                <h3>need something extra?</h3>
                <p>
                  add-ons let you customize your workspace without the upsell
                  nonsense.
                </p>
              </div>
            </div>
          </div>
          <div class="slide">
            <div class="img_box slide_mw_300 slide_mt_50 slide_mr_20">
              <img
                src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img3.png"
                alt="Boring Concept"
              />
            </div>
          </div>
          <div class="slide">
            <div class="img_box slide_mw_400 slide_mt_150 slide_mr_150">
              <img
                src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img4.png"
                alt="Boring Concept"
              />
            </div>
          </div>
          <div class="slide">
            <div class="boxed_text v_3 slide_mw_400 slide_mr_150">
              <div class="inner">
                <h4><i>03</i></h4>
                <h3>seamless tech that just works —</h3>
                <p>
                  no fuss, no learning curve, just the tools you need to get
                  things done. all fully autonomous. introverts, rejoice!
                </p>
              </div>
            </div>
          </div>
          <div class="slide">
            <div class="img_box slide_mw_300 slide_mt_250 slide_mr_20">
              <img
                src="https://www.justcoglobal.com/theboringoffice/wp-content/uploads/2025/04/boring_concept_img3.png"
                alt="Boring Concept"
              />
            </div>
          </div>
          <div class="slide">
            <div class="boxed_text slide_mw_400 slide_mt_100 slide_mr_150">
              <div class="inner">
                <h4><i>04</i></h4>
                <h3>private offices, no shared spaces.</h3>
                <p>
                  complete privacy. total security. just you, your own space,
                  and no one messing with your flow.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>