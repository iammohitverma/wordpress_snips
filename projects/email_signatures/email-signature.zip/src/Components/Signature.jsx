import { useState } from "react";

// all expert's components
import { Matthew } from "./Experts/Matthew";
import { Stacey } from "./Experts/Stacey";
import { Ben } from "./Experts/Ben";
import { Becky } from "./Experts/Becky";
import { Anthony } from "./Experts/Anthony";

// Signature css
import "../assets/css/signature.css";

export const Signature = () => {
  // Function to copy the table content to clipboard
  const copyFunction = () => {
    // Get the HTML content of the table
    const tableContent = document.querySelector(".table_wrap table").outerHTML;

    // Create a temporary div element to hold the HTML content
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = tableContent;

    // Append the div to the body (it needs to be in the DOM to be copied)
    document.body.appendChild(tempDiv);

    // Select the content
    const range = document.createRange();
    range.selectNode(tempDiv);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    // Copy the selected content
    try {
      document.execCommand("copy");
      alert("Email signature copied to clipboard!");
    } catch (err) {
      console.error("Failed to copy: ", err);
    }

    // Clean up by removing the temporary div
    document.body.removeChild(tempDiv);
  };

  const [expert, setExpert] = useState("matthew");

  const onHandleSelectChange = (event) => {
    setExpert(event.target.value);
  };

  const renderExpertSignature = () => {
    switch (expert) {
      case "matthew":
        return <Matthew />;
      case "stacey":
        return <Stacey />;
      case "ben":
        return <Ben />;
      case "becky":
        return <Becky />;
      case "anthony":
        return <Anthony />;
      default:
        return null;
    }
  };
  return (
    <>
      <header>
        <div className="container_okmg">
          <a
            href="https://www.cpadvisory.com.au/"
            className="logo"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/cpa-logo.svg"
              alt=""
            />
          </a>
        </div>
      </header>
      <section className="email_signature_wrap">
        <div className="container_okmg">
          <div className="form_wrap">
            <div className="head">
              <h1 className="signature_header">Email Signature</h1>
              <h2 className="signature_sub_header">
                Preview and Select Signature
              </h2>
              <p className="signature_description">
                Choose from the generated email signature options to view and
                select the one that best fits your needs.
              </p>
            </div>

            <form>
              <div className="input_control">
                <label htmlFor="experts">
                  Our Experts: Signature Preview Options
                </label>
                <select
                  name="experts"
                  id="experts"
                  onChange={(e) => onHandleSelectChange(e)}
                >
                  <option value="matthew">Matthew Hughes</option>
                  <option value="stacey">Stacey Billerwell</option>
                  <option value="ben">Ben Chamberlain</option>
                  <option value="anthony">Anthony Rizzacasa</option>
                  <option value="becky">Becky Hughes</option>
                </select>
              </div>
            </form>
          </div>
          <div className="inner">
            <div className="table_wrap">{renderExpertSignature()}</div>
          </div>

          <div className="copy_btn_wrap">
            <div className="container_okmg">
              <button className="copyBtn" onClick={copyFunction}>
                Copy email signature
              </button>
            </div>
          </div>
        </div>
      </section>
      <footer>
        <div className="container_okmg">
          <p>© 2024 Capital Property Advisory</p>
        </div>
      </footer>
    </>
  );
};
