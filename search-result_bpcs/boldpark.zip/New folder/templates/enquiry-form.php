<?php 
/*
Template Name: Enrolment/Enquiry Form
*/
get_header(); // Load the header template
?>
<?php if( have_rows('enquiry_page_section') ): ?>
    <?php while( have_rows('enquiry_page_section') ): the_row(); 

if( get_row_layout() == 'banner_section' ):
    $banner_heading = get_sub_field('banner_heading');
    $banner_desc = get_sub_field('banner_description');
    $banner_img = get_sub_field('image');
?>
<!-- Common banner secion inner pages  -->
<section class="app_process_banner bg_grey enquiry_form_banner">
    <div class="banner_main">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="banner_left">
                        <div class="banner_headings">
                            <h2 class="banner_mainheading sec_title_90"><?php echo$banner_heading; ?></h2>
                            <p>
                               <?php echo$banner_desc; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="banner_right">
                        <div class="center_image">
                            <img src="<?php echo $banner_img['url'];?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Common banner secion inner pages  -->
<?php 
endif;
endwhile;
endif;
 get_footer(); // Load the footer template ?>
