<!-- sirf video 2 column section -->
<?php
$Text_visual_duo = get_sub_field('both_side_visual');

if( have_rows('both_side_visual') ): while ( have_rows('both_side_visual') ) : the_row(); 

    if( have_rows('visual') ): while ( have_rows('visual') ) : the_row();       

        $left_side_visual = get_sub_field('left_side_visual');
        echo  $left_side_visual['video_featured_image']['url'];

    endwhile; endif;

endwhile; endif;

?>
<section class="two_column_video_layout pb_100" style="background-color:#fafbf7">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 mt-3">
                    <!-- video columns -->
                    <div class="two_elem">
                        <figure data-target-el="hide-show-toggle" data-video="http://52.64.249.237/wp-content/uploads/2024/04/test.mp4" class="mt-4">
                            <div class="hideElem">
                                <img src="http://52.64.249.237/wp-content/uploads/2024/04/for-educator-video-01.png" alt="" class="feat_img">
                            </div>
                        </figure>
                    
                        <div class="cntnt_wrap">
                            <h4 class="hdng">
                                What I wish teachers knew about FASD
                            </h4>
                            <p class="desc">
                                Opening address at the 2nd Australasian FASD Conference
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-6 mt-3">
                    <!-- video columns -->
                    <div class="two_elem">
                        <figure data-target-el="hide-show-toggle" data-video="http://52.64.249.237/wp-content/uploads/2024/04/test.mp4" class="mt-4">
                            <div class="hideElem">
                                <img src="http://52.64.249.237/wp-content/uploads/2024/04/for-educator-video-02.png" alt="" class="feat_img">
                            </div>
                        </figure>

                        <div class="cntnt_wrap">
                            <h4 class="hdng">
                                Michael and Lina's Story
                            </h4>
                            <p class="desc">
                                Opening address at the 2nd Australasian FASD Conference
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>