$(window).on("load", function () {
  let firebase = window.firebase;
  let firebaseAuth = window.firebaseAuth;

  // if user is not logged in redirect to login page
  firebase.auth().onAuthStateChanged((user) => {
    // Load existing saved content for this user (optional)
    // firebaseDB
    //   .ref("users/" + user.uid + "/builder_testing/projectData")
    //   .once("value")
    //   .then((snapshot) => {
    //     const data = snapshot.val();
    //     if (data && data.html) {
    //       // editor.setComponents(data.html);
    //       console.log(data);
    //     }
    //   });

    if (!user) {
      // User not logged in
      if (window.location.pathname !== "/builder_testing/login") {
        window.location.href = "/builder_testing/login";
      }
    } else {
      console.log("User is logged in:", user.email);
      // User is logged in
      if (window.location.pathname !== "/builder_testing/admin_dashboard") {
        window.location.href = "/builder_testing/admin_dashboard";
      }
    }
  });

  const form = document.querySelector(".popup_tm form");
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // user signin Google Firebase!🔥
    firebaseAuth
      .signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
        alert("Login successful!");
        window.location.href = "/builder_testing/admin_dashboard";
      })
      .catch((error) => {
        alert("Login failed: " + "Please enter valid credentials!");
        console.log("Login failed: " + error.message);
      });

    // // user created Google Firebase!🔥
    // firebaseAuth
    //   .createUserWithEmailAndPassword(email, password)
    //   .then((userCredential) => {
    //     alert("User registered successfully!");
    //     window.location.href = "/builder_testing/admin_dashboard";
    //   })
    //   .catch((error) => {
    //     alert("Signup Error: " + error.message);
    //   });
  });

  // builderCode
  if ($("body").find("#gjs").length == 1) {
    builderCode();
    $("body").addClass("builder_enabled");
  }

  // builderCode function here
  function builderCode() {
    const cssStyles = [
      "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css",
      "https://unpkg.com/splitting/dist/splitting.css",
      "https://unpkg.com/splitting/dist/splitting-cells.css",
      "https://unpkg.com/aos@next/dist/aos.css",
      "./assets/fonts/heebo/stylesheet.css",
      "./assets/fonts/roboto/stylesheet.css",
      "./assets/css/custom_style.css",
      "./assets/css/grapes_init.css",
    ];
    const jsScripts = [
      "https://code.jquery.com/jquery-3.7.1.min.js",
      "https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js",
      "https://unpkg.com/splitting/dist/splitting.min.js",
      "https://unpkg.com/aos@next/dist/aos.js",
      "./assets/js/custom_script.js",
    ];

    // const editor = grapesjs.init({
    //   container: "#gjs",
    //   fromElement: true, // This loads the existing HTML as editable components
    //   width: "100%",
    //   height: "100vh",
    //   storageManager: {
    //     id: "gjsdata-", // Prefix for localStorage keys
    //     type: "local", // Save to localStorage
    //     autosave: false, // Auto-save on changes
    //     autoload: false, // Load saved data on init
    //     stepsBeforeSave: 1, // Save after every change
    //   },
    //   plugins: ["gjs-blocks-basic"],
    //   pluginsOpts: {
    //     "gjs-blocks-basic": {},
    //   },
    //   canvas: {
    //     styles: cssStyles,
    //     scripts: jsScripts,
    //   },
    //   // Disable telemetry to avoid the 400 error
    //   telemetry: false,
    // });

    firebase
      .database()
      .ref("publicTemplate")
      .once("value")
      .then((snapshot) => {
        const data = snapshot.val();

        const editor = grapesjs.init({
          container: "#gjs",
          width: "100%",
          height: "100vh",
          fromElement: false, // important
          plugins: ["gjs-blocks-basic"],
          canvas: {
            styles: cssStyles,
            scripts: jsScripts,
          },
          telemetry: false,
        });

        editor.on("load", () => {
          // Defer content injection slightly
          setTimeout(() => {
            editor.setComponents(data.html);
            editor.setStyle(data.css);
            // Show loader
            const loader = document.querySelector(".preloader");
            if (loader) loader.classList.remove("show");
            if (loader) loader.classList.add("hide");

            const iframe = document.querySelector("#gjs iframe");
            //   console.log(iframe);

            if (!iframe) return;

            const iframeWindow = iframe.contentWindow;
            if (iframeWindow && iframeWindow.AOS) {
              iframeWindow.AOS.init({
                disable: true,
              });
            }

            const iframeDoc =
              iframe.contentDocument || iframe.contentWindow.document;

            // Example: select the <header> inside the iframe
            const header = iframeDoc.querySelector("header");

            if (header) {
              // Do something with the header
              // header.style.backgroundColor = "red"; // Example: change background
              // console.log("Header found inside iframe:", header);
            } else {
              // console.log("No <header> found inside iframe.");
            }
          }, 100);
        });

        // Add Save Template button ✅
        editor.Panels.addButton("options", [
          //   {
          //     id: "save-template",
          //     className: "fa fa-save",
          //     command: "save-template",
          //     attributes: { title: "Save Template" },
          //   },
          {
            id: "save-template",
            label: "Save", // 👈 This shows the text
            command: "save-template",
            attributes: { title: "Save Template" },
            // Optional: you can style it further using className
            className: "save-template-button", // Your custom class if needed
          },
        ]);

        // Save Template command
        editor.Commands.add("save-template", {
          run(editor, sender) {
            sender && sender.set("active", false);

            const html = editor.getHtml();
            const css = editor.getCss();

            const user = firebaseAuth.currentUser;

            if (!user) {
              alert("Please login first to save your changes!");
              return;
            }
            // Show loader
            const state_loader = document.querySelector(".state_loader");
            state_loader?.classList.add("show");
            state_loader?.classList.remove("hide");

            // Save to Firebase realtime database 💾
            // firebase
            //   .database()
            //   .ref("users/" + user.uid + "/builder_testing/projectData")
            //   .set({
            //     html: html,
            //     css: css,
            //   })
            //   .then(() => {
            //     alert("Your changes are successfully saved! 😀");
            //     if (state_loader) state_loader.classList.remove("show");
            //     if (state_loader) state_loader.classList.add("hide");
            //   })
            //   .catch((error) => {
            //     console.error("Error saving data:", error);
            //   });
            firebase
              .database()
              .ref("publicTemplate")
              .set({
                html: html,
                css: css,
                owner: user.uid,
              })
              .then(() => {
                alert("Your changes are successfully saved! 😀");
                if (state_loader) state_loader.classList.remove("show");
                if (state_loader) state_loader.classList.add("hide");
              })
              .catch((error) => {
                console.error("Error saving data:", error);
              });
          },
        });

        // Logout button ✅
        editor.Panels.addButton("options", [
          {
            id: "logout-template",
            label: "Logout", // 👈 This shows the text
            command: "logout-template",
            attributes: { title: "Logout Template" },
            // Optional: you can style it further using className
            className: "logout-template-button", // Your custom class if needed
          },
        ]);

        // Logout button command
        editor.Commands.add("logout-template", {
          run(editor, sender) {
            sender && sender.set("active", false);

            firebaseAuth
              .signOut()
              .then(() => {
                alert("Logged out successfully!");
                if (window.location.pathname !== "/builder_testing/login") {
                  window.location.href = "/builder_testing/login";
                }
                // Reset your UI here, for example:
                // hide editor, show login form, clear editor content, etc.
              })
              .catch((error) => {
                alert("Logout failed: " + error.message);
              });
          },
        });
      });
  }
});
