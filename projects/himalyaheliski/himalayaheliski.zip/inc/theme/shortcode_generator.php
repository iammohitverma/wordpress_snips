<?php
// team_members_func
function team_members_func( $atts ) {
    $attributes = shortcode_atts( array(
        'limit' => 4
    ), $atts );

    ob_start();

    // include template with the arguments
    get_template_part( 'inc/shortcodes/team_members', null, array('attributes' => $attributes) );

    return ob_get_clean();
}
add_shortcode( 'team_members', 'team_members_func' );

