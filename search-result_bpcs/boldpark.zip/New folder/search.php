<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package boldpark-theme
 */

get_header();?>

<!-- include search result file -->
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>
<h1> Mohit </h1>

<?php include get_template_directory() . "/search-results.php"; ?>


<?php get_footer(); ?> 