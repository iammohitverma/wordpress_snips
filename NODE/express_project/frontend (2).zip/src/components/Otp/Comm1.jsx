import React, { useEffect, useState } from "react";
import { AiOutlineFire } from "react-icons/ai";
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axiosinstance from "../../api/axiosinstance";

export default function Comm1() {


    const [Otp, setOtp] = useState("");
    const [statusMessage, setStatusMessage] = useState("");
    const location = useLocation()
    const [email, setemail] = useState(location.state?.email || '')
    const navigate = useNavigate();
    useEffect(() => {
        if (!email) {
            navigate('/');
        }
    }, [email, navigate]);

    // Function placeholders for future backend integration
    const handleVerify = async (e) => {
        e.preventDefault();
        console.log('Verifying with email:', email, 'Otp:', Otp);

        try {
            const res = await axiosinstance.post('/api/auth/verify-otp', { email, Otp });
            console.log(res.data.message);
            setStatusMessage(res.data.message)
            // Navigate to dashboard with email passed as state
            localStorage.setItem('email', email);

            navigate('/home', { state: { email } });

        } catch (error) {
            console.error('Verification Failed:', error.response?.data?.message);
            setStatusMessage('Invalid or expired OTP. Please try again.');
        }
    };

    const handleBackToEmail = (e) => {
        e.preventDefault();
        navigate("/")
    };

    const handleSignUp = (e) => {
        e.preventDefault();
        // Add sign up navigation here
        set("Sign up clicked");
    };

    return (
        <div className="min-h-screen bg-[#fff6e9] flex flex-col items-center justify-start py-16 px-5">
            {/* Top Flame Icon */}
            <div className="mb-6 flex justify-center">
                <div className="mb-6">
                    <span className="text-6xl text-orange-600"><AiOutlineFire /></span>
                </div>
            </div>

            {/* Title */}
            <div className="text-center mb-8">
                <h1 className="text-lg font-extrabold text-black">
                    Candle Burn-Test Log
                </h1>
                <p className="text-sm text-gray-700 font-normal mt-1">
                    Professional candle testing made simple
                </p>
            </div>

            {/* Form Container */}
            <form
                onSubmit={handleVerify}
                className="bg-white rounded-lg shadow-lg w-full max-w-md p-6"
                noValidate
            >
                <h2 className="font-bold text-center text-base mb-1 text-black">
                    Welcome back
                </h2>
                <p className="text-center text-xs mb-6 text-black">
                    Enter the verification code sent to your email
                </p>

                {/* Input group with left icon */}
                <label
                    htmlFor="Otp"
                    className="block mb-1 text-xs font-semibold text-gray-700"
                >
                    Verification Code
                </label>
                <div className="relative mb-2">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg
                            className="w-5 h-5 text-gray-400"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                        >
                            <path d="M16 12H8m8 0a4 4 0 01-8 0 4 4 0 018 0z"></path>
                        </svg>
                    </span>
                    <input
                        id="verificationCode"
                        name="verificationCode"
                        type="text"
                        autoComplete="off"
                        placeholder="123456"
                        maxLength={6}
                        pattern="[0-9]*"
                        inputMode="numeric"
                        value={Otp}
                        onChange={(e) => setOtp(e.target.value)}
                        required
                        className="block w-full pl-10 pr-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#F7A766] focus:border-[#F7A766]"
                    />
                </div>

                {statusMessage}
                {/* Status message */}
                <div className="mb-5 rounded px-3 py-2 bg-green-100 text-green-800 text-xs inline-flex items-center gap-2">
                    <svg
                        className="w-4 h-4 flex-shrink-0"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                    >
                        <path d="M5 13l4 4L19 7"></path>
                    </svg>
                    OTP Successfully send to your email {email}
                </div>
                {/* Verify button with right icon */}
                <button
                    type="submit"
                    className="w-full bg-[#E3A870] hover:bg-[#d6975c] text-white rounded-md py-2 flex items-center justify-center gap-2 font-semibold transition-colors"
                    aria-label="Verify and Sign In"
                >
                    Verify &amp; Sign In
                    <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                    >
                        <path d="M5 12h14M12 5l7 7-7 7"></path>
                    </svg>
                </button>

                {/* Back to email */}
                <p
                    onClick={handleBackToEmail}
                    className="my-4 text-xs text-center cursor-pointer text-gray-700 hover:underline select-none"
                    tabIndex={0}
                    role="button"
                    onKeyDown={(e) => {
                        if (e.key === "Enter") handleBackToEmail(e);
                    }}
                >
                    <a href="/"> Back to email</a>
                </p>


            </form>
        </div>
    );
}

