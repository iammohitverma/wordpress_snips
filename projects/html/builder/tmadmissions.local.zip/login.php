<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>
    Admin Login
  </title>
  <link rel="icon" type="image/x-icon" href="./assets/images/favicon.ico" />

  <!-- bootstrap 5 -->
  <link rel="stylesheet" href="./assets/bootstrap-5.2.3-dist/css/bootstrap.min.css" />

  <!-- heebo font -->
  <link rel="stylesheet" href="./assets/fonts/heebo/stylesheet.css" />
  <!-- roboto font -->
  <link rel="stylesheet" href="./assets/fonts/roboto/stylesheet.css" />

  <!-- custom style -->
  <link rel="stylesheet" href="./assets/css/custom_style.css" />
</head>

<body>

  <!-- custom popup -->
  <div class="popup_tm active">
    <div class="popup_box">
      <!-- <button type="button" class="close btn-close"></button> -->
      <div class="popup_box_inner">
        <h4 class="text-center">Admin Login</h4>
        <form>
          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Submit</button>
        </form>
      </div>
    </div>
  </div>

  <!-- jQuery 3.7.1 -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

  <!-- grapes js builder init js -->
  <script src="./assets/js/grapes_init.js"></script>

</body>

</html>