document.addEventListener('DOMContentLoaded', function () {
    const selectBox = document.getElementById('plugin-selector');
    const selectedBox = document.getElementById('selected-plugins');
    const hiddenInput = document.getElementById('jn_disabled_plugins_input');
    const selectAllButton = document.getElementById('select-all-plugins');

    let selectedPlugins = new Set(hiddenInput.value.split(',').filter(Boolean));

    function renderTags() {
        selectedBox.innerHTML = '';
        selectedPlugins.forEach(path => {
            const option = selectBox.querySelector(`option[value="${path}"]`);
            const tag = document.createElement('span');
            tag.textContent = option ? option.textContent : path;
            tag.className = 'plugin-tag';
            tag.dataset.plugin = path;
            tag.addEventListener('click', () => {
                selectedPlugins.delete(path);
                updateHiddenInput();
                renderTags();
            });
            selectedBox.appendChild(tag);
        });
    }

    function updateHiddenInput() {
        hiddenInput.value = Array.from(selectedPlugins).join(',');
    }

    selectBox.addEventListener('change', () => {
        const selected = selectBox.value;
        if (selected && !selectedPlugins.has(selected)) {
            selectedPlugins.add(selected);
            updateHiddenInput();
            renderTags();
        }
    });

    // Select All Plugins Button
    selectAllButton.addEventListener('click', () => {
        const options = selectBox.querySelectorAll('option');
        options.forEach(opt => {
            const val = opt.value;
            if (val && !selectedPlugins.has(val)) {
                selectedPlugins.add(val);
            }
        });
        updateHiddenInput();
        renderTags();
    });

    renderTags();

    const removeAllButton = document.getElementById('remove-all-plugins');

    removeAllButton.addEventListener('click', () => {
        selectedPlugins.clear();
        updateHiddenInput();
        renderTags();
    });
});
