<?php
$section_heading = get_sub_field('section_heading'); 
echo $section_heading;
$fields = acf_get_fields('impairment_tabs_layout');
if ($fields) {
    $brain_description = get_field('brain_description');
    echo $brain_description;
}
 ?>
 <!-- banner without slider start-->
<section class="brain_impairment_sec">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="heading_with_icon mb_60">
                    <i>
                        <img src="http://52.64.249.237/wp-content/uploads/2024/04/info_icon.svg" alt="shape">
                    </i>    
                Click on one of the 10 neurodevelopmental domains involved in the diagnosis of FASD to find out more. </h2>
            </div>
        </div>

        <div class="tab_slider tabbing_enabled">
            <button class="control prev">
                <img src="http://52.64.249.237/wp-content/uploads/2024/04/tab_slider_prev.svg" alt="">
            </button>
            <button class="control next">
                <img src="http://52.64.249.237/wp-content/uploads/2024/04/tab_slider_next.svg" alt="">
            </button>
            <div class="items">
                <button class="active">Brain structure & Neurology</button>
                <button>Motor Skills</button>
                <button>Cognition</button>
                <button>Language</button>
                <button>Academic achievement</button>
            </div>
        </div>

        <div class="tab_content col_2">
            <div class="content_wrap active">
                <div class="row">
                    <div class="col-md-6">
                        <div class="img_wrap">
                            <img src="http://52.64.249.237/wp-content/uploads/2024/04/frontal_lobe.png" alt="tab-content-image">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="text_wrap">
                            <h4 class="heading">Brain structure and neurology includes:</h4>
                            <ul>
                                <li>Abnormal head circumference</li>
                                <li>Structural brain abnormalities</li>
                                <li>Seizure disorder not due to known postnatal causes</li>
                                <li>Significant neurological diagnoses otherwise unexplained</li>
                            </ul>
                            <h4 class="heading">How a person with FASD might be affected</h4>
                            <ul>
                                <li>A baby with FASD may be born with a head that is significantly smaller than a normal sized baby of the same gender and age</li>
                                <li>Children with microcephaly may have brains that have not have developed properly</li>
                                <li>Children with FASD may have seizures, vision or hearing problems or cerebral palsy</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content_wrap">
                <div class="row">
                    <div class="col-md-6">
                        <div class="img_wrap">
                            <img src="http://52.64.249.237/wp-content/uploads/2024/04/frontal_lobe.png" alt="tab-content-image">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="text_wrap">
                            <h4 class="heading">Motor Skills</h4>
                            <ul>
                                <li>Abnormal head circumference</li>
                                <li>Structural brain abnormalities</li>
                                <li>Seizure disorder not due to known postnatal causes</li>
                                <li>Significant neurological diagnoses otherwise unexplained</li>
                            </ul>
                            <h4 class="heading">How a person with FASD might be affected</h4>
                            <ul>
                                <li>A baby with FASD may be born with a head that is significantly smaller than a normal sized baby of the same gender and age</li>
                                <li>Children with microcephaly may have brains that have not have developed properly</li>
                                <li>Children with FASD may have seizures, vision or hearing problems or cerebral palsy</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="single_btn_wrap text-center mt_60">
            <a href="#" class="fasd_btn outline_btn" style="--btnClr:#BF4846">Learn about FASD</a>
        </div>
    </div>

    <!-- shapes for all corner | uncomment commented img tag-->
    <!-- <img src="http://52.64.249.237/wp-content/uploads/2024/04/sec_shape_lightblue_v3.svg" alt="shape" class="sec_shape top_right">
    <img src="http://52.64.249.237/wp-content/uploads/2024/04/circle_light_black.svg" alt="shape" class="sec_shape bottom_left"> -->
</section>
<!-- banner without slider end-->