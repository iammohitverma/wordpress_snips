export const ComC = ({ name, countUpdate }) => {
  return (
    <>
      <p>Com C {name}</p>
      <button onClick={() => countUpdate()}>Click me</button>
    </>
  );
};
