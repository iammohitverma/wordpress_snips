import { useState } from "react";
import ForgeItemsData from "./ForgeItemsData";
import ForgeComponentInfo from "./ForgeComponentInfo";

const ForgeTabs = () => {
    const [dataTab, setDataTab] = useState("main_hand");
    const handleTabChange = (e) => {
        setDataTab(e.target.dataset.item);
    }
    return (

        <div className="forge_items_tab">
            <div className="tab_buttons_wrap">
                <button className={dataTab == "main_hand" ? 'active' : ''} data-item="main_hand" onClick={handleTabChange}>Main Hand</button>
                <button className={dataTab == "off_hand" ? 'active' : ''} data-item="off_hand" onClick={handleTabChange}>Off Hand</button>
                <button className={dataTab == "armor" ? 'active' : ''} data-item="armor" onClick={handleTabChange}>Armor</button>
            </div>
            <div className="tab_content">
                <div className="content_inner">
                    <div className="forge_items">
                        {
                            ForgeItemsData[dataTab] && ForgeItemsData[dataTab].items ?
                                ForgeItemsData[dataTab].items.map((element, index) => {
                                    return (
                                        <button className="item" key={index}>
                                            <img
                                                src={element.itemImage}
                                                alt={`Item ${index + 1}`}
                                                className="forge-item-image"
                                            />
                                        </button>
                                    )
                                })
                                : <p className="not_found">No Data Found</p>
                        }
                    </div>
                    <div className="forge_item_details">
                        <div className="info left">
                            {
                                ForgeComponentInfo.left.info.map((element, index) => {
                                    return (
                                        <div className="info_row" key={index}>
                                            <span className='hdng'>
                                                <em>{element.display}</em>
                                            </span>
                                            <span className='textBlue'>{element.value}</span>
                                        </div>
                                    )
                                })
                            }
                        </div>

                        <div className="info right">
                            {
                                ForgeComponentInfo.right.info.map((element, index) => {
                                    return (
                                        <div className="info_row" key={index}>
                                            <span className='hdng'>
                                                <em>{element.display}</em>
                                            </span>
                                            <span className='textBlue'>{element.value}</span>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                    <div className="forge_component_btn_wrap">
                        <button className="forge_component_btn">
                            Forge Component Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ForgeTabs;