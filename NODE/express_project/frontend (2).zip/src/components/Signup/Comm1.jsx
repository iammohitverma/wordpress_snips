import React, { useEffect, useState } from "react";
import { AiOutlineFire } from "react-icons/ai";
import axiosinstance from "../../api/axiosinstance"
import { Link, useNavigate } from "react-router-dom";
const EmailIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M16 12l-4-4-4 4m8 0v6a2 2 0 002 2H6a2 2 0 002-2v-6"
        />
    </svg>
);

const UserIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M5.121 17.804A9 9 0 1118.88 6.196m-7.757 8.423a4 4 0 105.656-5.656 4 4 0 00-5.656 5.656z"
        />
    </svg>
);

const LockIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <rect width="14" height="10" x="5" y="11" rx="2" ry="2" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 11V7a4 4 0 10-8 0v4" />
    </svg>
);

const PhoneIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M3 10a7 7 0 0011.668 5.668L20 21l-4.332-5.668A7 7 0 013 10z"
        />
    </svg>
);

const FireIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8 text-orange-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 2C7 7 9 12 9 12a3 3 0 006 0s2-5-3-10z"
            fill="currentColor"
        />
    </svg>
);

const ArrowRightIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 ml-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
    >
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
);

export default function Comm1() {
      const navigate = useNavigate();
    const useremail = localStorage.getItem('email');
      useEffect(() => {
    
        if (useremail) {
          navigate("/home")
        }
      }, [useremail])
    

    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
        phone: "",
    });
    const [message, setmessage] = useState("")
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const validate = () => {
        const newErrors = {};
        if (!form.name.trim()) newErrors.name = "Name is required";
        if (!form.email.trim()) newErrors.email = "Email is required";
        else if (!/\S+@\S+\.\S+/.test(form.email)) newErrors.email = "Email is invalid";
        if (!form.password) newErrors.password = "Password is required";
        if (form.password !== form.confirmPassword)
            newErrors.confirmPassword = "Passwords do not match";
        if (!form.phone.trim()) newErrors.phone = "Phone is required";
        else if (!/^\+?[\d\s\-]{7,15}$/.test(form.phone)) newErrors.phone = "Phone is invalid";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        try {
            const response = await axiosinstance.post('/api/auth/signup', {
                email: form.email,
                password: form.password,
                name: form.name,
                phone: form.phone

            });
            console.log(response.data);
            setmessage(response.data.message)
        } catch (error) {
            console.error(error?.response?.data || error.message);
            setmessage(response.data.message)
        }
    };


    return (
        <div className="py-10 min-h-screen bg-orange-100 flex flex-col items-center justify-center px-4">
            <div className="mb-6 flex flex-col items-center space-y-2 select-none">
                <div className="mb-6">
                    <span className="text-6xl text-orange-600"><AiOutlineFire /></span>
                </div>
                <h1 className="font-bold text-2xl text-slate-900 tracking-wide select-text">
                    Candle Burn-Test Log
                </h1>
                <p className="text-slate-700 text-sm select-text">Professional candle testing made simple</p>
            </div>

            <form
                onSubmit={handleSubmit}
                className="bg-white rounded-lg shadow-md p-8 max-w-md w-full grid gap-5"
                noValidate
            >
                <h2 className="text-center text-lg font-semibold text-slate-900 mb-1">Create an Account</h2>
                <p className="text-center text-sm text-slate-600 mb-5">
                    Fill in the details below to sign up
                </p>

                {/* Name */}
                <label className="relative flex items-center border border-gray-300 rounded-md px-3 py-2 focus-within:border-orange-400 transition-colors">
                    <UserIcon />
                    <input
                        type="text"
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        placeholder="Full name"
                        className="pl-3 w-full outline-none placeholder:text-gray-400"
                        aria-invalid={errors.name ? "true" : "false"}
                        aria-describedby={errors.name ? "name-error" : undefined}
                        required
                    />
                </label>
                {errors.name && (
                    <p id="name-error" className="text-sm text-red-500 ml-1 -mt-3 mb-3">
                        {errors.name}
                    </p>
                )}

                {/* Email */}
                <label className="relative flex items-center border border-gray-300 rounded-md px-3 py-2 focus-within:border-orange-400 transition-colors">
                    <EmailIcon />
                    <input
                        type="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        className="pl-3 w-full outline-none placeholder:text-gray-400"
                        aria-invalid={errors.email ? "true" : "false"}
                        aria-describedby={errors.email ? "email-error" : undefined}
                        required
                    />
                </label>
                {errors.email && (
                    <p id="email-error" className="text-sm text-red-500 ml-1 -mt-3 mb-3">
                        {errors.email}
                    </p>
                )}

                {/* Password */}
                <label className="relative flex items-center border border-gray-300 rounded-md px-3 py-2 focus-within:border-orange-400 transition-colors">
                    <LockIcon />
                    <input
                        type="password"
                        name="password"
                        value={form.password}
                        onChange={handleChange}
                        placeholder="Password"
                        className="pl-3 w-full outline-none placeholder:text-gray-400"
                        aria-invalid={errors.password ? "true" : "false"}
                        aria-describedby={errors.password ? "password-error" : undefined}
                        required
                    />
                </label>
                {errors.password && (
                    <p id="password-error" className="text-sm text-red-500 ml-1 -mt-3 mb-3">
                        {errors.password}
                    </p>
                )}

                {/* Confirm Password */}
                <label className="relative flex items-center border border-gray-300 rounded-md px-3 py-2 focus-within:border-orange-400 transition-colors">
                    <LockIcon />
                    <input
                        type="password"
                        name="confirmPassword"
                        value={form.confirmPassword}
                        onChange={handleChange}
                        placeholder="Confirm password"
                        className="pl-3 w-full outline-none placeholder:text-gray-400"
                        aria-invalid={errors.confirmPassword ? "true" : "false"}
                        aria-describedby={errors.confirmPassword ? "confirmPassword-error" : undefined}
                        required
                    />
                </label>
                {errors.confirmPassword && (
                    <p id="confirmPassword-error" className="text-sm text-red-500 ml-1 -mt-3 mb-3">
                        {errors.confirmPassword}
                    </p>
                )}

                {/* Phone */}
                <label className="relative flex items-center border border-gray-300 rounded-md px-3 py-2 focus-within:border-orange-400 transition-colors">
                    <PhoneIcon />
                    <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="Phone number"
                        className="pl-3 w-full outline-none placeholder:text-gray-400"
                        aria-invalid={errors.phone ? "true" : "false"}
                        aria-describedby={errors.phone ? "phone-error" : undefined}
                        required
                    />
                </label>
                {errors.phone && (
                    <p id="phone-error" className="text-sm text-red-500 ml-1 -mt-3 mb-3">
                        {errors.phone}
                    </p>
                )}
                <p className="text-center">{message}</p>
                <button
                    type="submit"
                    aria-label="Sign up"
                    className="bg-orange-400 hover:bg-[#c78e53] transition-colors text-white rounded-md px-4 py-3 mt-3 font-semibold flex items-center justify-center"
                >
                    Sign Up
                    <ArrowRightIcon />
                </button>
            </form>
            <p className="text-sm mt-4 text-gray-600">
                Already have an account? <Link to={'/'} className=" text-orange-500 underline">Login</Link>
            </p>
            <p className="text-slate-700 text-xs mt-8 select-none">
                Secure passwordless authentication
            </p>
        </div>
    );
}

