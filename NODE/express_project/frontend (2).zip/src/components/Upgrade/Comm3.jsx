import React, { useState } from 'react';

const FAQItem = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b border-gray-300">
            <button
                className={`flex justify-between items-center w-full py-4 text-left text-lg font-semibold focus:outline-none transition ease-in-out duration-200 ${isOpen ? 'text-blue-600' : 'text-gray-800'}`}
                onClick={() => setIsOpen(!isOpen)}
            >
                <span>{question}</span>
                <span className={`transform transition duration-300 ${isOpen ? 'rotate-180' : ''}`}>
                    ▼
                </span>
            </button>
            {isOpen && (
                <div className="py-2 text-gray-600">
                    {answer}
                </div>
            )}
        </div>
    );
};

const Comm3 = () => {
    const faqs = [
        {
            question: "Can I cancel my subscription anytime?",
            answer: "Yes, you can cancel your subscription at any time. Your premium features will remain active until the end of your billing period."
        },
        {
            question: "What happens to my data if I downgrade?",
            answer: "Your existing burn tests and data will be preserved. You'll just be limited to the free plan features for new tests."
        },
        {
            question: "Do you offer annual billing?",
            answer: "We currently offer monthly billing. Annual billing options may be available in the future."
        }
    ];

    return (
        <div className="max-w-2xl mx-auto p-6 py-10 bg-white rounded-lg shadow-md mt-10">
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            {faqs.map((faq, index) => (
                <FAQItem key={index} question={faq.question} answer={faq.answer} />
            ))}
        </div>
    );
};

export default Comm3;
