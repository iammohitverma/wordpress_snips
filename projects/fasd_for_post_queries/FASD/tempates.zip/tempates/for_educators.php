<?php /* Template Name: Educators */
get_header();
?>

<div class="" id="singular-pages">

    <!-- this section is used on multiple pages | so please pass page name as a class also use inline background-color -->
    <section class="global_banner inner_pages" style="background-color:#BF4846">
        <div class="container">
            <div class="owl-carousel owl-theme" id="global_banner">
                <!-- use this "row" class for your repeater fields | loop  -->
                <div class="row d-flex justify-content-center align-items-center">
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <h1 class="hdng">
                                For Educators
                            </h1>
                            <p class="desc">
                                Our aim is to be the leading source of high quality, evidence-based content about
                                alcohol and pregnancy and FASD in Australia.
                            </p>
                            <a href="#" class="banner_btn" style="background-color:#dd6c69">
                                Learn about FASD
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-sm-10 col-md-6 mt-4 mt-md-0">
                        <figure>
                            <img src="/wp-content/uploads/2024/04/educator_image-1.svg" alt="" class="hero_img">
                        </figure>
                    </div>
                </div>
                <div class="row d-flex justify-content-center align-items-center">
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <h1 class="hdng">
                                For Educators
                            </h1>
                            <p class="desc">
                                Our aim is to be the leading source of high quality, evidence-based content about
                                alcohol and pregnancy and FASD in Australia.
                            </p>
                            <a href="#" class="banner_btn" style="background-color:#dd6c69">
                                Learn about FASD
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-sm-10 col-md-6 mt-4 mt-md-0">
                        <figure>
                            <img src="/wp-content/uploads/2024/04/educator_image-1.svg" alt="" class="hero_img">
                        </figure>
                    </div>
                </div>
            </div>
        </div>

        <!-- shapes for all corner | uncomment commented img tag-->
        <!-- <img src="/wp-content/uploads/2024/04/banner-bottom-left-shape.png" alt="" class="top-left"> -->
        <img src="/wp-content/uploads/2024/04/educator_shape_tr-1.svg" alt="" class="top-right">
        <!-- <img src="/wp-content/uploads/2024/04/banner-top-right-shape.png" alt="" class="bottom-right"> -->
        <img src="/wp-content/uploads/2024/04/educator-banner-shape.png" alt="" class="bottom-left">
    </section>

    <section class="educators_can_do">
        <div class="educators_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="educators_content">
                            <div class="heading">
                                <h3>What educators<br>can do</h3>
                            </div>
                            <div class="description">
                                <p>
                                    Educators can raise concerns and work with health professionals to inform a
                                    diagnosis. Along with parents and carers, teachers play an important role describing
                                    what they see, identifying triggers that may stimulate a response and other factors
                                    that provide challenges. It is critically important that educators understand the
                                    strengths and difficulties of a child or young person with FASD and work in
                                    partnership with the family.<br><br>
                                    During the assessment process a teacher may be asked to complete some information
                                    about the child. Following a diagnosis, the health professionals will prepare a
                                    management plan. Parents are encouraged to share some of this report with the school
                                    to assist in coordinated strategies being implemented.<br><br>
                                    Children and young people with FASD benefit from targeted learning strategies. They
                                    may require explicit instruction to acquire skills that typically developing
                                    children would learn through observation or generalisation, often related to working
                                    memory and attention issues.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="educators_image">
                            <div class="image_wrap">
                                <!-- 
                                if there is video section please use these attributes in following figure tag | 
                                data-target-el="hide-show-toggle" data-video="https://www.youtube.com/embed/MLpWrANjFbI?autoplay=1&mute=1"
                            -->
                                <figure class="videoAayegi" data-target-el="hide-show-toggle"
                                    data-video="http://52.64.249.237/wp-content/uploads/2024/04/test.mp4">
                                    <div class="hideElem">
                                        <img src="/wp-content/uploads/2024/04/latest_news02.png" alt="educators image"
                                            class="feat_img" />
                                        <a class="link_arrow" href="#">
                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M1.88379 12.1163L12.1163 1.88379M12.1163 1.88379H3.74425M12.1163 1.88379V10.2559"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="learning_strategies">
        <div class="learning_strategies_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="learning_content">
                            <div class="heading">
                                <h3>Successful<br>learning strategies</h3>
                            </div>
                            <div class="image_wrap">
                                <img src="/wp-content/uploads/2024/04/learning_stretegies_image-1.svg"
                                    alt="learning stretegies image">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="learning_description">
                            <ul>
                                <li>Use visual & auditory cues</li>
                                <li>Use clear, simple instructions & tasks</li>
                                <li>Lots of repetition</li>
                                <li>Break tasks into small steps recognition that a complex task will be more difficult
                                    to complete as several domains of neurodevelopmental functioning may be required
                                </li>
                                <li>Hands on learning</li>
                                <li>Specifically designed group activities</li>
                                <li>Improve self-monitoring with use of devices such as mobile phone calendars and
                                    reminders</li>
                                <li>Use the Eight Magic Keys to underpin teaching and learning strategies: use concrete
                                    and simplified language, be consistent, use lots of repetition, keep a routine and
                                    structure to each day, provide lots of supervision</li>
                            </ul>
                        </div>
                        <div class="learning_button">
                            <a href="#" class="brdr_btn list_btn">Find resources for educators</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="learning_videos">
        <div class="learning_videos_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="video_left">
                            <div class="image_wrap">
                                <figure class="videoAayegi" data-target-el="hide-show-toggle"
                                    data-video="http://52.64.249.237/wp-content/uploads/2024/04/test.mp4">
                                    <div class="hideElem">
                                        <img src="/wp-content/uploads/2024/04/learning_video_img01.png" alt="image"
                                            class="feat_img" />
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="video_right">
                            <div class="image_wrap">
                                <figure class="videoAayegi" data-target-el="hide-show-toggle"
                                    data-video="http://52.64.249.237/wp-content/uploads/2024/04/test.mp4">
                                    <div class="hideElem">
                                        <img src="/wp-content/uploads/2024/04/learning_video_img02.png" alt="image"
                                            class="feat_img" />
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="colored_2_column_layout" style="background-color: #F4F5F1;">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-12 col-sm-10 col-md-6">
                    <div class="inner">
                        <h2 class="hdng" style="color: #292929">
                            Common difficulties and tips
                        </h2>
                        <p class="desc" style="color: #6D6D6D">
                            Ten domains of neurodevelopment (the brain's neurological pathways that influence
                            performance or functioning) are known to be affected by alcohol exposure in pregnancy. The
                            following information links those ten domains with common difficulties seen in people with
                            FASD and tips for helping to improve skills and manage daily activities.
                        </p>
                        <a href="#" class="brdr_btn black_btn">Find out more</a>
                    </div>
                </div>
                <div class="col-12 col-sm-10 col-md-6">
                    <div class="inner">
                        <img src="/wp-content/uploads/2024/04/about_intro_img.svg" alt="image">
                    </div>
                </div>
            </div>
        </div>

        <!-- shapes -->
        <img src="/wp-content/uploads/2024/04/dificulties_shape_br-1.svg" alt="" class="middle-right">
    </section>

    <section class="learning_strategies Education_department">
        <div class="learning_strategies_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="learning_content">
                            <div class="heading">
                                <h3>Education<br>Department<br>websites</h3>
                            </div>
                            <div class="image_wrap">
                                <img src="/wp-content/uploads/2024/04/learning_stretegies_image-1.svg"
                                    alt="learning stretegies image">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="learning_description">
                            <ul>
                                <h3 class="desc_heading">Australia</h3>
                                <li>Use visual & auditory cues</li>
                                <li>Use clear, simple instructions & tasks</li>
                                <li>Lots of repetition</li>
                                <li>Break tasks into small steps recognition that a complex task will be more difficult
                                    to complete as several domains of neurodevelopmental functioning may be required
                                </li>
                                <li>Hands on learning</li>
                                <li>Specifically designed group activities</li>
                                <li>Improve self-monitoring with use of devices such as mobile phone calendars and
                                    reminders</li>
                                <li>Use the Eight Magic Keys to underpin teaching and learning strategies: use concrete
                                    and simplified language, be consistent, use lots of repetition, keep a routine and
                                    structure to each day, provide lots of supervision</li>
                            </ul>
                            <ul>
                                <h3 class="desc_heading">New Zealand</h3>
                                <li>Students with learning support needs - New Zealand Ministry of Education</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="Learning_with_fasd" style="background-color: #F4F5F1;">
        <div class="colored_2_Row_wrap">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <h2 class="hdng" style="color: #292929">
                                Learning with FASD
                            </h2>
                            <p class="desc" style="color: #6D6D6D">
                                Learning with FASD is a new Australian Government Department of Health funded,
                                easy-to-access online portal housing evidence-based resources and tools to help
                                educators and the broader school community effectively understand and support students
                                with Fetal Alcohol Spectrum Disorder (FASD) in Australian primary schools.<br><br>
                                The portal is available at learningwithfasd.org.au and provides information for primary
                                school teachers and support staff on understanding FASD, implementing classroom
                                strategies to support learning, and advice on engaging with parents, caregivers, and
                                families of students with FASD.
                            </p>
                            <a href="#" class="brdr_btn black_btn">Visit Learning with FASD</a>
                        </div>
                    </div>
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <img src="/wp-content/uploads/2024/04/about_intro_img.svg" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="colored_2_Row_wrap">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <h2 class="hdng" style="color: #292929">
                                Learning with FASD
                            </h2>
                            <p class="desc" style="color: #6D6D6D">
                                Learning with FASD is a new Australian Government Department of Health funded,
                                easy-to-access online portal housing evidence-based resources and tools to help
                                educators and the broader school community effectively understand and support students
                                with Fetal Alcohol Spectrum Disorder (FASD) in Australian primary schools.<br><br>
                                The portal is available at learningwithfasd.org.au and provides information for primary
                                school teachers and support staff on understanding FASD, implementing classroom
                                strategies to support learning, and advice on engaging with parents, caregivers, and
                                families of students with FASD.
                            </p>
                            <a href="#" class="brdr_btn black_btn">Visit Learning with FASD</a>
                        </div>
                    </div>
                    <div class="col-12 col-sm-10 col-md-6">
                        <div class="inner">
                            <img src="/wp-content/uploads/2024/04/about_intro_img.svg" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- shapes -->
        <img src="/wp-content/uploads/2024/04/dificulties_shape_br-1.svg" alt="" class="middle-right">
    </section>

    <section class="educator_articles">
        <div class="educator_articles_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="article_heading">
                            <h3 class="hdng">Explore Educators Articles</h3>
                        </div>
                        <div class="article_btn">
                            <a href="#" class="brdr_btn black_btn">See Resources</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

<?php 
get_footer();
?>