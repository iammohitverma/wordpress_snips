<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Glass_Cage
 */

get_header();
?>
<div data-pageName="<?php echo get_the_title(); ?>" class="singular_page" id="page-<?php echo sanitize_title_with_dashes(get_the_title()); ?>">

<div style="height:400px"></div>

<section class="slider_sec img_slider d-none">
		 <!-- Swiper -->
		 <div class="swiper mySwiper">
			<div class="swiper-wrapper">
				<div class="swiper-slide">
					<div class="img_wrap">
						<img src="/wp-content/uploads/2025/04/home_hero.png" alt="">
					</div>
				</div>
				<div class="swiper-slide">
					<div class="img_wrap">
						<img src="/wp-content/uploads/2025/04/img_1.jpeg" alt="">
					</div>
				</div>
				<div class="swiper-slide">
					<div class="img_wrap">
						<img src="/wp-content/uploads/2025/04/home_hero.png" alt="">
					</div>
				</div>
				<div class="swiper-slide">
					<div class="img_wrap">
						<img src="/wp-content/uploads/2025/04/img_1.jpeg" alt="">
					</div>
				</div>
			</div>
			<div class="swiper_button_wrap">
				<button class="swiper_button swiper_button_next">
					<img src="<?php echo get_template_directory_uri(). '/assets/images/left_arrow.svg' ?>" alt="">
				</button>
				<button class="swiper_button swiper_button_prev">
					<img src="<?php echo get_template_directory_uri(). '/assets/images/right_arrow.svg' ?>" alt="">
				</button>
			</div>
		</div>

	</section>

</div>
<?php
get_footer();