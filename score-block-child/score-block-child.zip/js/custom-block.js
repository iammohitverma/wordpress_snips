jQuery(document).ready(function ($) {
  console.log("Custom block loaded");
});
