<?php
/**
 * Template part for displaying Apply Now
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */

$apply_heading = get_sub_field('heading');
$apply_desc = get_sub_field('description');
$apply_button = get_sub_field('button');
$apply_now_button = get_sub_field('apply_now_button');
?>
<div class="container">
    <div class="row">
        <div class="col-12 col-lg-5">
            <div class="inner">
                <h3 class="hdng sec_title_60">
                    <?php echo $apply_heading; ?>
                </h3>
            <?php echo $apply_desc;
              if($apply_button):
            ?>
                <a href="<?php echo $apply_button['url'];?>" class="cmn_btn"><?php echo $apply_button['title'];?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-12 col-lg-7">
            <div class="inner">
                <div class="tm-anim-wrap-v2 max_650">
                    <div class="box">
                    <?php if($apply_now_button): ?>
                        <a href="<?php echo $apply_now_button['url'];?>" class="btn"> <?php echo $apply_now_button['title'];?> </a>
                        <?php endif; ?>
                        <div class="shapes">
                            <span class="shape hexagon"></span>
                            <span class="shape square"></span>
                            <span class="shape rectangle"></span>
                            <span class="shape rectangle2"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>