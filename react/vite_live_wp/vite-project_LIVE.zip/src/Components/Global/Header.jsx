import { NavLink } from "react-router-dom";

function Header({ isLogin, loggedInUserName }) {
  return (
    <>
      <header className="p-3 border-bottom">
        <div className="container">
          <div className="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <NavLink
              to="/"
              className="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none"
            >
              <img src="/loader.gif" alt="" width={100} />
            </NavLink>

            <ul className="nav col-12 col-lg-auto ms-lg-auto mb-2 justify-content-center mb-md-0">
              <li>
                <NavLink to="/" className="nav-link px-2 link-dark">
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink to="/about" className="nav-link px-2 link-dark">
                  About
                </NavLink>
              </li>
              {/* <li>
                <NavLink to="/blog" className="nav-link px-2 link-dark">
                  Blog
                </NavLink>
              </li> */}
              <li>
                <NavLink to="/contact" className="nav-link px-2 link-dark">
                  Contact
                </NavLink>
              </li>
              {/* {isLogin ? (
                <>
                  <li>
                    <NavLink to="/logout" className="ms-5 btn btn-primary">
                      Logout
                    </NavLink>
                  </li>
                  <li>
                    <span className="ms-5 badge p-2 text-bg-secondary">
                      {loggedInUserName}
                    </span>
                  </li>
                </>
              ) : (
                <li>
                  <NavLink to="/login" className="ms-5 btn btn-primary">
                    Login
                  </NavLink>
                </li>
              )} */}
            </ul>
          </div>
        </div>
      </header>
    </>
  );
}
export default Header;
