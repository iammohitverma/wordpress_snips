import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const useFetchAcfData = (pageId, pageKey) => {
  const baseUrl = import.meta.env.VITE_API_URL;

  return useQuery({
    queryKey: ["acfData", pageId, pageKey],
    queryFn: async () => {
      const res = await axios.get(`${baseUrl}/wp-json/acf/v3/pages/${pageId}`);
      const json = res.data;
      if (json?.acf && Array.isArray(json.acf[pageKey])) {
        return json.acf[pageKey];
      } else {
        throw new Error("Flexible content not found or invalid format.");
      }
    },
    refetchInterval: 5000, // har 5 second me auto update (optional)
    staleTime: 0, // force refetch every time after interval
    cacheTime: 0, // optional: agar aap chahte ho ki data cache me bilkul na rahe
  });
};

export default useFetchAcfData;
