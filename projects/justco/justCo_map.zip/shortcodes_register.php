<?php

// custom office shortcode
function unboring_spaces_shortcode($atts)
{

    ob_start();

    get_template_part('/inc/tbo/shortcodes/customizable_offices');

    return ob_get_clean();

}
add_shortcode('customizable_offices', 'unboring_spaces_shortcode');

// the boring concept section shortcode
function boring_concept_func($atts)
{
    $attributes = shortcode_atts(array(
        'limit' => 4
    ), $atts);

    ob_start();

    // include template with the arguments
    get_template_part('inc/theme/gsap/boring_concept', null, array('attributes' => $attributes));

    return ob_get_clean();
}
add_shortcode('boring_concept', 'boring_concept_func');


// the boring process section shortcode
function boring_process_func($atts)
{
    $attributes = shortcode_atts(array(
        'limit' => 4
    ), $atts);

    ob_start();

    // include template with the arguments
    get_template_part('inc/theme/gsap/boring_process', null, array('attributes' => $attributes));

    return ob_get_clean();
}
add_shortcode('boring_process', 'boring_process_func');


// the boring addons section shortcode
function boring_addons_func($atts)
{
    $attributes = shortcode_atts(array(
        'limit' => 4
    ), $atts);

    ob_start();

    // include template with the arguments
    get_template_part('inc/theme/gsap/boring_addons', null, array('attributes' => $attributes));

    return ob_get_clean();
}
add_shortcode('boring_addons', 'boring_addons_func');



// mcdonald house image slider shortcode:-
function macdonald_house_galery($atts)
{

    ob_start();

    get_template_part('/inc/tbo/shortcodes/macdonald_house_slider');

    return ob_get_clean();

}
add_shortcode('macdonald_house', 'macdonald_house_galery');



// Render justco maps
function render_location_map($atts)
{
    // Default attributes
    $atts = shortcode_atts(array(
        'name' => '',
        'lat' => '',
        'lng' => '',
        'address' => '',
    ), $atts);

    // Prepare positions array with one position from lat/lng attributes
    $positions = array();

    if (!empty($atts['lat']) && !empty($atts['lng'])) {
        $positions[] = array(
            'lat' => $atts['lat'],
            'lng' => $atts['lng'],
            'name' => $atts['name'],
            'address' => $atts['address'],
        );
    }

    // If no position provided, fallback to 0,0
    if (empty($positions)) {
        $positions[] = array(
            'lat' => 0,
            'lng' => 0,
            'name' => 'Location',
            'address' => 'Address',
        );
    }

    ob_start();
    ?>
    <section class="location_map_section">
        <div id="map" style="max-width: 100%; height: 400px;width:400px"></div>
    </section>

    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDx4DPRPTmy8PiQUDzuvfGK3A_VUUmPcnw&callback=initMap&v=weekly">
        </script>

    <script>
        function initMap() {
            const positionsRaw = <?php echo json_encode($positions); ?>;
            // Convert lat/lng to numbers for all positions
            const positions = positionsRaw.map(pos => ({
                ...pos,
                lat: parseFloat(pos.lat),
                lng: parseFloat(pos.lng),
            }));


            const first = positions[0] || { lat: 0, lng: 0 };

            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 12,
                center: { lat: parseFloat(first.lat), lng: parseFloat(first.lng) },
                <?php if (!empty($atts['map_id'])): ?>
                                                mapId: "<?php echo esc_js($atts['map_id']); ?>",
                <?php endif ?>
            });

            positions.forEach(pos => {
                if (!pos.lat || !pos.lng) return;

                new google.maps.Marker({
                    map,
                    position: { lat: parseFloat(pos.lat), lng: parseFloat(pos.lng) },
                    title: pos.name || '',
                });
            });
            tabs_map(positions);
        }
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('location_map_tbo', 'render_location_map');

