const ForgeComponentInfo = {
    left: {
        info: [
            { display: "Class", value: "Artisan" },
            { display: "Type", value: "Class" },
            { display: "Component", value: "3" },
            { display: "Cost", value: "X Crypto" }
        ]
    },
    right: {
        info: [
            { display: "Duration", value: "X Days" },
            { display: "Fail Chance", value: "X %" },
            { display: "Luck Chance", value: "X %" }
        ]
    }
};
export default ForgeComponentInfo;
