

<?php
/*
Template Name: New 10th Year Anniversary Template by GSAP 
*/
get_header();
?>


<!-- preloader start -->
<div id="preloader">
  <h4>0%</h4>
</div> 

<main>


<?php
if( have_rows('anniversary_sections') ): ?>
   <?php // Loop through rows.
    while ( have_rows('anniversary_sections') ) : the_row(); 

    // Case: Beginning Section.
    if( get_row_layout() == 'tab_buttons' ): ?>
    
        <!-- tab buttons -->
        <div class="tab_head_tm">
            <div class="container_tm">
                <div class="tab_buttons_tm">
                    <?php
                    $is_first = true;
                    if (have_rows('tab_button')):
                        while (have_rows('tab_button')) : the_row();
                            $button = get_sub_field('button');
                            $buttonTitle = $button['title'];
                            $buttonData = get_sub_field('button_data');
                            $active_class = $is_first ? 'active' : '';
                            if ( $buttonTitle && $buttonData) {
                                ?>
                                <a href="javascript-void(0);" class="<?php echo $active_class; ?>" data-btn="<?php echo $buttonData; ?>" target="_self"><?php echo $buttonTitle; ?></a>
                                <?php
                            }
                            $is_first = false; 
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>
        </div>
        
    <?php endif; ?>
    <?php endwhile; ?>

<?php endif; ?>

<?php
// Check value exists.
if( have_rows('anniversary_sections') ): ?>
<div class="sections_area_wrap">
   <?php // Loop through rows.
    while ( have_rows('anniversary_sections') ) : the_row(); 

    // Case: Beginning Section.
    if( get_row_layout() == 'beginning_section' ): ?>
        <div class="sections_wrap active" id="beginning">
           <?php // Check rows exists.
            if( have_rows('beginning_content_block') ):
                $sec = 1;
            // Loop through rows.
            while( have_rows('beginning_content_block') ) : the_row();

            // Load sub field value.
            $beginning_content_one = get_sub_field('beginning_content_one');
            $beginning_content_two = get_sub_field('beginning_content_two'); ?>
            <section class="example_classname sec_<?php echo $sec; ?>">
                <div class="container_tm">
                    <div class="row_tm">
                        <div class="col_6_tm">
                        <div class="text_wrap">
                                    <?php echo $beginning_content_one; ?>
                                </div>
                        </div>
                        <div class="col_6_tm">
                                <?php
                                // Check rows exists.
                                if( have_rows('beginning_image_block') ): ?>
                                    <div class="img_area_wrap">
                                    <?php $x = 1;
                                    // Loop through rows.
                                    while( have_rows('beginning_image_block') ) : the_row();
                                
                                        // Load sub field value.
                                        $image = get_sub_field('image'); ?>
                                        <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img_<?php echo $x; ?>">
                                
                                   <?php // End loop.
                                        $x++;
                                    endwhile; ?>
                                    </div>
                                <?php // No value.
                                else :
                                    // Do something...
                                endif; 
                                ?>
                            
                            <!-- Right content when image not uploded:- -->
                            <?php if ($beginning_content_two != "") { ?>
                                <div class="text_wrap">
                                    <?php echo $beginning_content_two; ?>
                                </div>
                            <?php } ?>
                            
                        </div>
                    </div>
                </div>
            </section>

            <?php // End loop.
            $sec++;
            endwhile;

            // No value.
            else :
            // Do something...
            endif; ?>
        </div>

    <?php // Case: Journey Section.
    elseif( get_row_layout() == 'journey_section' ): ?>
        <div class="sections_wrap journey" id="journey">
           <?php // Check rows exists.
            if( have_rows('journey_content_block') ): 
                $sec = 1;
            // Loop through rows.
            while( have_rows('journey_content_block') ) : the_row();

            $journey_content_one = get_sub_field('journey_content_one');
            $journey_content_two = get_sub_field('journey_content_two'); ?>

            <section class="example_classname sec_<?php echo $sec; ?>">
                <div class="container_tm">
                    <div class="row_tm">
                        <div class="col_6_tm">
                            <div class="text_wrap">
                                <?php echo  $journey_content_one; ?>
                            </div>
                        </div>
                        <div class="col_6_tm">
                            
                            <?php
                            // Check rows exists.
                            if( have_rows('journey_image_block') ): ?>
                                <div class="img_area_wrap">
                               <?php $x=1;
                            // Loop through rows.
                            while( have_rows('journey_image_block') ) : the_row();

                            // Load sub field value.
                            $image = get_sub_field('image'); ?>
                            <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img_<?php echo $x; ?>">

                            <?php // End loop.
                            $x++;
                            endwhile; ?>
                            </div>
                            <?php // No value.
                            else :
                            // Do something...
                            endif; ?>

                            <!-- Right content when image not uploded:- -->
                            <?php if ($journey_content_two != "") { ?>
                                <div class="text_wrap">
                                <?php echo $journey_content_two; ?>
                                </div>
                            <?php } ?>
                            
                        </div>
                    </div>
                </div>
            </section>

            <?php // End loop.
            $sec++;
            endwhile;

            // No value.
            else :
            // Do something...
            endif; ?>
            </div>

    <?php // Case: Ahead Section.
    elseif( get_row_layout() == 'ahead_section' ): ?>
        <div class="sections_wrap looking_ahead" id="looking_ahead">
            <?php // Check rows exists.
            if( have_rows('ahead_content_block') ):
                $sec=1;
            // Loop through rows.
            while( have_rows('ahead_content_block') ) : the_row();

            // Load sub field value.
            $ahead_content_one = get_sub_field('ahead_content_one');
            $ahead_content_two = get_sub_field('ahead_content_two'); ?>
            <section class="example_classname sec_<?php echo $sec;?>">
            <div class="container_tm">
                <div class="row_tm">
                    <div class="col_6_tm">
                        <div class="text_wrap">
                            <?php echo $ahead_content_one; ?>
                        </div>
                    </div>
                    <div class="col_6_tm">
                        <?php
                            // Check rows exists.
                            if( have_rows('ahead_image_block') ): ?>
                                <div class="img_area_wrap">
                               <?php $x=1;
                            // Loop through rows.
                            while( have_rows('ahead_image_block') ) : the_row();

                            // Load sub field value.
                            $image = get_sub_field('image'); ?>
                            <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img_<?php echo $x; ?>">

                            <?php // End loop.
                            $x++;
                            endwhile; ?>
                            </div>
                           <?php // No value.
                            else :
                            // Do something...
                            endif; ?>

                        <!-- Right content when image not uploded:- -->
                        <?php if ($ahead_content_two != "") { ?>
                                <div class="text_wrap">
                                <?php echo $ahead_content_two; ?>
                                </div>
                            <?php } ?>
                    </div>
                </div>
            </div>
            </section>

           <?php // End loop.
           $sec++;
            endwhile;

            // No value.
            else :
                // Do something...
            endif; ?>
        </div> 
        
    <?php // Case: Ahead Section.
    elseif( get_row_layout() == 'decade_of_dnh' ):
        $Heading = get_sub_field('decade_heading');
        $Button = get_sub_field('decade_button'); ?>
        <div class="sections_wrap decadesofdNH" id="decadesofdNH">
            <section class="decade_section">
                <div class="container_tm">
                    <div class="heading_wrap">
                        <h3><?php echo $Heading; ?></h3>
                    </div>
                    <div class="images_wrap">
                        <div class="row_tm">
                        <?php
                        // Check rows exists.
                        if( have_rows('decade_image_block') ):
                            $x=1;
                        // Loop through rows.
                        while( have_rows('decade_image_block') ) : the_row();

                        // Load sub field value.
                        $image = get_sub_field('image');
                        $link = get_sub_field('link'); 
                        ?>
                        <div class="col_4_tm">
                            <div class="image_wrap">
                                <a href="<?php echo $link['url'];?>" target="<?php echo $link['target'];?>">
                                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img_<?php echo $x; ?>">
                                </a>
                            </div>
                        </div>

                        <?php // End loop.
                        $x++;
                        endwhile;

                        // No value.
                        else :
                        // Do something...
                        endif; ?>
                    
                        </div>
                    </div>
                    <div class="btn_wrap">
                        <?php if ($Button != "") { ?>
                            <a href="javascript:void(0)" class="start_again"> <?php echo esc_html( $Button['title'] ); ?> </a>
                       <?php } ?>
                        
                    </div>
                </div>
            </section>
        </div>
        <?php 
    endif;

    // End loop.
    endwhile;

// No value.
else : ?>
    </div>
<?php endif; ?>
        
</main>

<?php 
get_footer();
?>

<!--  jquery/3.7.1  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!--  GSAP  -->
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<!--  GSAP ScrollTrigger -->
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js"></script>
<!-- anime js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>
<!-- anniversary_script_tm -->
<script src="/wp-content/themes/divi-child/anniversary_script_tm.js?query=1.0"></script>