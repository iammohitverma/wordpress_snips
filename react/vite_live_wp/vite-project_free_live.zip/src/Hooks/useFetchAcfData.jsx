import axios from "axios";
import { useState, useEffect } from "react";

const useFetchAcfData = (pageId, pageKey) => {
  const [data, setData] = useState([]); // it’s an array now
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const baseUrl = import.meta.env.VITE_API_URL;
        const res = await axios.get(
          `${baseUrl}/wp-json/acf/v3/pages/${pageId}`
        );
        const json = res.data;

        if (json?.acf && Array.isArray(json.acf[pageKey])) {
          setData(json.acf[pageKey]);
        } else {
          setError("Flexible content not found or invalid format.");
        }
      } catch (err) {
        setError(err.message || "Something went wrong while fetching data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [pageId, pageKey]);

  return { acfData: data, loading, error };
};

export default useFetchAcfData;
