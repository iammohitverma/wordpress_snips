export const MasterSignature = ({ expertData }) => {
  return (
    <>
      <table width="600" align="start" cellSpacing="0" cellPadding="0">
        <tbody>
          <tr>
            <td>
              <table width="100%" align="start" cellSpacing="0" cellPadding="0">
                <tbody>
                  {/* HIDE header with code */}
                  <tr style={{ display: "block" }}>
                    <td>
                      <table
                        align="start"
                        width="600"
                        style={{
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                          backgroundColor: "#30526d",
                          borderRadius: "10px",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "200px",
                                // textAlign: "right",
                                padding: "20px 30px",
                                backgroundColor: "#30526d",
                                borderTopLeftRadius: "10px",
                                borderBottomLeftRadius: "10px",
                              }}
                            >
                              <img
                                src={expertData.expertImg}
                                alt=""
                                style={{
                                  width: "140px",
                                  minWidth: "140px",
                                  // height: "140px",
                                }}
                              />
                            </td>
                            <td
                              style={{
                                width: "400px",
                                verticalAlign: "middle",
                                padding: "20px 30px",
                                paddingLeft: "0px",
                                backgroundColor: "#30526d",
                                borderTopRightRadius: "10px",
                                borderBottomRightRadius: "10px",
                                color: "#ffffff",
                              }}
                            >
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "24px",
                                  fontWeight: "600",
                                  color: "#ffffff",
                                  textTransform: "uppercase",
                                  letterSpacing: "1px",
                                }}
                              >
                                {expertData.expertName}
                              </p>
                              <div>
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/bar_2.png"
                                  alt=""
                                  style={{
                                    width: "25px",
                                    verticalAlign: "middle",
                                  }}
                                />
                              </div>

                              {expertData.expertPositionSm && (
                                <>
                                  <p
                                    style={{
                                      fontFamily: "Roboto, sans-serif",
                                      fontSize: "10px",
                                      fontWeight: "400",
                                      color: "#fff",
                                      textTransform: "uppercase",
                                      letterSpacing: "2px",
                                      marginBottom: "5px",
                                    }}
                                  >
                                    {expertData.expertPositionSm}
                                  </p>
                                  <div
                                    style={{
                                      marginBottom: "5px",
                                    }}
                                  ></div>
                                </>
                              )}
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                  marginBottom: "3px",
                                }}
                              >
                                {expertData.expertPositionLgFirstRow}
                              </p>
                              <p
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  fontWeight: "400",
                                  color: "#fff",
                                  textTransform: "uppercase",
                                  letterSpacing: "2px",
                                }}
                              >
                                {expertData.expertPositionLgSecondRow}
                              </p>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  {/* SHOW header with image */}
                  <tr style={{ display: "none" }}>
                    <td>
                      <img
                        src={expertData.headerImage}
                        style={{ maxWidth: "100%", verticalAlign: "middle" }}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        // align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                width: "300px",
                                verticalAlign: "top",
                                padding: "20px 0 0 0px",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td>
                                      <table>
                                        <tbody>
                                          {expertData.expertContact && (
                                            <tr>
                                              <td width={30}>
                                                <p
                                                  style={{
                                                    fontFamily:
                                                      "Roboto, sans-serif",
                                                    fontSize: "14px",
                                                    fontWeight: "600",
                                                    color: "#ec6563",
                                                    textTransform: "uppercase",
                                                    letterSpacing: "1px",
                                                    marginBottom: "3px",
                                                    textDecoration: "none",
                                                    display: "inline-block",
                                                    paddingTop: "5px",
                                                  }}
                                                >
                                                  M:
                                                </p>
                                              </td>
                                              <td>
                                                <a
                                                  href={`tel: ${expertData.expertContact}`}
                                                  style={{
                                                    fontFamily:
                                                      "Roboto, sans-serif",
                                                    fontSize: "14px",
                                                    fontWeight: "600",
                                                    color: "#30526d",
                                                    textTransform: "uppercase",
                                                    letterSpacing: "1px",
                                                    marginBottom: "3px",
                                                    textDecoration: "none",
                                                    display: "inline-block",
                                                    paddingTop: "5px",
                                                  }}
                                                >
                                                  {expertData.expertContact}
                                                </a>
                                              </td>
                                            </tr>
                                          )}

                                          <tr>
                                            <td width={30}>
                                              <p
                                                style={{
                                                  fontFamily:
                                                    "Roboto, sans-serif",
                                                  fontSize: "14px",
                                                  fontWeight: "600",
                                                  color: "#ec6563",
                                                  textTransform: "uppercase",
                                                  letterSpacing: "1px",
                                                  marginBottom: "3px",
                                                  textDecoration: "none",
                                                  display: "inline-block",
                                                  paddingTop: "5px",
                                                }}
                                              >
                                                P:
                                              </p>
                                            </td>
                                            <td>
                                              <a
                                                href="tel:08 9323 0000"
                                                style={{
                                                  fontFamily:
                                                    "Roboto, sans-serif",
                                                  fontSize: "14px",
                                                  fontWeight: "600",
                                                  color: "#30526d",
                                                  textTransform: "uppercase",
                                                  letterSpacing: "1px",
                                                  marginBottom: "3px",
                                                  textDecoration: "none",
                                                  display: "inline-block",
                                                  paddingTop: "5px",
                                                }}
                                              >
                                                1300 CAPITAL
                                              </a>
                                            </td>
                                          </tr>
                                          {expertData.expertEmail && (
                                            <tr>
                                              <td width={30}>
                                                <p
                                                  style={{
                                                    fontFamily:
                                                      "Roboto, sans-serif",
                                                    fontSize: "14px",
                                                    fontWeight: "600",
                                                    color: "#ec6563",
                                                    textTransform: "uppercase",
                                                    letterSpacing: "1px",
                                                    marginBottom: "3px",
                                                    textDecoration: "none",
                                                    display: "inline-block",
                                                    paddingTop: "5px",
                                                  }}
                                                >
                                                  E:
                                                </p>
                                              </td>
                                              <td>
                                                <a
                                                  href={`mailto: ${expertData.expertEmail}`}
                                                  style={{
                                                    fontFamily:
                                                      "Roboto, sans-serif",
                                                    fontSize: "14px",
                                                    fontWeight: "600",
                                                    color: "#30526d",
                                                    letterSpacing: "1px",
                                                    marginBottom: "3px",
                                                    textDecoration: "none",
                                                    display: "inline-block",
                                                    paddingTop: "5px",
                                                  }}
                                                >
                                                  {expertData.expertEmail}
                                                </a>
                                              </td>
                                            </tr>
                                          )}
                                          <tr>
                                            <td width={30}>
                                              <p
                                                style={{
                                                  fontFamily:
                                                    "Roboto, sans-serif",
                                                  fontSize: "14px",
                                                  fontWeight: "600",
                                                  color: "#ec6563",
                                                  textTransform: "uppercase",
                                                  letterSpacing: "1px",
                                                  marginBottom: "3px",
                                                  textDecoration: "none",
                                                  display: "inline-block",
                                                  paddingTop: "5px",
                                                }}
                                              >
                                                W:
                                              </p>
                                            </td>
                                            <td>
                                              <a
                                                href="https://cpadvisory.com.au/"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                style={{
                                                  fontFamily:
                                                    "Roboto, sans-serif",
                                                  fontSize: "14px",
                                                  fontWeight: "600",
                                                  color: "#30526d",
                                                  letterSpacing: "1px",
                                                  marginBottom: "3px",
                                                  textDecoration: "none",
                                                  display: "inline-block",
                                                  paddingTop: "5px",
                                                }}
                                              >
                                                cpadvisory.com.au
                                              </a>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td
                              style={{
                                width: "300px",
                                textAlign: "right",
                                paddingRight: "0px",
                                paddingTop: "20px",
                                verticalAlign: "top",
                              }}
                            >
                              <table>
                                <tbody>
                                  <tr>
                                    <td
                                      style={{
                                        width: "300px",
                                        textAlign: "right",
                                      }}
                                    >
                                      <a
                                        href="https://www.cpadvisory.com.au/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          paddingTop: "0px",
                                        }}
                                      >
                                        <img
                                          src={expertData.companyLogo}
                                          alt=""
                                          style={{
                                            width: "300px",
                                          }}
                                        />
                                      </a>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      style={{
                                        padding: "0px 0px",
                                        width: "300px",
                                        paddingTop: "15px",
                                        textAlign: "right",
                                      }}
                                    >
                                      <img src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/white_space_170.jpg" />
                                      <a
                                        href="https://www.instagram.com/capitalpropertyadvisory/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          marginLeft: "0",
                                          marginRight: "0",
                                        }}
                                      >
                                        <img
                                          src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/instagram_r.png"
                                          alt=""
                                          style={{
                                            width: "30px",
                                            height: "20px",
                                            objectFit: "contain",
                                          }}
                                        />
                                      </a>
                                      <a
                                        href="https://www.facebook.com/capitalpropertyadvisory/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          marginRight: "0",
                                        }}
                                      >
                                        <img
                                          src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/facebook_r_2.png"
                                          alt=""
                                          style={{
                                            width: "30px",
                                            height: "20px",
                                            objectFit: "contain",
                                          }}
                                        />
                                      </a>
                                      <a
                                        href="https://au.linkedin.com/company/capital-property-advisory/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          marginRight: "0",
                                        }}
                                      >
                                        <img
                                          src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/linkedin_r_2.png"
                                          alt=""
                                          style={{
                                            width: "30px",
                                            height: "20px",
                                            objectFit: "contain",
                                          }}
                                        />
                                      </a>
                                      <a
                                        href="https://open.spotify.com/show/02cyiNPOIIRRXCzCaDcP2g?si=37d97901349f493b&nd=1&dlsi=158951d90f264278"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-block",
                                          marginRight: "0",
                                        }}
                                      >
                                        <img
                                          src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/spotify_r.png"
                                          alt=""
                                          style={{
                                            width: "30px",
                                            height: "20px",
                                            objectFit: "contain",
                                          }}
                                        />
                                      </a>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        // align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          {/* footer info row one */}
                          {expertData.footerInfoRowOne && (
                            <tr>
                              <td
                                style={{
                                  borderTop: "5px solid #fff",
                                }}
                              >
                                <p
                                  style={{
                                    fontFamily: "Roboto, sans-serif",
                                    fontSize: "14px",
                                    fontWeight: "400",
                                    color: "rgb(48, 82, 109)",
                                    letterSpacing: "1px",
                                    marginBottom: "3px",
                                    paddingTop: "5px",
                                  }}
                                >
                                  {expertData.footerInfoRowOne}
                                </p>
                              </td>
                            </tr>
                          )}
                          {/* footer info row two */}
                          {expertData.footerInfoRowTwo && (
                            <tr>
                              <td
                                style={{
                                  borderTop: "2px solid #fff",
                                }}
                              >
                                <p
                                  style={{
                                    fontFamily: "Roboto, sans-serif",
                                    fontSize: "14px",
                                    fontWeight: "400",
                                    color: "rgb(48, 82, 109)",
                                    letterSpacing: "1px",
                                    marginBottom: "3px",
                                    paddingTop: "2px",
                                  }}
                                >
                                  {expertData.footerInfoRowTwo}
                                </p>
                              </td>
                            </tr>
                          )}
                          {/* footer info row three */}
                          {expertData.footerInfoRowThree && (
                            <tr>
                              <td
                                style={{
                                  borderTop: "5px solid #fff",
                                }}
                              >
                                <p
                                  style={{
                                    fontFamily: "Roboto, sans-serif",
                                    fontSize: "14px",
                                    fontWeight: "400",
                                    color: "rgb(48, 82, 109)",
                                    letterSpacing: "1px",
                                    marginBottom: "3px",
                                    paddingTop: "5px",
                                  }}
                                >
                                  {expertData.footerInfoRowThree}
                                </p>
                              </td>
                            </tr>
                          )}
                          {/* footer info row four */}
                          {expertData.footerInfoRowFour && (
                            <tr>
                              <td
                                style={{
                                  borderTop: "2px solid #fff",
                                }}
                              >
                                <p
                                  style={{
                                    fontFamily: "Roboto, sans-serif",
                                    fontSize: "14px",
                                    fontWeight: "400",
                                    color: "rgb(48, 82, 109)",
                                    letterSpacing: "1px",
                                    marginBottom: "3px",
                                    paddingTop: "2px",
                                  }}
                                >
                                  {expertData.footerInfoRowFour}
                                </p>
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <table
                        bgcolor="#ffffff"
                        // align="start"
                        width="600"
                        style={{
                          backgroundColor: "#ffffff",
                          maxWidth: "600px",
                          width: "100%",
                          fontFamily: "Roboto, sans-serif",
                          padding: "0",
                          borderSpacing: "0",
                        }}
                        cellSpacing="0"
                        cellPadding="0"
                      >
                        <tbody>
                          <tr>
                            <td
                              style={{
                                padding: "20px 0px",
                                width: "600px",
                                paddingTop: "20px",
                              }}
                            >
                              <img src={expertData.brandLogo} alt="" />
                              {/* <a
                                href="http://rebaa.com.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/rebaa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/pipa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://www.pipa.asn.au/qualified-property-investment-adviser-property-investment-adviser/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/qpia.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a>
                              <a
                                href="https://members.reiwa.com.au/s/"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                  display: "inline-block",
                                  marginLeft: "5px",
                                }}
                              >
                                <img
                                  src="https://apps.okmg.com/client_signatures/cpa-signature/static/images/reiwa.jpg"
                                  alt=""
                                  style={{
                                    width: "auto",
                                    height: "40px",
                                    objectFit: "contain",
                                  }}
                                />
                              </a> */}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};
