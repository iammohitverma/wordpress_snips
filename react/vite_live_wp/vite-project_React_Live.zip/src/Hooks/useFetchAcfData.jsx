import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const useFetchAcfData = (pageId, pageKey) => {
  const baseUrl = import.meta.env.VITE_API_URL;

  return useQuery({
    queryKey: ["acfData", pageId, pageKey],
    queryFn: async () => {
      const res = await axios.get(`${baseUrl}/wp-json/acf/v3/pages/${pageId}`);
      const json = res.data;
      if (json?.acf && Array.isArray(json.acf[pageKey])) {
        return json.acf[pageKey];
      } else {
        throw new Error("Flexible content not found or invalid format.");
      }
    },
  });
};

export default useFetchAcfData;
