import axios from "axios";
import React, { useState } from "react";

const baseUrl = import.meta.env.VITE_API_URL;
const formId = "166";

function ContactForm({ data }) {
  const sectionData = data || {};
  const isform = sectionData.show_form;

  // State for form fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState({}); // error state
  const [loading, setLoading] = useState(); // loading state

  const handleSubmit = async (e) => {
    setLoading(true); // loading on
    e.preventDefault(); // form submit te page reload rokya
    setErrors({}); // pehle wale errors clear kar diye

    const formData = new FormData();
    formData.append("your-name", name);
    formData.append("your-email", email);
    formData.append("your-message", message);
    formData.append("_wpcf7_unit_tag", 123); // Contact Form 7 nu eh zaruri field chahidi

    try {
      const response = await axios.post(
        `${baseUrl}/wp-json/contact-form-7/v1/contact-forms/${formId}/feedback`, // endpoint
        formData, // formData bhejeya
        {
          headers: {
            "Content-Type": "multipart/form-data", // content type set kita
          },
        }
      );
      // Response check kar reha
      if (response.data.status === "validation_failed") {
        // agar validation failed hoya
        const fieldErrors = {}; // empty object errors layi
        // invalid_fields array loop kitta
        response.data.invalid_fields.forEach((f) => {
          fieldErrors[f.field] = f.message; // field name nu message assign kita
        });

        setErrors(fieldErrors); // errors state update kitti
      } else if (response.data.status === "mail_sent") {
        // agar form send ho gaya
        alert("Form sent!"); // alert show kita
        setName(""); // name field empty kar ditta
        setEmail(""); // email field empty kar ditta
        setMessage(""); // message field empty kar ditta
      }

      console.log(response);

      setLoading(false); // loading off
    } catch (error) {
      setLoading(false); // loading off
      // agar error aayi request ch
      console.error(
        "Form submission failed:", // error message print
        error.response?.data || error.message // response ya message show
      );
    }
  };

  return (
    <>
      {isform == "yes" && (
        <section className="ContactForm py-5">
          <div className="container">
            <div className="row">
              <div className="col-8 mx-auto">
                <div className="p-5 bg-body-tertiary rounded-3">
                  <h2 className="text-center mb-3">Contact Us</h2>
                  <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                      <label htmlFor="name" className="form-label">
                        Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        onChange={(e) => setName(e.target.value)}
                        value={name}
                      />
                      {errors["your-name"] && (
                        <p className="alert alert-danger p-1">
                          {errors["your-name"]}
                        </p>
                      )}
                    </div>
                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        onChange={(e) => setEmail(e.target.value)}
                        value={email}
                      />
                      {errors["your-email"] && (
                        <p className="alert alert-danger p-1">
                          {errors["your-email"]}
                        </p>
                      )}
                    </div>
                    <div className="mb-3">
                      <label htmlFor="message" className="form-label">
                        Message
                      </label>
                      <textarea
                        name="message"
                        id="message"
                        className="form-control"
                        onChange={(e) => setMessage(e.target.value)}
                        value={message}
                      ></textarea>
                      {errors["your-email"] && (
                        <p className="alert alert-danger p-1">
                          {errors["your-email"]}
                        </p>
                      )}
                    </div>
                    {loading && (
                      <img
                        src="/loader.gif"
                        alt=""
                        width={50}
                        style={{ mixBlendMode: "darken" }}
                      />
                    )}
                    <div className="d-flex">
                      <button type="submit" className="btn btn-primary">
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
export default ContactForm;
