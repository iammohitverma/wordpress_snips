<?php
/**
 * Template part for displaying Question (Single/Full Width)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package boldpark-theme
 */
$question_heading = get_sub_field('heading');
$question_content = get_sub_field('content');
$question_button = get_sub_field('button');
?>

<div class="container">
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="inner pl-25">
            <?php if($question_heading): ?>
                <h3 class="hdng sec_title_60">
                    <?php echo $question_heading; ?>
                </h3>
                <?php endif; 
                  if($question_content):
                ?>
                <?php echo$question_content; ?>
                <?php endif; 
                  if($question_button):
                  $question_button_url = $question_button['url'];
                                    $question_button_title = $question_button['title'];
                  ?>
                <a href="<?php echo esc_url( $question_button_url ); ?>" class="cmn_btn"><?php echo esc_html( $question_button_title ); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>